# Live Graphics Generator

A Python desktop application that generates live graphics files (CSV and JSON) for your events.

## Features

- **Real-time Updates**: Updates graphics files every 10 seconds
- **Multiple Formats**: Generates CSV and JSON files
- **Easy Setup**: Simple GUI with Event ID paste functionality
- **Custom Output**: Choose your output folder
- **Live Logging**: See what's happening in real-time

## Files Generated

- `lower-thirds-live.csv` - Lower thirds graphics data
- `schedule-live.csv` - Event schedule data  
- `custom-graphics-live.csv` - Custom graphics data

## How to Use

1. **Run the application**: Double-click `run_live_graphics.bat`
2. **Enter Event ID**: Copy from your Graphics Links page and paste
3. **Choose Output Folder**: Select where to save the files
4. **Start Generating**: Click "Start Live Updates" to begin
5. **Files Update**: Files are updated every 10 seconds automatically

## Requirements

- Python 3.7 or higher
- Internet connection
- Valid Supabase credentials

## Installation

1. Download all files to a folder
2. Run `run_live_graphics.bat` (installs dependencies automatically)
3. Or manually: `pip install -r requirements.txt` then `python live_graphics_generator.py`
