# Netlify Deployment Guide

This package contains your Run of Show Timer application ready for Netlify deployment.

## Quick Deploy

### Option 1: Deploy from Git (Recommended)
1. Push this code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Connect your repository to Netlify
3. Set the build command to: `npm run build`
4. Set the publish directory to: `dist`
5. Add your environment variables (see below)
6. Deploy!

### Option 2: Manual Deploy
1. Zip this entire folder
2. Go to [Netlify](https://netlify.com)
3. Drag and drop the zip file to deploy

## Environment Variables

You need to set these environment variables in your Netlify dashboard:

### Required Variables:
- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Your Supabase anonymous key

### How to Set Environment Variables:
1. Go to your Netlify site dashboard
2. Navigate to Site settings > Environment variables
3. Add the variables above with your actual values

## Getting Supabase Credentials

1. Go to your [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project
3. Go to Settings > API
4. Copy the Project URL and anon/public key

## Features Included

- ✅ React SPA with proper routing
- ✅ Optimized build with Vite
- ✅ Security headers configured
- ✅ Caching rules for performance
- ✅ SPA redirects for client-side routing
- ✅ Gzip compression enabled

## Custom Domain (Optional)

To use a custom domain:
1. Go to Site settings > Domain management
2. Add your custom domain
3. Update the `VITE_APP_DOMAIN` environment variable if needed

## Build Optimization

The build includes:
- Code splitting for better performance
- Asset optimization
- Gzip compression
- Proper caching headers

## Troubleshooting

### Build Fails
- Check that all environment variables are set
- Ensure Node.js version is 18 or higher
- Check the build logs for specific errors

### App Doesn't Load
- Verify environment variables are correct
- Check browser console for errors
- Ensure Supabase credentials are valid

### Routing Issues
- The `_redirects` file handles SPA routing
- All routes redirect to `index.html` for React Router

## Support

For issues with this deployment package, check:
1. Netlify build logs
2. Browser console for client-side errors
3. Supabase dashboard for database issues
