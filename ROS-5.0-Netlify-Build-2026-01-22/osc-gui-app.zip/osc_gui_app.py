import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import time
import json
import socket
import struct
from datetime import datetime
from supabase import create_client, Client
import os

# Supabase configuration
SUPABASE_URL = 'https://huqijhevmtgardkyeowa.supabase.co'
SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1cWlqaGV2bXRnYXJka3llb3dhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcyNDgyNTQsImV4cCI6MjA3MjgyNDI1NH0.1G81Zif1YWQwISEGJw4XMzY89Rlvh6Jda1-j-roPZBk'

class OSCServer:
    def __init__(self, port=57130):
        self.port = port
        self.running = False
        self.socket = None
        self.thread = None
        
    def start(self):
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.socket.bind(('0.0.0.0', self.port))
            self.running = True
            self.thread = threading.Thread(target=self._listen, daemon=True)
            self.thread.start()
            return True
        except Exception as e:
            return False, str(e)
    
    def stop(self):
        self.running = False
        if self.socket:
            self.socket.close()
    
    def _listen(self):
        while self.running:
            try:
                data, addr = self.socket.recvfrom(1024)
                self._handle_message(data, addr)
            except:
                pass
    
    def _handle_message(self, data, addr):
        try:
            # Simple OSC message parsing (basic implementation)
            message = data.decode('utf-8', errors='ignore')
            print(f"OSC from {addr}: {message}")
            
            # Handle common OSC commands
            if '/ping' in message:
                self._send_response('/pong', ['server', 'alive'], addr)
            elif '/list-events' in message:
                self._send_event_list(addr)
            elif '/set-event' in message:
                # Extract event ID from message
                parts = message.split()
                if len(parts) > 1:
                    event_id = parts[1]
                    self._send_response('/event-set', [event_id], addr)
            
        except Exception as e:
            print(f"Error handling OSC message: {e}")
    
    def _send_response(self, address, args, addr):
        # Simple OSC response (basic implementation)
        response = f"{address} {' '.join(map(str, args))}"
        self.socket.sendto(response.encode(), addr)
    
    def _send_event_list(self, addr):
        # This would be implemented with actual Supabase data
        events = ["Event 1", "Event 2", "Event 3"]  # Placeholder
        self._send_response('/events', events, addr)

class OSCGUIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("OSC Control Panel")
        self.root.geometry("800x600")
        
        # Supabase client
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        
        # OSC Server
        self.osc_server = OSCServer()
        
        # Current event
        self.current_event = None
        self.events = []
        
        self.setup_ui()
        self.start_osc_server()
        self.load_events()
    
    def setup_ui(self):
        # Create notebook for tabs
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Events Tab
        events_frame = ttk.Frame(notebook)
        notebook.add(events_frame, text="Events")
        self.setup_events_tab(events_frame)
        
        # OSC Tab
        osc_frame = ttk.Frame(notebook)
        notebook.add(osc_frame, text="OSC Server")
        self.setup_osc_tab(osc_frame)
        
        # Log Tab
        log_frame = ttk.Frame(notebook)
        notebook.add(log_frame, text="Log")
        self.setup_log_tab(log_frame)
    
    def setup_events_tab(self, parent):
        # Event selection
        ttk.Label(parent, text="Select Event:").pack(pady=5)
        
        self.event_var = tk.StringVar()
        self.event_combo = ttk.Combobox(parent, textvariable=self.event_var, width=50)
        self.event_combo.pack(pady=5)
        self.event_combo.bind('<<ComboboxSelected>>', self.on_event_selected)
        
        ttk.Button(parent, text="Refresh Events", command=self.load_events).pack(pady=5)
        
        # Event details
        details_frame = ttk.LabelFrame(parent, text="Event Details")
        details_frame.pack(fill='both', expand=True, pady=10)
        
        self.details_text = scrolledtext.ScrolledText(details_frame, height=10)
        self.details_text.pack(fill='both', expand=True, padx=5, pady=5)
    
    def setup_osc_tab(self, parent):
        # Server status
        status_frame = ttk.LabelFrame(parent, text="Server Status")
        status_frame.pack(fill='x', padx=5, pady=5)
        
        self.status_var = tk.StringVar(value="Starting...")
        ttk.Label(status_frame, textvariable=self.status_var).pack(pady=5)
        
        # OSC Commands
        commands_frame = ttk.LabelFrame(parent, text="OSC Commands")
        commands_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        commands_text = """
Supported OSC Commands:
/list-events          - List all events
/set-event <id>       - Set current event
/ping                 - Test connection
/timer/start          - Start timer
/timer/stop           - Stop timer
/timer/reset          - Reset timer
/cue/<id>/load        - Load cue
        """
        
        ttk.Label(commands_frame, text=commands_text, justify='left').pack(pady=10)
        
        # Test commands
        test_frame = ttk.LabelFrame(parent, text="Test Commands")
        test_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Button(test_frame, text="Test Ping", command=self.test_ping).pack(side='left', padx=5)
        ttk.Button(test_frame, text="List Events", command=self.test_list_events).pack(side='left', padx=5)
    
    def setup_log_tab(self, parent):
        self.log_text = scrolledtext.ScrolledText(parent, height=20)
        self.log_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Clear log button
        ttk.Button(parent, text="Clear Log", command=self.clear_log).pack(pady=5)
    
    def log_message(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        
        # Also print to console
        print(log_entry.strip())
    
    def clear_log(self):
        self.log_text.delete(1.0, tk.END)
    
    def start_osc_server(self):
        success = self.osc_server.start()
        if success:
            self.status_var.set(f"OSC Server running on port {self.osc_server.port}")
            self.log_message(f"OSC Server started on port {self.osc_server.port}")
        else:
            self.status_var.set("Failed to start OSC Server")
            self.log_message("Failed to start OSC Server")
    
    def load_events(self):
        try:
            self.log_message("Loading events from Supabase...")
            
            # Query events from Supabase
            response = self.supabase.table('events').select('*').execute()
            
            if response.data:
                self.events = response.data
                event_names = [f"{event['id']}: {event.get('name', 'Unnamed')}" for event in self.events]
                self.event_combo['values'] = event_names
                self.log_message(f"Loaded {len(self.events)} events")
            else:
                self.log_message("No events found")
                
        except Exception as e:
            self.log_message(f"Error loading events: {e}")
            messagebox.showerror("Error", f"Failed to load events: {e}")
    
    def on_event_selected(self, event):
        selection = self.event_var.get()
        if selection:
            event_id = selection.split(':')[0]
            self.current_event = next((e for e in self.events if str(e['id']) == event_id), None)
            
            if self.current_event:
                details = f"Event ID: {self.current_event['id']}\n"
                details += f"Name: {self.current_event.get('name', 'N/A')}\n"
                details += f"Date: {self.current_event.get('date', 'N/A')}\n"
                details += f"Location: {self.current_event.get('location', 'N/A')}\n"
                
                self.details_text.delete(1.0, tk.END)
                self.details_text.insert(1.0, details)
                
                self.log_message(f"Selected event: {self.current_event['name']}")
    
    def test_ping(self):
        # Send ping to local OSC server
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(b'/ping', ('localhost', self.osc_server.port))
            sock.close()
            self.log_message("Ping sent to OSC server")
        except Exception as e:
            self.log_message(f"Error sending ping: {e}")
    
    def test_list_events(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(b'/list-events', ('localhost', self.osc_server.port))
            sock.close()
            self.log_message("List events command sent")
        except Exception as e:
            self.log_message(f"Error sending list events: {e}")
    
    def on_closing(self):
        self.log_message("Shutting down OSC server...")
        self.osc_server.stop()
        self.root.destroy()

def main():
    root = tk.Tk()
    app = OSCGUIApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()
