import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import DriftStatusIndicator from './DriftStatusIndicator';
import { DatabaseService, TimerMessage } from '../services/database';
import { socketClient } from '../services/socket-client';
import { startSecondTicker } from '../utils/secondTicker';
import {
  countdownColorForRemaining,
  useCountdownColorMode,
} from '../lib/countdownColor';
import { overtimeSignPrefix, useOvertimeSign } from '../lib/overtimeSign';
import { OvertimeClockText } from '../lib/OvertimeClockText';
import { findTopPreshowCue, isPreshowTimerMessage } from '../lib/preshowCountdown';
import { shouldUsePreshowRainbow } from '../lib/usePreshowRainbow';
import { AltTimerBadge } from './AltTimerBadge';
import CueCardClockOverlay from './CueCardClockOverlay';
import {
  getLiveIndentedSubTimer,
  hasDualAltLayout,
  isOperatorAltTimer,
  mapOperatorCountdownRow,
  resolveDisplaySecondaryTimer,
} from '../lib/operatorCountdown';
import TeleprompterClockOverlay, {
  type TeleprompterClockFeed,
} from './TeleprompterClockOverlay';
import PptClockOverlay from './PptClockOverlay';
import { parsePptClockSync, type PptClockFeed } from '../lib/pptClockFeed';
import type { CueCardComment, CueCardSlide } from '../lib/cueCards';
import { resolveLiveCueLabel, shouldKeepExistingRunningTimer } from '../lib/cueDisplay';

interface DsmClockProps {
  isRunning?: boolean;
  elapsedTime?: number;
  totalDuration?: number;
  onClose?: () => void;
  message?: string;
  messageEnabled?: boolean;
  itemId?: number; // Add itemId for drift detection
  eventId?: string; // Add eventId for Supabase message loading
  supabaseMessage?: TimerMessage | null; // Add supabaseMessage prop
  scheduleItems?: any[]; // Run-of-show items; when active cue has timerDisplay === 'timeOfDay', show large time-of-day instead of countdown
  /** When false (session disconnect / Displays paused), stop sockets + HTTP polls. */
  networkEnabled?: boolean;
  mainTimer?: {
    cue: string;
    segmentName: string;
  } | null;
  secondaryTimer?: {
    itemId: number;
    remaining: number;
    duration: number;
    cue: string;
    segmentName: string;
  } | null;
  /** DSM layout reference controls (owned by page chrome; hidden in fullscreen) */
  force16x9Ref?: boolean;
  simSecondary?: boolean;
  simOvertime?: boolean;
}

/** Fixed design canvas — scaled uniformly so windowed / fullscreen stay 1:1. */
const DSM_DESIGN_W = 1920;
const DSM_DESIGN_H = 1080;

/** DSM Clock Timer — fork of Clock for DSM UI work. Keep in sync only when intentionally porting fixes. */
const DsmClock: React.FC<DsmClockProps> = ({
  isRunning = false,
  elapsedTime = 0,
  totalDuration = 0, // Default to 0 when no timer is running
  onClose,
  message = '',
  messageEnabled = false,
  itemId,
  eventId,
  supabaseMessage = null,
  scheduleItems,
  networkEnabled = true,
  mainTimer = null,
  secondaryTimer = null,
  force16x9Ref = true,
  simSecondary = false,
  simOvertime = false,
}) => {
  const [timerProgress, setTimerProgress] = useState<{ elapsed: number; total: number }>({
    elapsed: elapsedTime,
    total: totalDuration
  });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [messageLoading, setMessageLoading] = useState(false);
  const [supabaseOnly, setSupabaseOnly] = useState(true);
  const [hybridTimerData, setHybridTimerData] = useState<any>({ activeTimer: null });
  const [cueClockFeed, setCueClockFeed] = useState<{
    enabled: boolean;
    slide: CueCardSlide | null;
    comments: CueCardComment[];
  } | null>(null);
  const [teleprompterClockFeed, setTeleprompterClockFeed] =
    useState<TeleprompterClockFeed | null>(null);
  const [pptClockFeed, setPptClockFeed] = useState<PptClockFeed | null>(null);
  const [secondaryTimerUpdate, setSecondaryTimerUpdate] = useState(0);
  const [secondaryTimerStartTime, setSecondaryTimerStartTime] = useState<Date | null>(null);
  const [lastActiveTimerId, setLastActiveTimerId] = useState<string | null>(null);
  const [lastActiveItemId, setLastActiveItemId] = useState<number | null>(null);
  const [lastActiveStartTime, setLastActiveStartTime] = useState<string | null>(null);
  const [clockOffset, setClockOffset] = useState<number>(0); // Offset between client and server clocks in ms
  const simSecondaryStartedAtRef = useRef<string>(new Date().toISOString());
  const [stageScale, setStageScale] = useState(1);
  const stageOuterRef = useRef<HTMLDivElement>(null);
  const countdownColorMode = useCountdownColorMode();
  const overtimeSign = useOvertimeSign();

  useLayoutEffect(() => {
    const el = stageOuterRef.current;
    if (!el) return;
    const update = () => {
      const { clientWidth: w, clientHeight: h } = el;
      if (w <= 0 || h <= 0) return;
      setStageScale(Math.min(w / DSM_DESIGN_W, h / DSM_DESIGN_H));
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const stageMessageForColor =
    [hybridTimerData?.timerMessage, supabaseMessage].find((m: any) => m?.enabled) ?? null;
  const activeTimerItemId =
    hybridTimerData?.activeTimer?.item_id ?? hybridTimerData?.activeTimer?.itemId ?? null;
  const activeCue = (() => {
    if (!Array.isArray(scheduleItems) || activeTimerItemId == null) return null;
    const idNum = Number(activeTimerItemId);
    return (
      scheduleItems.find(
        (s: any) =>
          s?.id === activeTimerItemId ||
          String(s?.id) === String(activeTimerItemId) ||
          (Number.isFinite(idNum) && Number(s?.id) === idNum)
      ) || null
    );
  })();
  const activeCueProgramType = activeCue?.programType || null;
  // Prefer the running cue's day so Day 2+ PreShow matches (not Day 1's top cue)
  const topPreshowItemId = Array.isArray(scheduleItems)
    ? findTopPreshowCue(scheduleItems, null, activeCue?.day ?? null)?.id ?? null
    : null;
  const timerRunningForRainbow = !!(
    hybridTimerData?.activeTimer?.is_running && hybridTimerData?.activeTimer?.is_active
  );
  const usePreshowRainbow = shouldUsePreshowRainbow(stageMessageForColor, {
    isRunning: timerRunningForRainbow,
    programType: activeCueProgramType,
    itemId: activeTimerItemId,
    topPreshowItemId,
  });

  // Clock component always runs in WebSocket-only mode

  // Clock always uses WebSocket data, no props handling needed
  
  // Helper function to get synced current time (client time + offset)
  const getSyncedNow = () => new Date(Date.now() + clockOffset);
  
  // Helper function to calculate elapsed time with clock sync
  const calculateElapsed = (startedAt: Date | string) => {
    const syncedNow = getSyncedNow();
    const start = startedAt instanceof Date ? startedAt : new Date(startedAt);
    return Math.floor((syncedNow.getTime() - start.getTime()) / 1000);
  };

  const isResolumeSynced = (timer: {
    resolume_state?: string;
    mitti_state?: string;
    avplayout_state?: string;
    time_source?: string;
  } | null | undefined) =>
    timer?.resolume_state === 'synced' ||
    timer?.mitti_state === 'synced' ||
    timer?.avplayout_state === 'synced' ||
    (timer?.time_source === 'resolume' && timer?.resolume_state !== 'armed') ||
    (timer?.time_source === 'mitti' && timer?.mitti_state !== 'armed') ||
    (timer?.time_source === 'avplayout' && timer?.avplayout_state !== 'armed');

  const isResolumeArmed = (timer: {
    resolume_state?: string;
    mitti_state?: string;
    avplayout_state?: string;
  } | null | undefined) =>
    timer?.resolume_state === 'armed' ||
    timer?.mitti_state === 'armed' ||
    timer?.avplayout_state === 'armed';

  const getExternalSyncLabel = (
    timer: {
      time_source?: string;
      resolume_state?: string;
      mitti_state?: string;
      avplayout_state?: string;
      user_id?: string;
      user_name?: string;
    } | null | undefined
  ): 'Mitti' | 'AV-Playout' | 'Resolume' => {
    if (
      timer?.time_source === 'avplayout' ||
      timer?.avplayout_state === 'armed' ||
      timer?.avplayout_state === 'synced' ||
      timer?.user_id === 'companion-avplayout' ||
      timer?.user_name === 'AV-Playout Sync'
    ) {
      return 'AV-Playout';
    }
    if (
      timer?.time_source === 'mitti' ||
      timer?.mitti_state === 'armed' ||
      timer?.mitti_state === 'synced' ||
      timer?.user_id === 'companion-mitti' ||
      timer?.user_name === 'Mitti Sync'
    ) {
      return 'Mitti';
    }
    return 'Resolume';
  };

  const isResolumeCompanionSubCue = (timer: { user_name?: string; user_id?: string } | null | undefined) =>
    timer?.user_name === 'Resolume Sync' ||
    timer?.user_id === 'companion-resolume' ||
    timer?.user_name === 'Mitti Sync' ||
    timer?.user_id === 'companion-mitti' ||
    timer?.user_name === 'AV-Playout Sync' ||
    timer?.user_id === 'companion-avplayout';

  const enrichSubCueTimer = (timer: any) => {
    if (!timer || typeof timer !== 'object') return timer;
    if (isResolumeSynced(timer) || isResolumeArmed(timer)) return timer;
    if (!isResolumeCompanionSubCue(timer)) return timer;
    const isAv =
      timer?.user_id === 'companion-avplayout' || timer?.user_name === 'AV-Playout Sync';
    const isMitti = timer?.user_id === 'companion-mitti' || timer?.user_name === 'Mitti Sync';
    return {
      ...timer,
      time_source: isAv ? 'avplayout' : isMitti ? 'mitti' : 'resolume',
      ...(isAv
        ? { avplayout_state: timer.is_running ? 'synced' : 'armed' }
        : isMitti
          ? { mitti_state: timer.is_running ? 'synced' : 'armed' }
          : { resolume_state: timer.is_running ? 'synced' : 'armed' }),
    };
  };

  /** Op Timer lives only in operatorCountdown — never in secondaryTimer (cue) lifecycle. */
  const setOperatorCountdown = (
    prev: any,
    mappedOp: ReturnType<typeof mapOperatorCountdownRow>
  ) => {
    const next: any = { ...prev, operatorCountdown: mappedOp };
    // Strip any stale dual-write of Op into secondaryTimer
    if (isOperatorAltTimer(prev?.secondaryTimer)) {
      next.secondaryTimer = null;
    }
    return next;
  };

  const sameEventId = (id: unknown) => String(id || '') === String(eventId || '');

  const getRemainingFromTimer = (
    timer: { started_at?: string; duration_seconds?: number } | null | undefined,
    offsetMs: number
  ) => {
    if (!timer?.started_at || timer.duration_seconds == null) return null;
    const startedMs = new Date(timer.started_at).getTime();
    if (!Number.isFinite(startedMs)) return null;
    return timer.duration_seconds - (Date.now() + offsetMs - startedMs) / 1000;
  };

  const shouldRejectResolumeAlignReset = (
    prev: { started_at?: string; duration_seconds?: number; is_running?: boolean } | null | undefined,
    next: {
      started_at?: string;
      duration_seconds?: number;
      is_running?: boolean;
      resolume_state?: string;
      mitti_state?: string;
      avplayout_state?: string;
      time_source?: string;
      resolume_align_reason?: string;
      mitti_align_reason?: string;
      avplayout_align_reason?: string;
    },
    offsetMs: number
  ) => {
    if (!prev?.is_running || !next.is_running || !isResolumeSynced(next)) return false;
    if (!prev.started_at || !next.started_at || prev.started_at === next.started_at) return false;
    const reason = String(
      next.avplayout_align_reason || next.mitti_align_reason || next.resolume_align_reason || ''
    ).toLowerCase();
    if (reason === 'loop') return false;
    if (next.time_source === 'avplayout' || next.avplayout_state === 'synced') return false;
    const dur = next.duration_seconds ?? prev.duration_seconds ?? 0;
    if (dur <= 0) return false;
    const prevRem = getRemainingFromTimer(prev, offsetMs);
    const nextRem = getRemainingFromTimer(next, offsetMs);
    if (prevRem == null || nextRem == null) return false;
    return prevRem <= 15 && nextRem > dur * 0.85;
  };

  // Update timer progress when props change (non-WebSocket mode)
  useEffect(() => {
    if (!supabaseOnly) {
      // Use props data when not in hybrid mode
      setTimerProgress({
        elapsed: elapsedTime,
        total: totalDuration
      });
    }
  }, [elapsedTime, totalDuration, supabaseOnly]);

  // Real-time countdown timer for running timers
  useEffect(() => {
    console.log('🔍 [CLOCK DEBUG] Timer progress effect triggered', {
      isRunning: hybridTimerData?.activeTimer?.is_running,
      isActive: hybridTimerData?.activeTimer?.is_active,
      startedAt: hybridTimerData?.activeTimer?.started_at,
      duration: hybridTimerData?.activeTimer?.duration_seconds
    });
    
    if (supabaseOnly && hybridTimerData?.activeTimer?.is_running && hybridTimerData?.activeTimer?.is_active) {
      const activeTimer = hybridTimerData.activeTimer;
      const startedAt = new Date(activeTimer.started_at);
      const total = activeTimer.duration_seconds || 0;
      
      console.log('🔍 [CLOCK DEBUG] Setting up local countdown timer', {
        startedAt: startedAt.toISOString(),
        total
      });
      
      const updateCountdown = () => {
        const elapsed = calculateElapsed(startedAt);
        
        console.log('🔍 [CLOCK DEBUG] Local countdown update', { elapsed, total, clockOffsetSeconds: Math.floor(clockOffset / 1000) });
        
        setTimerProgress({
          elapsed: elapsed,
          total: total
        });
      };
      
      // Worker-based tick so countdown stays smooth when window is visible but unfocused
      const stopTicker = startSecondTicker(updateCountdown);
      
      return () => {
        console.log('🔍 [CLOCK DEBUG] Cleaning up countdown interval');
        stopTicker();
      };
    } else if (supabaseOnly && hybridTimerData?.activeTimer && !hybridTimerData?.activeTimer?.is_running) {
      // Timer is loaded but not running - show 0 elapsed
      const activeTimer = hybridTimerData.activeTimer;
      console.log('🔍 [CLOCK DEBUG] Timer loaded but not running', {
        duration: activeTimer.duration_seconds
      });
      
      setTimerProgress({
        elapsed: 0,
        total: activeTimer.duration_seconds || 0
      });
    } else if (supabaseOnly && !hybridTimerData?.activeTimer) {
      // No active timer - clear display
      console.log('🔍 [CLOCK DEBUG] No active timer - clearing display');
      
      setTimerProgress({
        elapsed: 0,
        total: 0
      });
    }
  }, [hybridTimerData?.activeTimer?.is_running, hybridTimerData?.activeTimer?.is_active, hybridTimerData?.activeTimer?.started_at, hybridTimerData?.activeTimer?.duration_seconds, hybridTimerData?.activeTimer, supabaseOnly, clockOffset]);

  // Update current time every second (Worker tick — not throttled when unfocused but visible)
  useEffect(() => {
    return startSecondTicker(() => {
      setCurrentTime(new Date());
    });
  }, []);

  // REMOVED: This was for props-based mode, but Clock always uses WebSocket mode
  // Timer progress is handled by the effect above (lines 74-134)

  // Listen for full screen changes
  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);

  // Message loading is now handled by ClockPage via real-time subscriptions
  // No need for polling here since ClockPage already manages this

  // WebSocket mode: Fetch timer data via WebSocket when supabaseOnly is true
  useEffect(() => {
    if (!supabaseOnly || !eventId || !networkEnabled) {
      // Clear any existing WebSocket connections (handled in cleanup)
      // Reset timer tracking when exiting WebSocket mode
      setLastActiveTimerId(null);
      setLastActiveItemId(null);
      setLastActiveStartTime(null);
      if (eventId && !networkEnabled) {
        socketClient.disconnect(eventId, 'clock');
      }
      
      // WebSocket provides real-time updates, no drift detection cleanup needed
      
      return;
    }

    console.log('🔄 Clock: Setting up WebSocket connection for eventId:', eventId);
    let loadInFlight = false;

    const loadActiveTimer = async () => {
      if (loadInFlight) {
        console.log('🔄 Already loading active timer, skipping...');
        return;
      }
      
      try {
        loadInFlight = true;
        console.log('🔄 Loading active timer from API...');
        const activeTimer = await DatabaseService.getActiveTimer(eventId);
        if (activeTimer && activeTimer.timer_state !== 'stopped' && activeTimer.is_active) {
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: activeTimer
          }));
          console.log('✅ Active timer updated:', activeTimer);
        } else {
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('❌ No active timer found or timer is stopped');
        }
        
        // Also load sub-cue timers and messages on initial load
        try {
          console.log('🔄 Clock: Loading sub-cue timers and messages on initial load...');
          
           // Load current sub-cue timers
           const subCueTimersResult = await DatabaseService.getActiveSubCueTimers(eventId);
           if (subCueTimersResult && subCueTimersResult.data && subCueTimersResult.data.length > 0) {
             // Find the first running sub-cue timer
             const runningSubCueTimer = subCueTimersResult.data.find(timer => 
               timer.timer_state === 'running' || timer.is_running === true
             );
            if (runningSubCueTimer) {
              setHybridTimerData(prev => ({
                ...prev,
                secondaryTimer: enrichSubCueTimer(runningSubCueTimer)
              }));
              console.log('✅ Clock: Initial load - sub-cue timer loaded:', runningSubCueTimer);
            } else {
              setHybridTimerData(prev => ({ ...prev, secondaryTimer: null }));
            }
          } else {
            setHybridTimerData(prev => ({ ...prev, secondaryTimer: null }));
          }

          const operatorRow = await DatabaseService.getOperatorCountdown(eventId);
          setHybridTimerData((prev) =>
            setOperatorCountdown(prev, mapOperatorCountdownRow(operatorRow))
          );
          
          // Load current timer message (enabled only; null clears stale display)
          const timerMessage = await DatabaseService.getTimerMessage(eventId);
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: timerMessage || null
          }));
          console.log('✅ Clock: Initial load - timer message:', timerMessage);
        } catch (error) {
          console.error('❌ Clock: Initial load failed to load sub-cue timers and messages:', error);
        }
        
        // Check if active timer has changed (cue jump detection)
        if (activeTimer && activeTimer.timer_state !== 'stopped' && activeTimer.is_active && supabaseOnly) {
          const currentActiveTimerId = `${activeTimer.item_id}_${activeTimer.started_at}`;
          const currentItemId = activeTimer.item_id;
          
          if (lastActiveTimerId && lastActiveTimerId !== currentActiveTimerId) {
            console.log('🔄 Active timer changed - stopping secondary timer');
            console.log('🔄 Previous timer:', lastActiveTimerId);
            console.log('🔄 New timer:', currentActiveTimerId);
            // Clear sub-cue secondary only — Op Timer is independent
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null,
            }));
          }
          
          // Also check if the item_id changed (new cue loaded) - this should stop sub-cue timer
          if (lastActiveItemId && lastActiveItemId !== currentItemId) {
            console.log('🔄 New cue loaded - stopping secondary timer');
            console.log('🔄 Previous item_id:', lastActiveItemId);
            console.log('🔄 New item_id:', currentItemId);
            // Clear sub-cue secondary only — Op Timer is independent
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null,
            }));
          }
          
          // Check if the start time changed (timer paused/resumed/restarted)
          const currentStartTime = activeTimer.started_at;
          if (lastActiveStartTime && lastActiveStartTime !== currentStartTime) {
            console.log('🔄 Timer start time changed - restarting local timer');
            console.log('🔄 Previous start time:', lastActiveStartTime);
            console.log('🔄 New start time:', currentStartTime);
            // The local timer will automatically restart due to the dependency change
          }
          
          // WebSocket provides real-time updates, no drift detection needed
          
          setLastActiveTimerId(currentActiveTimerId);
          setLastActiveItemId(currentItemId);
          setLastActiveStartTime(currentStartTime);
        } else if (!activeTimer && lastActiveTimerId && supabaseOnly) {
          // Active timer stopped — clear sub-cue secondary only; Op Timer stays
          console.log('🔄 Active timer stopped - stopping secondary timer and drift detection');
          setHybridTimerData(prev => ({
            ...prev,
            secondaryTimer: null,
          }));
          
          // WebSocket provides real-time updates, no drift detection cleanup needed
          
          setLastActiveTimerId(null);
          setLastActiveItemId(null);
          setLastActiveStartTime(null);
        }
      } catch (error) {
        console.error('❌ Error loading active timer:', error);
      } finally {
        loadInFlight = false;
      }
    };

    // Load initial data once
    loadActiveTimer();

    // Set up WebSocket connection for real-time timer updates
    const callbacks = {
      onServerTime: (data: any) => {
        // Sync client clock with server clock
        const serverTime = new Date(data.serverTime).getTime();
        const clientTime = new Date().getTime();
        const offset = serverTime - clientTime;
        setClockOffset(offset);
        console.log('🕐 Clock: Clock sync:', {
          serverTime: data.serverTime,
          clientTime: new Date().toISOString(),
          offsetMs: offset,
          offsetSeconds: Math.floor(offset / 1000)
        });
      },
      onTimerUpdated: (data: any) => {
        console.log('🔍 [CLOCK DEBUG] ===== WebSocket onTimerUpdated =====');
        console.log('🔍 [CLOCK DEBUG] Received data:', data);
        console.log('🔍 [CLOCK DEBUG] Event ID check:', { received: data?.event_id, expected: eventId, match: data?.event_id === eventId });
        console.log('🔍 [CLOCK DEBUG] Timer state:', data?.timer_state);
        console.log('🔍 [CLOCK DEBUG] Is running:', data?.is_running);
        console.log('🔍 [CLOCK DEBUG] Started at:', data?.started_at);
        console.log('🔍 [CLOCK DEBUG] Duration:', data?.duration_seconds);
        
        if (data && data.event_id === eventId) {
          // Update timer data directly from WebSocket
          console.log('🔍 [CLOCK DEBUG] Updating hybridTimerData with WebSocket data');
          setHybridTimerData(prev => {
            console.log('🔍 [CLOCK DEBUG] Previous hybridTimerData:', prev);
            if (shouldKeepExistingRunningTimer(prev?.activeTimer, data)) {
              return prev;
            }
            let activeTimer = data;
            if (shouldRejectResolumeAlignReset(prev?.activeTimer, data, clockOffset)) {
              activeTimer = { ...data, started_at: prev!.activeTimer!.started_at };
            }
            const newData = {
              ...prev,
              activeTimer
            };
            console.log('🔍 [CLOCK DEBUG] New hybridTimerData:', newData);
            return newData;
          });
          console.log('✅ Clock: Timer updated via WebSocket');
        } else {
          console.log('⚠️ Clock: Timer update ignored - event ID mismatch or no data');
        }
      },
      onActiveTimersUpdated: (data: any) => {
        console.log('🔍 [CLOCK DEBUG] ===== WebSocket onActiveTimersUpdated =====');
        console.log('🔍 [CLOCK DEBUG] Raw data received:', data);
        
        // Handle array format (from server broadcast)
        let timerData = data;
        if (Array.isArray(data) && data.length > 0) {
          timerData =
            data.find((t: any) => t?.timer_state === 'running' || t?.is_running === true) ||
            data[0];
          console.log('🔍 [CLOCK DEBUG] Extracted timer from array:', timerData);
        }
        
        console.log('🔍 [CLOCK DEBUG] Event ID check:', { received: timerData?.event_id, expected: eventId, match: timerData?.event_id === eventId });
        console.log('🔍 [CLOCK DEBUG] Timer state:', timerData?.timer_state);
        console.log('🔍 [CLOCK DEBUG] Is active:', timerData?.is_active);
        console.log('🔍 [CLOCK DEBUG] Is running:', timerData?.is_running);
        
        if (timerData && timerData.event_id === eventId) {
          // Check if timer is stopped
          if (timerData.timer_state === 'stopped' || timerData.is_active === false) {
            console.log('🔍 [CLOCK DEBUG] Timer is stopped - clearing timer data');
            // Clear timer data when stopped
            setHybridTimerData(prev => ({
              ...prev,
              activeTimer: null
            }));
            console.log('✅ Clock: Timer stopped via WebSocket - cleared timer data');
          } else {
            console.log('🔍 [CLOCK DEBUG] Timer is active - updating hybridTimerData');
            // Update timer data directly from WebSocket
            setHybridTimerData(prev => {
              if (shouldKeepExistingRunningTimer(prev?.activeTimer, timerData)) {
                return prev;
              }
              let activeTimer = timerData;
              if (shouldRejectResolumeAlignReset(prev?.activeTimer, timerData, clockOffset)) {
                activeTimer = { ...timerData, started_at: prev!.activeTimer!.started_at };
              }
              return { ...prev, activeTimer };
            });
            console.log('✅ Clock: Active timer updated via WebSocket');
          }
        } else {
          console.log('⚠️ Clock: Active timers update ignored - event ID mismatch or no data');
        }
      },
      onTimerStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket timer stopped:', data);
        if (data && data.event_id === eventId) {
          // Clear timer data when stopped
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('✅ Clock: Timer cleared via WebSocket');
        }
      },
      onTimersStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket all timers stopped:', data);
        if (data && data.event_id === eventId) {
          // Clear timer data when all stopped
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('✅ Clock: All timers cleared via WebSocket');
        }
      },
      onSubCueTimerStarted: (data: any) => {
        console.log('🔄 Clock: WebSocket sub-cue timer started:', data);
        if (data && data.event_id === eventId) {
          setHybridTimerData(prev => {
            const enriched = enrichSubCueTimer(data);
            let secondaryTimer = enriched;
            if (shouldRejectResolumeAlignReset(prev?.secondaryTimer, enriched, clockOffset)) {
              secondaryTimer = { ...enriched, started_at: prev!.secondaryTimer!.started_at };
              console.log('🎬 Clock: Ignoring Resolume sub-cue align that reset countdown to full clip');
            }
            return { ...prev, secondaryTimer };
          });
          console.log('✅ Clock: Sub-cue timer started via WebSocket:', data);
        }
      },
      onSubCueTimerStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket sub-cue timer stopped:', data);
        if (data && sameEventId(data.event_id)) {
          // Clear sub-cue only — Op Timer is independent and keeps running
          setHybridTimerData((prev) => ({
            ...prev,
            secondaryTimer: null,
          }));
          console.log('✅ Clock: Sub-cue timer stopped via WebSocket');
        }
      },
      onOperatorCountdownUpdated: (data: any) => {
        if (!data) return;
        // WS room is already event-scoped; accept if event_id missing or matches
        if (data.event_id != null && !sameEventId(data.event_id)) return;
        console.log('⏱️ Clock: Op Timer updated via WebSocket', data);
        setHybridTimerData((prev) =>
          setOperatorCountdown(prev, mapOperatorCountdownRow(data))
        );
      },
      onOperatorCountdownCleared: (data: any) => {
        if (data?.event_id != null && !sameEventId(data.event_id)) return;
        console.log('⏱️ Clock: Op Timer cleared via WebSocket');
        setHybridTimerData((prev) => setOperatorCountdown(prev, null));
      },
      onTimerMessageUpdated: (data: any) => {
        console.log('📨 Clock: WebSocket timer message updated:', data);
        if (data && data.event_id === eventId) {
          // enabled:false must clear — otherwise a stale hybrid message stays on screen
          const next = data.enabled ? data : null;
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: next
          }));
          console.log('✅ Clock: Timer message updated via WebSocket:', next);
        }
      },
      onInitialSync: async () => {
        console.log('🔄 Clock: Performing initial sync for sub-cue timers and messages');
        try {
          // Load current sub-cue timers
          const subCueTimersResult = await DatabaseService.getActiveSubCueTimers(eventId);
          if (subCueTimersResult && subCueTimersResult.data && subCueTimersResult.data.length > 0) {
            // Find the first running sub-cue timer
            const runningSubCueTimer = subCueTimersResult.data.find(timer => 
              timer.timer_state === 'running' || timer.is_running === true
            );
            if (runningSubCueTimer) {
              setHybridTimerData(prev => ({
                ...prev,
                secondaryTimer: enrichSubCueTimer(runningSubCueTimer),
              }));
              console.log('✅ Clock: Initial sync - sub-cue timer loaded:', runningSubCueTimer);
            }
          }

          const operatorRow = await DatabaseService.getOperatorCountdown(eventId);
          setHybridTimerData((prev) =>
            setOperatorCountdown(prev, mapOperatorCountdownRow(operatorRow))
          );
          
          // Load current timer message (enabled only; null clears stale display)
          const timerMessage = await DatabaseService.getTimerMessage(eventId);
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: timerMessage || null
          }));
          console.log('✅ Clock: Initial sync - timer message:', timerMessage);
        } catch (error) {
          console.error('❌ Clock: Initial sync failed to load sub-cue timers and messages:', error);
        }
      },
      onConnectionChange: (connected: boolean) => {
        console.log('🔄 Clock: WebSocket connection status:', connected);
        if (connected) {
          // Reload timer when reconnected
          loadActiveTimer();
        }
      },
      onResetAllStates: (data: any) => {
        if (data?.event_id === eventId || !data?.event_id) {
          setHybridTimerData((prev) => ({
            ...prev,
            activeTimer: null,
            secondaryTimer: null,
            operatorCountdown: null,
          }));
          setLastActiveTimerId(null);
          setLastActiveItemId(null);
          setLastActiveStartTime(null);
        }
      }
    };

    socketClient.connect(eventId, callbacks, 'clock');

    const onCueCardsClockSync = (data: any) => {
      if (!data || String(data.eventId) !== String(eventId)) return;
      if (!data.enabled || !data.slide) {
        setCueClockFeed(null);
        return;
      }
      setTeleprompterClockFeed(null);
      setCueClockFeed({
        enabled: true,
        slide: data.slide,
        comments: Array.isArray(data.comments) ? data.comments : [],
      });
    };

    const onPptClockSync = (data: any) => {
      if (!data || String(data.eventId) !== String(eventId)) return;
      setPptClockFeed(parsePptClockSync(data));
    };

    const onTeleprompterClockSync = (data: any) => {
      if (!data || String(data.eventId) !== String(eventId)) return;
      if (!data.enabled) {
        setTeleprompterClockFeed(null);
        return;
      }
      setCueClockFeed(null);
      setTeleprompterClockFeed((prev) => {
        const nextSettings = data.settings || prev?.settings || {
          fontSize: 48,
          lineHeight: 1.4,
          textAlign: 'center' as const,
          textColor: '#FFFFFF',
          backgroundColor: '#000000',
        };
        return {
          enabled: true,
          scriptText:
            typeof data.scriptText === 'string' ? data.scriptText : prev?.scriptText || '',
          scrollPosition:
            typeof data.scrollPosition === 'number'
              ? data.scrollPosition
              : prev?.scrollPosition || 0,
          settings: nextSettings,
          guideLinePosition:
            typeof data.guideLinePosition === 'number'
              ? data.guideLinePosition
              : prev?.guideLinePosition ?? 50,
          comments: Array.isArray(data.comments)
            ? data.comments
            : prev?.comments || [],
          voiceIgnoreLines: Array.isArray(data.voiceIgnoreLines)
            ? data.voiceIgnoreLines
            : prev?.voiceIgnoreLines || [],
          scriptName:
            typeof data.scriptName === 'string'
              ? data.scriptName
              : prev?.scriptName,
          voiceHighlight:
            data.voiceHighlight !== undefined
              ? data.voiceHighlight
              : prev?.voiceHighlight ?? null,
        };
      });
    };

    const sock = socketClient.getSocket();
    sock?.on('cueCardsClockSync', onCueCardsClockSync);
    sock?.on('teleprompterClockSync', onTeleprompterClockSync);
    sock?.on('pptClockSync', onPptClockSync);

    // Re-register callbacks + refresh when the page becomes visible again.
    // Never disconnect here — display clocks must keep receiving messages while open
    // (including when another window has focus, or this window was briefly occluded).
    const refreshClockOnReturn = () => {
      if (document.hidden) return;
      console.log('🔄 Clock: Visible - re-registering callbacks and refreshing timer state');
      socketClient.connect(eventId, callbacks, 'clock');
      setCurrentTime(new Date());
      void loadActiveTimer();
      socketClient.getSocket()?.on('cueCardsClockSync', onCueCardsClockSync);
      socketClient.getSocket()?.on('teleprompterClockSync', onTeleprompterClockSync);
      socketClient.getSocket()?.on('pptClockSync', onPptClockSync);
    };
    document.addEventListener('visibilitychange', refreshClockOnReturn);

    return () => {
      console.log('🔄 Clock: Cleaning up WebSocket connection');
      document.removeEventListener('visibilitychange', refreshClockOnReturn);
      socketClient.getSocket()?.off('cueCardsClockSync', onCueCardsClockSync);
      socketClient.getSocket()?.off('teleprompterClockSync', onTeleprompterClockSync);
      socketClient.getSocket()?.off('pptClockSync', onPptClockSync);
      socketClient.disconnect(eventId, 'clock');
    };
  }, [eventId, networkEnabled]); // Removed supabaseOnly since it's always true in this component

  // Reset sim secondary clock when toggled on from page chrome
  useEffect(() => {
    if (!simSecondary) return;
    simSecondaryStartedAtRef.current = new Date(Date.now() - 45_000).toISOString();
    setSecondaryTimerUpdate((p) => p + 1);
  }, [simSecondary]);

  // Update secondary / operator ALT timer every second when in hybrid mode
  useEffect(() => {
    if (!supabaseOnly) return;
    const active =
      simSecondary ||
      !!hybridTimerData?.secondaryTimer?.is_running ||
      !!(
        hybridTimerData?.operatorCountdown?.is_active &&
        hybridTimerData?.operatorCountdown?.is_running
      );
    if (!active) return;

    return startSecondTicker(() => {
      setSecondaryTimerUpdate(prev => prev + 1);
    });
  }, [supabaseOnly, simSecondary, hybridTimerData?.secondaryTimer, hybridTimerData?.operatorCountdown]);

  // Poll Op Timer so Clock still picks it up if a WS handler was dropped
  useEffect(() => {
    if (!supabaseOnly || !eventId || !networkEnabled) return;
    let cancelled = false;

    const poll = async () => {
      try {
        const operatorRow = await DatabaseService.getOperatorCountdown(eventId);
        if (cancelled) return;
        setHybridTimerData((prev) => {
          const mapped = mapOperatorCountdownRow(operatorRow);
          const prevOp = prev?.operatorCountdown;
          if (
            (!mapped && !prevOp) ||
            (mapped &&
              prevOp &&
              mapped.started_at === prevOp.started_at &&
              mapped.duration_seconds === prevOp.duration_seconds &&
              mapped.cue_display === prevOp.cue_display &&
              mapped.is_running === prevOp.is_running &&
              mapped.is_active === prevOp.is_active)
          ) {
            return prev;
          }
          return setOperatorCountdown(prev, mapped);
        });
      } catch (err) {
        console.warn('⏱️ Clock: Op Timer poll failed', err);
      }
    };

    void poll();
    const id = window.setInterval(poll, 2000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [supabaseOnly, eventId, networkEnabled]);

  // REMOVED: Duplicate timer effect that was causing flickering
  // The timer progress effect above (lines 74-134) handles all timer updates

  // WebSocket provides real-time updates, no drift detection cleanup needed

  const formatTimeBody = (seconds: number) => {
    const absSeconds = Math.abs(seconds);
    const hours = Math.floor(absSeconds / 3600);
    const minutes = Math.floor((absSeconds % 3600) / 60);
    const secs = Math.floor(absSeconds % 60);
    if (hours === 0) {
      return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Helper function to format time (same as RunOfShowPage) - handles negative values
  const formatTime = (seconds: number) => {
    const sign = overtimeSignPrefix(seconds, overtimeSign);
    return `${sign}${formatTimeBody(seconds)}`;
  };

  const renderSignedTime = (seconds: number, className?: string) => (
    <OvertimeClockText
      seconds={seconds}
      body={formatTimeBody(seconds)}
      sign={overtimeSign}
      className={className}
    />
  );

  // Format time of day
  const formatTimeOfDay = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Get remaining time (same logic as RunOfShowPage) - allow negative values except Resolume sync
  const getRemainingTime = () => {
    const progress = timerProgress;
    const remaining = progress.total - progress.elapsed;

    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show full duration
        if (simOvertime) return -(Math.abs(progress.total) || 90);
        return progress.total;
      }
    }

    if (simOvertime) {
      return remaining < 0 ? remaining : -(Math.abs(remaining) || 90);
    }
    return remaining;
  };

  // Get elapsed time for count-up display
  const getElapsedTime = () => {
    const progress = timerProgress;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return 0;
      }
    }
    return progress.elapsed;
  };

  // Count-up: bar fills as elapsed increases (cap at 100%); overtime = red
  const getCountUpBarPercentage = () => {
    const progress = timerProgress;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return 0;
      }
    }
    if (progress.total <= 0) return 0;
    return Math.min(100, (progress.elapsed / progress.total) * 100);
  };

  const getCountUpProgressBarColor = () => {
    const progress = timerProgress;
    const elapsed = progress.elapsed;
    const remaining = progress.total - progress.elapsed;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return countdownColorForRemaining(0, { isRunning: false, mode: countdownColorMode });
      }
    }
    if (usePreshowRainbow) {
      return countdownColorForRemaining(remaining, {
        mode: countdownColorMode,
        rainbow: true,
      });
    }
    if (elapsed > progress.total) return countdownColorForRemaining(0, { mode: countdownColorMode });
    return countdownColorForRemaining(remaining, { mode: countdownColorMode });
  };

  // Get remaining percentage for progress bar (same logic as RunOfShowPage)
  const getRemainingPercentage = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show 100% (full bar)
        return 100;
      }
    }
    
    return progress.total > 0 ? (remainingSeconds / progress.total) * 100 : 0;
  };

  // Get progress bar color based on remaining time (same logic as RunOfShowPage)
  const getProgressBarColor = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return countdownColorForRemaining(0, { isRunning: false, mode: countdownColorMode });
      }
    }

    if (usePreshowRainbow) {
      return countdownColorForRemaining(remainingSeconds, {
        mode: countdownColorMode,
        rainbow: true,
      });
    }
    
    return countdownColorForRemaining(remainingSeconds, { mode: countdownColorMode });
  };

  // Active cue timer mode: timeOfDay = swap + progress bar; todOnly = time of day only, no progress bar or time remaining
  const activeItemId = hybridTimerData?.activeTimer?.item_id;
  const activeItem = scheduleItems?.length && activeItemId != null
    ? scheduleItems.find((i: any) => i.id === activeItemId || String(i.id) === String(activeItemId) || i.id == activeItemId)
    : null;
  const timerDisplayValue = activeItem && (activeItem.timerDisplay ?? activeItem.timer_display ?? '');
  const normalizedTimer = typeof timerDisplayValue === 'string' ? timerDisplayValue.replace(/_/g, '').toLowerCase() : '';
  const isTodOnly = normalizedTimer === 'todonly';
  const useTodOnly = !!isTodOnly;
  const useCountUp = normalizedTimer === 'countup';
  const useTimeOfDay = !!(activeItem && (
    normalizedTimer === 'timeofday' ||
    normalizedTimer === 'todonly' ||
    activeItem.useTimeOfDay === true
  ));
  const showTimeRemainingAndBar = useTimeOfDay && !useTodOnly; // Time Of Day: countdown top-left + progress bar; TOD Only: hide both (minimal = large time of day only)
  const elapsedForDisplay = getElapsedTime();
  const isOvertimeCountUp =
    simOvertime ||
    (useCountUp && timerProgress.total > 0 && elapsedForDisplay > timerProgress.total);
  const overtimeAmount = isOvertimeCountUp
    ? simOvertime && !(useCountUp && elapsedForDisplay > timerProgress.total)
      ? 90
      : elapsedForDisplay - timerProgress.total
    : 0;
  const hybridForAlt = {
    secondaryTimer:
      (supabaseOnly ? hybridTimerData?.secondaryTimer : secondaryTimer) ||
      hybridTimerData?.secondaryTimer,
    operatorCountdown: hybridTimerData?.operatorCountdown,
  };
  // Large ALT: Op wins; indented alone uses this slot too
  const liveSecondarySubTimer = enrichSubCueTimer(resolveDisplaySecondaryTimer(hybridForAlt));
  const dsmSimSecondaryTimer = simSecondary
    ? enrichSubCueTimer({
        is_running: true,
        is_active: true,
        started_at: simSecondaryStartedAtRef.current,
        created_at: simSecondaryStartedAtRef.current,
        duration_seconds: 180,
        duration: 180,
        cue: '12',
        cue_display: 'CUE 12',
        segment_name: 'Secondary Sim',
        item_id: -9001,
      })
    : null;
  const secondarySubTimer = dsmSimSecondaryTimer || liveSecondarySubTimer;
  const indentedSubTimer = enrichSubCueTimer(getLiveIndentedSubTimer(hybridForAlt));
  // Op + indented both live → main+indented go small (like messages); Op stays large center
  const dualAltLayout = hasDualAltLayout(hybridForAlt);
  const isOpAlt = isOperatorAltTimer(secondarySubTimer);
  const secondaryDisplayColor = isOpAlt
    ? 'text-violet-400'
    : secondarySubTimer && isResolumeSynced(secondarySubTimer)
      ? 'text-yellow-300'
      : 'text-orange-400';
  const indentedDisplayColor =
    indentedSubTimer && isResolumeSynced(indentedSubTimer) ? 'text-yellow-300' : 'text-orange-400';
  const secondarySyncLabel = getExternalSyncLabel(secondarySubTimer).toUpperCase();
  const secondaryResolumeLabel =
    !isOpAlt && secondarySubTimer
      ? isResolumeSynced(secondarySubTimer)
        ? ` · ${secondarySyncLabel}`
        : isResolumeArmed(secondarySubTimer)
          ? ` · ${secondarySyncLabel}`
          : ''
      : '';
  const secondaryStatusPrefix =
    !isOpAlt && secondarySubTimer && isResolumeSynced(secondarySubTimer) && secondarySubTimer.is_running
      ? `RUNNING · ${secondarySyncLabel} - `
      : !isOpAlt && secondarySubTimer && isResolumeArmed(secondarySubTimer)
        ? `LOADED · ${secondarySyncLabel} - `
        : '';

  /** Sub-cues hide at 0; Op Timer keeps counting until operator clears it. */
  const secondaryStillVisible = (timer: any): boolean => {
    if (!timer?.is_running) return false;
    if (isOperatorAltTimer(timer)) return true;
    if (timer.is_active) {
      const startedAt = new Date(timer.started_at || timer.created_at);
      const elapsed = Math.floor((Date.now() + clockOffset - startedAt.getTime()) / 1000);
      const totalDuration = timer.duration_seconds || timer.duration || 0;
      return totalDuration - elapsed > 0;
    }
    return true;
  };

  const secondaryRemainingSigned = (timer: any): number => {
    if (!timer) return 0;
    if (timer.is_running && (timer.is_active || isOperatorAltTimer(timer))) {
      const startedAt = new Date(timer.started_at || timer.created_at);
      const elapsed = Math.floor((Date.now() + clockOffset - startedAt.getTime()) / 1000);
      const totalDuration = timer.duration_seconds || timer.duration || 0;
      const rem = totalDuration - elapsed;
      return isOperatorAltTimer(timer) ? rem : Math.max(0, rem);
    }
    return timer.duration_seconds || timer.duration || 0;
  };

  // Prefer any currently enabled message; Pre Show uses OVER TIME-style label instead of overlay
  const activeStageMessage =
    [hybridTimerData?.timerMessage, supabaseMessage].find(
      (m) => m?.enabled && !isPreshowTimerMessage(m)
    ) ?? null;
  const cueClockActive = !!(cueClockFeed?.enabled && cueClockFeed.slide);
  const teleprompterClockActive = !!(
    teleprompterClockFeed?.enabled && teleprompterClockFeed.scriptText
  );
  const pptClockActive = !!pptClockFeed?.enabled;
  const mediaFeedActive = cueClockActive || teleprompterClockActive || pptClockActive;
  const stageFeedActive = mediaFeedActive;
  /** Cue/tele/PPT feed OR DSM forced 16:9 reference frame */
  const show16x9Frame = mediaFeedActive || force16x9Ref;
  /** Message / cue-card crowding (not Op+indented dual — that keeps Op large) */
  const layoutCrowded = !!activeStageMessage || show16x9Frame;
  /** Main (+ indented) go small: message crowding OR Op+indented dual */
  const layoutSmallMain = layoutCrowded || dualAltLayout;
  // Timers under the in-stage 16:9 feed (page itself is letterboxed 16:9)
  const crowdedTimerBottom = show16x9Frame ? 'bottom-5' : 'bottom-20';
  /** Under 16:9 band — DSM readable sizes. Off 16:9 → original Clock large sizes. */
  const dsmCrowdedTimeClass = 'text-[6.25rem] md:text-[7.25rem] lg:text-[8.25rem]';
  const dsmCrowdedSideTimeClass = 'text-[4.75rem] md:text-[5.75rem] lg:text-[6.75rem]';
  const dsmCrowdedLabelClass = 'text-2xl md:text-3xl lg:text-4xl';
  /** Slim OVER TIME — sized for secondary stack; shared Y for secondary + solo */
  const dsmCrowdedOvertimeClass = 'text-xl md:text-2xl lg:text-3xl leading-none';
  // bottom-5 + side bar (mt-1.5+h-3.5) + side digits (lg) + gap — matches secondary stack
  const dsmSlimOvertimeBottomClass = 'bottom-[9.5rem]';
  // % width fails here — parent shrink-wraps to the timer digits; use design-canvas px
  const dsmCrowdedBarClass = show16x9Frame
    ? 'w-[1280px] h-4'
    : 'w-full max-w-2xl h-2';
  const dsmCrowdedSideBarClass = show16x9Frame
    ? 'w-[28rem] mx-auto mt-1.5 h-3.5'
    : 'w-48 mx-auto mt-2 h-2.5';
  /** 16:9 off → same full-viewport flex shell as original Clock (large timer centering). */
  const classicClockShell = !show16x9Frame;
  // Classic Clock hero sizes when 16:9 DSM frame is off
  const dsmHeroMmSs = show16x9Frame
    ? 'text-[4.5rem] md:text-[5.5rem] lg:text-[6.5rem]'
    : 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]';
  const dsmHeroHhMmSs = show16x9Frame
    ? 'text-[3.5rem] md:text-[4.25rem] lg:text-[5rem]'
    : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';
  const dsmHeroTod = show16x9Frame
    ? 'text-[3.5rem] md:text-[4.5rem] lg:text-[5.5rem]'
    : 'text-[8rem] md:text-[9.5rem] lg:text-[11rem]';
  const dsmHeroLabel = show16x9Frame
    ? 'text-2xl md:text-3xl leading-none'
    : 'text-5xl leading-none';
  const hasLargeAlt = secondaryStillVisible(secondarySubTimer);
  const hasIndentedSmall = dualAltLayout && secondaryStillVisible(indentedSubTimer);
  const slimHasSecondary =
    (hasLargeAlt || hasIndentedSmall) && layoutSmallMain && (layoutCrowded || dualAltLayout);
  const showSlimOvertimeLabel =
    show16x9Frame &&
    !useTodOnly &&
    (useCountUp ? isOvertimeCountUp : getRemainingTime() < 0);

  const stageW = DSM_DESIGN_W * stageScale;
  const stageH = DSM_DESIGN_H * stageScale;

  return (
    <div
      ref={stageOuterRef}
      className={
        classicClockShell
          ? 'fixed inset-0 z-0 bg-black text-white overflow-hidden flex flex-col items-center justify-center'
          : 'fixed inset-0 z-0 flex items-center justify-center overflow-hidden bg-black text-white'
      }
      style={{ padding: 0, margin: 0 }}
    >
      {/* 16:9 ON: scaled 1920×1080 board. OFF: classic Clock full-viewport flex shell. */}
      <div
        className={
          classicClockShell
            ? 'relative flex flex-col flex-1 w-full h-full min-h-0 overflow-hidden bg-black'
            : 'relative overflow-hidden bg-black'
        }
        style={
          classicClockShell
            ? undefined
            : {
                width: stageW,
                height: stageH,
                outline: !isFullScreen ? '1px solid rgba(251,191,36,0.85)' : undefined,
                outlineOffset: 0,
              }
        }
        title={!classicClockShell && !isFullScreen ? '16:9 master board (windowed)' : undefined}
      >
        <div
          className={
            classicClockShell
              ? 'relative flex flex-col flex-1 w-full h-full min-h-0 overflow-hidden bg-black text-white'
              : 'absolute left-0 top-0 overflow-hidden bg-black text-white'
          }
          style={
            classicClockShell
              ? undefined
              : {
                  width: DSM_DESIGN_W,
                  height: DSM_DESIGN_H,
                  transform: `scale(${stageScale})`,
                  transformOrigin: 'top left',
                }
          }
        >
      {/* Thin master 16:9 outline when windowed + 16:9 mode */}
      {!classicClockShell && !isFullScreen ? (
        <div
          className="pointer-events-none absolute inset-0 z-[250]"
          style={{
            boxSizing: 'border-box',
            border: '2px solid rgba(251,191,36,0.9)',
          }}
          aria-hidden
        />
      ) : null}

      {/* Top Left: hide when cue/teleprompter feed is filling the stage */}
      {!useTodOnly && !show16x9Frame && (
        <div className="absolute top-10 left-10 text-3xl font-mono text-white">
          {showTimeRemainingAndBar ? (
            <>
              <div className="text-slate-400 text-lg mb-1">TIME REMAINING</div>
              <div
                className={`text-white ${usePreshowRainbow ? 'ros-rainbow-text' : ''}`}
                style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
              >
                {renderSignedTime(getRemainingTime())}
              </div>
            </>
          ) : useCountUp ? (
            <>
              <div className="text-slate-400 text-lg mb-1">CURRENT TIME ELAPSED</div>
              <div className="text-white">
                {formatTimeOfDay(currentTime)}
              </div>
            </>
          ) : (
            <>
              <div className="text-slate-400 text-lg mb-1">CURRENT TIME</div>
              <div className="text-white">
                {formatTimeOfDay(currentTime)}
              </div>
            </>
          )}
        </div>
      )}

      {/* Current Running CUE - Top Right (hidden while stage feed is on clock) */}
      {!show16x9Frame && (
      <div className="fixed top-10 right-10 text-3xl font-mono text-white z-50 w-80 text-right">
        <div className="text-slate-400 text-lg mb-1">CURRENT CUE</div>
        <div className="text-white flex items-center justify-end gap-3 whitespace-nowrap">
          <span>
            {(() => {
              if (supabaseOnly) {
                if (hybridTimerData?.activeTimer) {
                const activeTimer = hybridTimerData.activeTimer;
                const lastLoadedCue = hybridTimerData?.lastLoadedCue;
                const cueData = hybridTimerData?.cueData;
                const liveCue = resolveLiveCueLabel({
                  item: activeCue || cueData,
                  timer: activeTimer,
                });
                if (liveCue === 'DELAY') return 'DELAY';
                if (liveCue && liveCue !== 'CUE') return liveCue;
                
                // Try CUE data from active timer cue_is column first
                if (activeTimer.cue_is && !/^CUE\s*\d{5,}$/i.test(String(activeTimer.cue_is))) {
                  return activeTimer.cue_is;
                }
                
                // Try CUE data from schedule/items table second
                if (cueData) {
                  console.log('🔍 CUE data structure:', cueData);
                  console.log('🔍 CUE data fields:', Object.keys(cueData));
                  
                  const cueDisplay = cueData.customFields?.cue || cueData.cue || cueData.cue_display || cueData.name || cueData.title;
                  const segmentName = cueData.segmentName || cueData.segment_name || cueData.segment;
                  
                  if (cueDisplay) {
                    console.log('✅ Found CUE display:', cueDisplay);
                    return cueDisplay;
                  }
                }
                
                // Try active timer other fields
                const cueDisplay = activeTimer.cue_display || activeTimer.cue;
                const segmentName = activeTimer.segment_name || activeTimer.segmentName;
                
                if (cueDisplay) {
                  return cueDisplay;
                }
                
                // Fallback to last loaded cue
                if (lastLoadedCue) {
                  const lastCueDisplay = lastLoadedCue.cue_display || lastLoadedCue.cue;
                  const lastSegmentName = lastLoadedCue.segment_name || lastLoadedCue.segmentName;
                  if (lastCueDisplay) {
                    return lastCueDisplay;
                  }
                }
                
                if (liveCue) return liveCue;
                
                return 'No CUE';
              } else {
                  // No active timer - show "No Cue"
                  return 'No Cue';
                }
              } else {
                // Clock always runs in WebSocket-only mode
                return 'No CUE';
              }
            })()}
          </span>
          {/* Drift Status Indicator */}
          {itemId && (
            <DriftStatusIndicator 
              itemId={itemId} 
              className="flex-shrink-0"
            />
          )}
        </div>
      </div>
      )}

      {/* Timer Status Indicator - Bottom Left */}
      {!isFullScreen && supabaseOnly && hybridTimerData?.activeTimer && (
        <div className="absolute bottom-10 left-10 text-center">
          <div className={`text-lg font-bold px-4 py-2 rounded-lg ${
            hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
              ? 'bg-green-600 text-white'
              : 'bg-gray-600 text-white'
          }`}>
            {hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
              ? '⏱️ TIMER RUNNING'
              : '⏸️ TIMER LOADED'
            }
          </div>
        </div>
      )}

      {/* Full Screen Button - Hidden when in full screen */}
      {!isFullScreen && (
        <div className="absolute top-10 left-1/2 transform -translate-x-1/2 flex gap-3 z-50">
        <button
          onClick={() => {
            if (document.documentElement.requestFullscreen) {
              document.documentElement.requestFullscreen();
            }
          }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-lg transition-colors"
        >
          FULL SCREEN
        </button>
        {!isFullScreen && (
          <button
            className="px-4 py-2 rounded-lg font-bold text-lg bg-purple-600 text-white cursor-default"
            disabled
          >
            WEBSOCKET ONLY
          </button>
        )}
        </div>
      )}


      {/* Cue Cards / Teleprompter / PPT / DSM 16:9 reference — timers stay along bottom */}
      {show16x9Frame ? (
        <div
          className="absolute inset-x-0 z-20 grid place-items-start justify-items-center px-2"
          style={{
            top: '0.5rem',
            // Page is already 16:9 — reserve bottom of the stage for timers
            bottom: activeStageMessage ? '26%' : '18%',
            containerType: 'size',
          }}
        >
          <div
            className={`relative overflow-hidden bg-black shadow-2xl ${
              mediaFeedActive ? 'border-2 border-white/80' : 'border-2 border-amber-400/90'
            }`}
            style={{
              aspectRatio: '16 / 9',
              width: 'min(100cqw, calc(100cqh * 16 / 9))',
              height: 'min(100cqh, calc(100cqw * 9 / 16))',
            }}
          >
            {cueClockActive && cueClockFeed?.slide ? (
              <CueCardClockOverlay
                slide={cueClockFeed.slide}
                comments={cueClockFeed.comments}
                className="h-full w-full"
              />
            ) : null}
            {teleprompterClockActive && teleprompterClockFeed ? (
              <TeleprompterClockOverlay
                feed={teleprompterClockFeed}
                className="h-full w-full"
              />
            ) : null}
            {!cueClockActive && !teleprompterClockActive && pptClockActive && pptClockFeed ? (
              <PptClockOverlay feed={pptClockFeed} className="h-full w-full" />
            ) : null}
            {!mediaFeedActive && force16x9Ref ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950">
                <div
                  className="pointer-events-none absolute inset-0 opacity-40"
                  style={{
                    backgroundImage:
                      'linear-gradient(to right, rgba(251,191,36,0.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(251,191,36,0.25) 1px, transparent 1px)',
                    backgroundSize: '10% 10%',
                  }}
                />
                <div className="relative z-10 text-center text-amber-300">
                  <div className="text-3xl md:text-4xl font-bold tracking-[0.35em]">16 : 9</div>
                  <div className="mt-2 text-sm md:text-base text-amber-200/80">DSM reference frame</div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      {show16x9Frame && activeStageMessage ? (
        <div className="absolute bottom-[16%] left-1/2 z-30 w-[min(90vw,56rem)] -translate-x-1/2 rounded-lg border-2 border-white/80 bg-black/70 px-6 py-3 text-center text-2xl font-bold text-white md:text-3xl">
          {activeStageMessage.message}
        </div>
      ) : null}

      {/* Message Display */}
      {activeStageMessage && !show16x9Frame && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ transform: 'translateY(-40px)' }}>
          <div 
            className={`font-bold text-white bg-black bg-opacity-50 rounded-lg border-4 border-white text-center flex items-center justify-center ${
              activeStageMessage.flashing ? 'ros-timer-message-flash' : ''
            }`}
            style={{
              width: '80vw',
              minHeight: '50vh',
              maxHeight: '70vh',
              lineHeight: '1.2',
              whiteSpace: 'pre-line',
              overflow: 'visible',
              padding: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              wordWrap: 'break-word'
            }}
          >
            {(() => {
              const displayMessage = activeStageMessage.message || '';
              // Break long messages into multiple lines
              const words = displayMessage.split(' ');
              let formattedMessage;
              let lineCount;
              
              if (words.length <= 3) {
                formattedMessage = displayMessage; // Keep short messages on one line
                lineCount = 1;
              } else if (words.length <= 6) {
                // Break into 2 lines
                const mid = Math.ceil(words.length / 2);
                formattedMessage = words.slice(0, mid).join(' ') + '\n' + words.slice(mid).join(' ');
                lineCount = 2;
              } else if (words.length <= 10) {
                // Break into 3 lines
                const third = Math.ceil(words.length / 3);
                formattedMessage = words.slice(0, third).join(' ') + '\n' + 
                       words.slice(third, third * 2).join(' ') + '\n' + 
                       words.slice(third * 2).join(' ');
                lineCount = 3;
              } else {
                // Break into 4 lines for very long messages
                const quarter = Math.ceil(words.length / 4);
                formattedMessage = words.slice(0, quarter).join(' ') + '\n' + 
                       words.slice(quarter, quarter * 2).join(' ') + '\n' + 
                       words.slice(quarter * 2, quarter * 3).join(' ') + '\n' + 
                       words.slice(quarter * 3).join(' ');
                lineCount = 4;
              }
              
              // Calculate font size based on message length and line count
              // Account for descenders (g, j, p, q, y) that hang below baseline
              let fontSize;
              const hasDescenders = /[gjpqy]/.test(displayMessage.toLowerCase());
              
              if (words.length <= 3) {
                fontSize = hasDescenders ? 'clamp(3rem, 12vw, 16rem)' : 'clamp(3.5rem, 13.5vw, 18rem)';
              } else if (words.length <= 6) {
                fontSize = hasDescenders ? 'clamp(1.9rem, 8vw, 12rem)' : 'clamp(2.25rem, 9vw, 13.5rem)';
              } else if (words.length <= 10) {
                fontSize = hasDescenders ? 'clamp(1.4rem, 6vw, 9rem)' : 'clamp(1.6rem, 7vw, 10.5rem)';
              } else {
                fontSize = hasDescenders ? 'clamp(0.9rem, 4vw, 6rem)' : 'clamp(1.1rem, 5vw, 7rem)';
              }
              
              return (
                <div style={{ fontSize }}>
                  {formattedMessage}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Secondary Timer Display - Large ALT (Op preferred, else indented). Hidden only for stage messages. */}
      {(() => {
        if (supabaseOnly) {
          if (!hasLargeAlt) return false;
          // Stage message / cue-card feed — use compact bottom layout instead
          if (layoutCrowded) return false;
          return true;
        }
        return false;
      })() && (
        (() => {
          const hasMessage = supabaseOnly
            ? !!(supabaseMessage && supabaseMessage.enabled)
            : !!(messageEnabled && message) || !!(supabaseMessage && supabaseMessage.enabled);

          const labelNode = (() => {
            const currentSecondaryTimer = supabaseOnly ? secondarySubTimer : secondaryTimer;
            if (!currentSecondaryTimer) return null;
            if (!supabaseOnly) return <span>ALT</span>;
            return (
              <AltTimerBadge
                timer={currentSecondaryTimer}
                scheduleItems={scheduleItems}
                statusPrefix={secondaryStatusPrefix}
                resolumeSuffix={secondaryResolumeLabel}
              />
            );
          })();

          const remainingSeconds = (() => {
            const currentSecondaryTimer = supabaseOnly ? secondarySubTimer : secondaryTimer;
            if (!currentSecondaryTimer) return 0;
            const _ = secondaryTimerUpdate;
            return secondaryRemainingSigned(currentSecondaryTimer);
          })();

          const formatSecondaryBody = (remaining: number) => {
            const absRemaining = Math.abs(remaining);
            const hours = Math.floor(absRemaining / 3600);
            const minutes = Math.floor((absRemaining % 3600) / 60);
            const seconds = absRemaining % 60;
            if (hours === 0) {
              return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
          };
          const formatSecondary = (remaining: number) => (
            <OvertimeClockText
              seconds={remaining}
              body={formatSecondaryBody(remaining)}
              sign={overtimeSign}
            />
          );

          const hours = Math.floor(Math.abs(remainingSeconds) / 3600);
          const largeTimeClass = hours === 0 ? dsmHeroMmSs : dsmHeroHhMmSs;

          // Large (no message): same flex shell + progress-bar spacer as main timer → same Y axis
          if (!hasMessage) {
            return (
              <div className="flex-1 flex flex-col items-center justify-center animate-in fade-in duration-500">
                <div
                  className={`mb-[-50px] text-center ${secondaryDisplayColor} ${
                    show16x9Frame ? 'text-sm md:text-base lg:text-lg' : 'text-xl md:text-2xl lg:text-3xl'
                  } font-bold whitespace-nowrap`}
                  style={{ lineHeight: '1.2' }}
                >
                  {labelNode}
                </div>
                <div className="text-center">
                  <div
                    className={`${secondaryDisplayColor} font-mono font-bold ${largeTimeClass}`}
                    style={{ lineHeight: '1' }}
                  >
                    {formatSecondary(remainingSeconds)}
                  </div>
                </div>
                {/* Same height as main timer progress bar so digits share the same Y */}
                <div className="w-full max-w-5xl mt-0 h-8" aria-hidden />
              </div>
            );
          }

          // With message / 16:9: compact secondary in lower area (DSM: still readable)
          return (
            <div className={`absolute ${crowdedTimerBottom} right-1/3 transform translate-x-1/2 flex flex-col items-center animate-in fade-in duration-500`}>
              <div
                className={`absolute left-1/2 -translate-x-1/2 ${secondaryDisplayColor} ${dsmCrowdedLabelClass} font-bold whitespace-nowrap`}
                style={{ lineHeight: '1.2', bottom: 'calc(100% + 0.35rem)' }}
              >
                {labelNode}
              </div>
              <div className={`${secondaryDisplayColor} font-mono font-bold ${dsmCrowdedSideTimeClass}`} style={{ lineHeight: '1' }}>
                {formatSecondary(remainingSeconds)}
              </div>
            </div>
          );
        })()
      )}

      {/* Slim 16:9 OVER TIME — same Y for secondary (left) and solo (center) */}
      {showSlimOvertimeLabel && (
        <div
          className={`absolute z-30 ${dsmSlimOvertimeBottomClass} -translate-x-1/2 font-bold text-red-500 ${dsmCrowdedOvertimeClass} whitespace-nowrap ${
            slimHasSecondary ? 'left-[18%]' : 'left-1/2'
          }`}
        >
          OVER TIME
        </div>
      )}

      {/* Main Timer Layout - Small when message OR Op+indented dual (or large ALT alone pushes main down elsewhere) */}
      {(() => {
        const hasMessage = layoutCrowded;
        // Message crowding OR Op+indented dual: main goes small left
        return (hasLargeAlt || hasIndentedSmall) && layoutSmallMain && (hasMessage || dualAltLayout);
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-[18%] -translate-x-1/2 min-w-[14rem]`}>
          {/* Non-16:9: overtime stays in-flow above side digits */}
          {!show16x9Frame && getRemainingTime() < 0 && (
            <div className="mb-1">
              <div className={`font-bold text-red-500 ${dsmCrowdedOvertimeClass} whitespace-nowrap`}>
                OVER TIME
              </div>
            </div>
          )}
          
          <div 
            className={`font-mono font-bold transition-all duration-500 ease-in-out ${dsmCrowdedSideTimeClass} leading-none ${
              usePreshowRainbow ? 'ros-rainbow-text' : ''
            }`}
            style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
          >
            {renderSignedTime(getRemainingTime())}
          </div>
          {/* Main progress bar under small main timer */}
          <div className={`${dsmCrowdedSideBarClass} bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative`}>
            <div
              className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                usePreshowRainbow ? 'ros-rainbow-fill' : ''
              }`}
              style={{
                width: `${Math.min(100, Math.max(0, getRemainingPercentage()))}%`,
                ...(usePreshowRainbow ? {} : { background: getProgressBarColor() }),
              }}
            />
          </div>
        </div>
      )}

      {/* Small indented / secondary — right side when message OR when Op is large + indented also live */}
      {(() => {
        if (layoutCrowded && hasLargeAlt && !dualAltLayout) {
          // Message mode with a single ALT (op or indented) — show it small right
          return true;
        }
        // Op large center + indented small right
        return hasIndentedSmall && !layoutCrowded;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} right-[18%] translate-x-1/2 min-w-[14rem] ${
          dualAltLayout ? indentedDisplayColor : secondaryDisplayColor
        }`}>
          {/* Small secondary: ALT + CUE only — same scale as small main */}
          <div className={`mb-1 ${dsmCrowdedLabelClass} font-bold leading-none`}>
            <AltTimerBadge
              timer={dualAltLayout ? indentedSubTimer : secondarySubTimer}
              scheduleItems={scheduleItems}
              cueOnly
            />
          </div>
          
          {/* Sub-cue Countdown Timer */}
          <div className={`font-mono ${dsmCrowdedSideTimeClass} font-bold leading-none`}>
            {(() => {
              const _ = secondaryTimerUpdate;
              const t = dualAltLayout ? indentedSubTimer : secondarySubTimer;
              const remaining = secondaryRemainingSigned(t);
              const absRemaining = Math.abs(remaining);
              const hours = Math.floor(absRemaining / 3600);
              const minutes = Math.floor((absRemaining % 3600) / 60);
              const seconds = absRemaining % 60;
              const body = hours > 0
                ? `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
                : `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
              return <OvertimeClockText seconds={remaining} body={body} sign={overtimeSign} />;
            })()}
          </div>
          {/* Secondary progress bar under small alt timer */}
          <div className={`${dsmCrowdedSideBarClass} bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative`}>
            <div
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{
                width: `${(() => {
                  const t = dualAltLayout ? indentedSubTimer : secondarySubTimer;
                  if (!t) return 0;
                  const _ = secondaryTimerUpdate;
                  const total = t.duration_seconds || t.duration || 0;
                  if (total <= 0) return 0;
                  const elapsed = calculateElapsed(t.started_at || t.created_at);
                  return Math.min(100, Math.max(0, ((total - elapsed) / total) * 100));
                })()}%`,
                backgroundColor: dualAltLayout
                  ? isResolumeSynced(indentedSubTimer)
                    ? '#fde047'
                    : '#fb923c'
                  : isOpAlt
                    ? '#a78bfa'
                    : isResolumeSynced(secondarySubTimer)
                      ? '#fde047'
                      : '#fb923c',
              }}
            />
          </div>
        </div>
      )}

      {/* Main Timer Layout - Only when no secondary timer and no message */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(secondarySubTimer);
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return !hasSecondaryTimer && !hasMessage;
      })() && (
        <div className="flex-1 flex flex-col items-center justify-center">
          {useTimeOfDay ? (
            /* Large Time of Day in center; progress bar only when not TOD Only */
            <>
              <div className="text-center">
                <div 
                  className={`font-mono font-bold ${dsmHeroTod} text-white`}
                >
                  {formatTimeOfDay(currentTime)}
                </div>
              </div>
              {showTimeRemainingAndBar && (
                <div className="w-full max-w-5xl mt-0">
                  <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                    <div 
                      className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                        usePreshowRainbow ? 'ros-rainbow-fill' : ''
                      }`}
                      style={{ 
                        width: `${getRemainingPercentage()}%`,
                        ...(usePreshowRainbow ? {} : { background: getProgressBarColor() }),
                      }}
                    />
                  </div>
                </div>
              )}
            </>
          ) : useCountUp ? (
            /* Count Up: elapsed time; OVER TIME + red when overtime; bar fills up */
            <>
              {isOvertimeCountUp ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className={`font-bold text-red-500 ${dsmHeroLabel}`}>
                    OVER TIME
                  </div>
                  <div className={`font-mono text-red-400 ${show16x9Frame ? 'text-lg' : 'text-2xl'} mt-1 leading-none`}>
                    +{formatTime(overtimeAmount)}
                  </div>
                </div>
              ) : usePreshowRainbow ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className={`ros-preshow-super ${dsmHeroLabel}`}>PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              <div className="text-center">
                <div 
                  className={`font-mono font-bold ${usePreshowRainbow ? 'ros-rainbow-text' : ''} ${(() => {
                    const hours = Math.floor(Math.abs(elapsedForDisplay) / 3600);
                    return hours === 0 ? dsmHeroMmSs : dsmHeroHhMmSs;
                  })()}`}
                  style={usePreshowRainbow ? undefined : { color: getCountUpProgressBarColor() }}
                >
                  {renderSignedTime(elapsedForDisplay)}
                </div>
              </div>
              <div className="w-full max-w-5xl mt-0">
                <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                  <div 
                    className={`h-full transition-all duration-1000 absolute top-0 left-0 ${
                      usePreshowRainbow ? 'ros-rainbow-fill' : ''
                    }`}
                    style={{ 
                      width: `${getCountUpBarPercentage()}%`,
                      ...(usePreshowRainbow ? {} : { background: getCountUpProgressBarColor() }),
                    }}
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              {getRemainingTime() < 0 ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className={`font-bold text-red-500 ${dsmHeroLabel}`}>
                    OVER TIME
                  </div>
                </div>
              ) : usePreshowRainbow ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className={`ros-preshow-super ${dsmHeroLabel}`}>PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              {/* Countdown Timer - Centered */}
              <div className="text-center">
                <div 
                  className={`font-mono font-bold ${usePreshowRainbow ? 'ros-rainbow-text' : ''} ${(() => {
                    const remaining = getRemainingTime();
                    const hours = Math.floor(Math.abs(remaining) / 3600);
                    return hours === 0 ? dsmHeroMmSs : dsmHeroHhMmSs;
                  })()}`}
                  style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
                >
                  {renderSignedTime(getRemainingTime())}
                </div>
              </div>
              {/* Progress Bar - 0px below timer */}
              <div className="w-full max-w-5xl mt-0">
                <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                  <div 
                    className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                      usePreshowRainbow ? 'ros-rainbow-fill' : ''
                    }`}
                    style={{ 
                      width: `${getRemainingPercentage()}%`,
                      ...(usePreshowRainbow ? {} : { background: getProgressBarColor() }),
                    }}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when message is active */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(secondarySubTimer);
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasMessage && !hasSecondaryTimer;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-1/2 transform -translate-x-1/2 flex flex-col items-center`}>
          {useTimeOfDay ? (
            <div className={`font-mono font-bold ${dsmCrowdedTimeClass} text-white leading-none`}>
              {formatTimeOfDay(currentTime)}
            </div>
          ) : useCountUp ? (
            <>
              {/* 16:9 overtime uses shared slim label; in-flow only when 16:9 off */}
              {!show16x9Frame && isOvertimeCountUp ? (
                <div className="mb-1">
                  <div className={`font-bold text-red-500 ${dsmCrowdedOvertimeClass} whitespace-nowrap`}>
                    OVER TIME
                  </div>
                </div>
              ) : !isOvertimeCountUp && usePreshowRainbow ? (
                <div className="mb-1 text-center">
                  <div className={`ros-preshow-super ${dsmCrowdedLabelClass}`}>PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              <div 
                className={`font-mono font-bold transition-all duration-500 ease-in-out ${dsmCrowdedTimeClass} leading-none ${
                  usePreshowRainbow ? 'ros-rainbow-text' : ''
                }`}
                style={usePreshowRainbow ? undefined : { color: getCountUpProgressBarColor() }}
              >
                {renderSignedTime(elapsedForDisplay)}
              </div>
            </>
          ) : (
            <>
              {!show16x9Frame && getRemainingTime() < 0 ? (
                <div className="mb-1">
                  <div className={`font-bold text-red-500 ${dsmCrowdedOvertimeClass} whitespace-nowrap`}>
                    OVER TIME
                  </div>
                </div>
              ) : getRemainingTime() >= 0 && usePreshowRainbow ? (
                <div className="mb-1 text-center">
                  <div className={`ros-preshow-super ${dsmCrowdedLabelClass}`}>PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              <div 
                className={`font-mono font-bold transition-all duration-500 ease-in-out ${dsmCrowdedTimeClass} leading-none ${
                  usePreshowRainbow ? 'ros-rainbow-text' : ''
                }`}
                style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
              >
                {renderSignedTime(getRemainingTime())}
              </div>
            </>
          )}
          {/* Progress bar tucked directly under the timer */}
          <div className={`mt-2 ${dsmCrowdedBarClass}`}>
            <div className="w-full h-full bg-slate-700 rounded-full overflow-hidden border-2 border-slate-600 relative">
              <div
                className={`h-full transition-all duration-1000 absolute top-0 ${
                  useCountUp ? 'left-0' : 'right-0'
                } ${usePreshowRainbow ? 'ros-rainbow-fill' : ''}`}
                style={{
                  width: `${useCountUp ? getCountUpBarPercentage() : getRemainingPercentage()}%`,
                  ...(usePreshowRainbow
                    ? {}
                    : {
                        background: useCountUp
                          ? getCountUpProgressBarColor()
                          : getProgressBarColor(),
                      }),
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(secondarySubTimer);
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && !hasMessage && !dualAltLayout;
      })() && (
        <div className="text-center transition-all duration-500 ease-in-out absolute bottom-20 left-1/2 transform -translate-x-1/2">
          {useTimeOfDay ? (
            <div className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-white">
              {formatTimeOfDay(currentTime)}
            </div>
          ) : useCountUp ? (
            <>
              {isOvertimeCountUp ? (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              ) : usePreshowRainbow ? (
                <div className="mb-2 text-center">
                  <div className="ros-preshow-super text-lg md:text-xl lg:text-2xl">PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              <div 
                className={`font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl ${
                  usePreshowRainbow ? 'ros-rainbow-text' : ''
                }`}
                style={usePreshowRainbow ? undefined : { color: getCountUpProgressBarColor() }}
              >
                {renderSignedTime(elapsedForDisplay)}
              </div>
            </>
          ) : (
            <>
              {getRemainingTime() < 0 ? (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              ) : usePreshowRainbow ? (
                <div className="mb-2 text-center">
                  <div className="ros-preshow-super text-lg md:text-xl lg:text-2xl">PRE SHOW COUNTDOWN</div>
                  <span className="ros-preshow-super-rule" aria-hidden />
                </div>
              ) : null}
              <div 
                className={`font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl ${
                  usePreshowRainbow ? 'ros-rainbow-text' : ''
                }`}
                style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
              >
                {renderSignedTime(getRemainingTime())}
              </div>
            </>
          )}
        </div>
      )}

      {/* Progress bar for crowded single-timer is nested under the timer above */}

      {/* Progress Bar - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(secondarySubTimer);
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && !hasMessage && !dualAltLayout;
      })() && (
        <div className="w-full transition-all duration-500 ease-in-out absolute bottom-8 left-1/2 transform -translate-x-1/2 max-w-2xl">
          <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-2">
            <div 
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{ 
                width: `${getRemainingPercentage()}%`,
                background: getProgressBarColor()
              }}
            />
          </div>
        </div>
      )}
        </div>
      </div>
    </div>
  );
};

export default DsmClock;
