@echo off
setlocal
cd /d "%~dp0"
if not exist "launcher\start-offline-kiosk.bat" (
  echo ERROR: Unzip the full offline-kiosk-v2 folder first.
  pause
  exit /b 1
)
call "launcher\start-offline-kiosk.bat"
endlocal
