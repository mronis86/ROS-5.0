ROS Offline Kiosk V2

Operator shell for LAN Offline Show, displays (WebLinked), and RemoteOp.

1. Unzip this folder.
2. Double-click START.bat (or launcher\start-offline-kiosk.bat).
   First run installs Electron via npm — Node.js required.
3. Status tab: start Offline Show, set LAN / Cloud / token.
4. Optional WebLinked (SDI/NDI): on a machine that has the Sinor WebLinked
   build, run: npm run sync:weblinked
   (binaries are not in this zip — too large for Pages).

Settings / session length live in the kiosk UI.
