ROS Offline Kiosk V2 (package used by install-offline-kiosk.bat)

Preferred: download install-offline-kiosk.bat from ROS and run it.
It installs this package under %LOCALAPPDATA%\ROS-Offline-Kiosk if needed.

Manual:
1. Unzip this folder.
2. Double-click START.bat (Node.js 20+ required).
3. Optional WebLinked: npm run sync:weblinked
