import React, { useState, useEffect } from 'react';
import DriftStatusIndicator from './DriftStatusIndicator';
import { DatabaseService, TimerMessage } from '../services/database';
import { socketClient } from '../services/socket-client';
import { startSecondTicker } from '../utils/secondTicker';
import { isPreshowTimerMessage } from '../lib/preshowCountdown';
import { AltTimerBadge } from './AltTimerBadge';
import CueCardClockOverlay from './CueCardClockOverlay';
import TeleprompterClockOverlay, {
  type TeleprompterClockFeed,
} from './TeleprompterClockOverlay';
import type { CueCardComment, CueCardSlide } from '../lib/cueCards';

interface ClockProps {
  isRunning?: boolean;
  elapsedTime?: number;
  totalDuration?: number;
  onClose?: () => void;
  message?: string;
  messageEnabled?: boolean;
  itemId?: number; // Add itemId for drift detection
  eventId?: string; // Add eventId for Supabase message loading
  supabaseMessage?: TimerMessage | null; // Add supabaseMessage prop
  scheduleItems?: any[]; // Run-of-show items; when active cue has timerDisplay === 'timeOfDay', show large time-of-day instead of countdown
  mainTimer?: {
    cue: string;
    segmentName: string;
  } | null;
  secondaryTimer?: {
    itemId: number;
    remaining: number;
    duration: number;
    cue: string;
    segmentName: string;
  } | null;
  /** Offline show timer page — badges sit to the right of TIMER LOADED */
  offlineShowBadge?: boolean;
  cloudConnected?: boolean;
}

const Clock: React.FC<ClockProps> = ({
  isRunning = false,
  elapsedTime = 0,
  totalDuration = 0, // Default to 0 when no timer is running
  onClose,
  message = '',
  messageEnabled = false,
  itemId,
  eventId,
  supabaseMessage = null,
  scheduleItems,
  mainTimer = null,
  secondaryTimer = null,
  offlineShowBadge = false,
  cloudConnected = false,
}) => {
  const [timerProgress, setTimerProgress] = useState<{ elapsed: number; total: number }>({
    elapsed: elapsedTime,
    total: totalDuration
  });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [messageLoading, setMessageLoading] = useState(false);
  const [supabaseOnly, setSupabaseOnly] = useState(true);
  const [hybridTimerData, setHybridTimerData] = useState<any>({ activeTimer: null });
  const [cueClockFeed, setCueClockFeed] = useState<{
    enabled: boolean;
    slide: CueCardSlide | null;
    comments: CueCardComment[];
  } | null>(null);
  const [teleprompterClockFeed, setTeleprompterClockFeed] =
    useState<TeleprompterClockFeed | null>(null);
  const [secondaryTimerUpdate, setSecondaryTimerUpdate] = useState(0);
  const [secondaryTimerStartTime, setSecondaryTimerStartTime] = useState<Date | null>(null);
  const [lastActiveTimerId, setLastActiveTimerId] = useState<string | null>(null);
  const [lastActiveItemId, setLastActiveItemId] = useState<number | null>(null);
  const [lastActiveStartTime, setLastActiveStartTime] = useState<string | null>(null);
  const [clockOffset, setClockOffset] = useState<number>(0); // Offset between client and server clocks in ms

  // Clock component always runs in WebSocket-only mode

  // Clock always uses WebSocket data, no props handling needed
  
  // Helper function to get synced current time (client time + offset)
  const getSyncedNow = () => new Date(Date.now() + clockOffset);
  
  // Helper function to calculate elapsed time with clock sync
  const calculateElapsed = (startedAt: Date | string) => {
    const syncedNow = getSyncedNow();
    const start = startedAt instanceof Date ? startedAt : new Date(startedAt);
    return Math.floor((syncedNow.getTime() - start.getTime()) / 1000);
  };

  const isResolumeSynced = (timer: { resolume_state?: string; mitti_state?: string; time_source?: string } | null | undefined) =>
    timer?.resolume_state === 'synced' ||
    timer?.mitti_state === 'synced' ||
    (timer?.time_source === 'resolume' && timer?.resolume_state !== 'armed') ||
    (timer?.time_source === 'mitti' && timer?.mitti_state !== 'armed');

  const isResolumeArmed = (timer: { resolume_state?: string; mitti_state?: string } | null | undefined) =>
    timer?.resolume_state === 'armed' || timer?.mitti_state === 'armed';

  const isResolumeCompanionSubCue = (timer: { user_name?: string; user_id?: string } | null | undefined) =>
    timer?.user_name === 'Resolume Sync' ||
    timer?.user_id === 'companion-resolume' ||
    timer?.user_name === 'Mitti Sync' ||
    timer?.user_id === 'companion-mitti';

  const enrichSubCueTimer = (timer: any) => {
    if (!timer || typeof timer !== 'object') return timer;
    if (isResolumeSynced(timer) || isResolumeArmed(timer)) return timer;
    if (!isResolumeCompanionSubCue(timer)) return timer;
    const isMitti = timer?.user_id === 'companion-mitti' || timer?.user_name === 'Mitti Sync';
    return {
      ...timer,
      time_source: isMitti ? 'mitti' : 'resolume',
      ...(isMitti
        ? { mitti_state: timer.is_running ? 'synced' : 'armed' }
        : { resolume_state: timer.is_running ? 'synced' : 'armed' }),
    };
  };

  const getRemainingFromTimer = (
    timer: { started_at?: string; duration_seconds?: number } | null | undefined,
    offsetMs: number
  ) => {
    if (!timer?.started_at || timer.duration_seconds == null) return null;
    const startedMs = new Date(timer.started_at).getTime();
    if (!Number.isFinite(startedMs)) return null;
    return timer.duration_seconds - (Date.now() + offsetMs - startedMs) / 1000;
  };

  const shouldRejectResolumeAlignReset = (
    prev: { started_at?: string; duration_seconds?: number; is_running?: boolean } | null | undefined,
    next: {
      started_at?: string;
      duration_seconds?: number;
      is_running?: boolean;
      resolume_state?: string;
      mitti_state?: string;
      time_source?: string;
    },
    offsetMs: number
  ) => {
    if (!prev?.is_running || !next.is_running || !isResolumeSynced(next)) return false;
    if (!prev.started_at || !next.started_at || prev.started_at === next.started_at) return false;
    const dur = next.duration_seconds ?? prev.duration_seconds ?? 0;
    if (dur <= 0) return false;
    const prevRem = getRemainingFromTimer(prev, offsetMs);
    const nextRem = getRemainingFromTimer(next, offsetMs);
    if (prevRem == null || nextRem == null) return false;
    return prevRem <= 15 && nextRem > dur * 0.85;
  };

  // Update timer progress when props change (non-WebSocket mode)
  useEffect(() => {
    if (!supabaseOnly) {
      // Use props data when not in hybrid mode
      setTimerProgress({
        elapsed: elapsedTime,
        total: totalDuration
      });
    }
  }, [elapsedTime, totalDuration, supabaseOnly]);

  // Real-time countdown timer for running timers
  useEffect(() => {
    console.log('🔍 [CLOCK DEBUG] Timer progress effect triggered', {
      isRunning: hybridTimerData?.activeTimer?.is_running,
      isActive: hybridTimerData?.activeTimer?.is_active,
      startedAt: hybridTimerData?.activeTimer?.started_at,
      duration: hybridTimerData?.activeTimer?.duration_seconds
    });
    
    if (supabaseOnly && hybridTimerData?.activeTimer?.is_running && hybridTimerData?.activeTimer?.is_active) {
      const activeTimer = hybridTimerData.activeTimer;
      const startedAt = new Date(activeTimer.started_at);
      const total = activeTimer.duration_seconds || 0;
      
      console.log('🔍 [CLOCK DEBUG] Setting up local countdown timer', {
        startedAt: startedAt.toISOString(),
        total
      });
      
      const updateCountdown = () => {
        const elapsed = calculateElapsed(startedAt);
        
        console.log('🔍 [CLOCK DEBUG] Local countdown update', { elapsed, total, clockOffsetSeconds: Math.floor(clockOffset / 1000) });
        
        setTimerProgress({
          elapsed: elapsed,
          total: total
        });
      };
      
      // Worker-based tick so countdown stays smooth when window is visible but unfocused
      const stopTicker = startSecondTicker(updateCountdown);
      
      return () => {
        console.log('🔍 [CLOCK DEBUG] Cleaning up countdown interval');
        stopTicker();
      };
    } else if (supabaseOnly && hybridTimerData?.activeTimer && !hybridTimerData?.activeTimer?.is_running) {
      // Timer is loaded but not running - show 0 elapsed
      const activeTimer = hybridTimerData.activeTimer;
      console.log('🔍 [CLOCK DEBUG] Timer loaded but not running', {
        duration: activeTimer.duration_seconds
      });
      
      setTimerProgress({
        elapsed: 0,
        total: activeTimer.duration_seconds || 0
      });
    } else if (supabaseOnly && !hybridTimerData?.activeTimer) {
      // No active timer - clear display
      console.log('🔍 [CLOCK DEBUG] No active timer - clearing display');
      
      setTimerProgress({
        elapsed: 0,
        total: 0
      });
    }
  }, [hybridTimerData?.activeTimer?.is_running, hybridTimerData?.activeTimer?.is_active, hybridTimerData?.activeTimer?.started_at, hybridTimerData?.activeTimer?.duration_seconds, hybridTimerData?.activeTimer, supabaseOnly, clockOffset]);

  // Update current time every second (Worker tick — not throttled when unfocused but visible)
  useEffect(() => {
    return startSecondTicker(() => {
      setCurrentTime(new Date());
    });
  }, []);

  // REMOVED: This was for props-based mode, but Clock always uses WebSocket mode
  // Timer progress is handled by the effect above (lines 74-134)

  // Listen for full screen changes
  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);

  // Message loading is now handled by ClockPage via real-time subscriptions
  // No need for polling here since ClockPage already manages this

  // WebSocket mode: Fetch timer data via WebSocket when supabaseOnly is true
  useEffect(() => {
    if (!supabaseOnly || !eventId) {
      // Clear any existing WebSocket connections (handled in cleanup)
      // Reset timer tracking when exiting WebSocket mode
      setLastActiveTimerId(null);
      setLastActiveItemId(null);
      setLastActiveStartTime(null);
      
      // WebSocket provides real-time updates, no drift detection cleanup needed
      
      return;
    }

    console.log('🔄 Clock: Setting up WebSocket connection for eventId:', eventId);
    let loadInFlight = false;

    const loadActiveTimer = async () => {
      if (loadInFlight) {
        console.log('🔄 Already loading active timer, skipping...');
        return;
      }
      
      try {
        loadInFlight = true;
        console.log('🔄 Loading active timer from API...');
        const activeTimer = await DatabaseService.getActiveTimer(eventId);
        if (activeTimer && activeTimer.timer_state !== 'stopped' && activeTimer.is_active) {
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: activeTimer
          }));
          console.log('✅ Active timer updated:', activeTimer);
        } else {
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('❌ No active timer found or timer is stopped');
        }
        
        // Also load sub-cue timers and messages on initial load
        try {
          console.log('🔄 Clock: Loading sub-cue timers and messages on initial load...');
          
           // Load current sub-cue timers
           const subCueTimersResult = await DatabaseService.getActiveSubCueTimers(eventId);
           if (subCueTimersResult && subCueTimersResult.data && subCueTimersResult.data.length > 0) {
             // Find the first running sub-cue timer
             const runningSubCueTimer = subCueTimersResult.data.find(timer => 
               timer.timer_state === 'running' || timer.is_running === true
             );
            if (runningSubCueTimer) {
              setHybridTimerData(prev => ({
                ...prev,
                secondaryTimer: enrichSubCueTimer(runningSubCueTimer)
              }));
              console.log('✅ Clock: Initial load - sub-cue timer loaded:', runningSubCueTimer);
            } else {
              setHybridTimerData(prev => ({ ...prev, secondaryTimer: null }));
            }
          } else {
            setHybridTimerData(prev => ({ ...prev, secondaryTimer: null }));
          }
          
          // Load current timer message (enabled only; null clears stale display)
          const timerMessage = await DatabaseService.getTimerMessage(eventId);
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: timerMessage || null
          }));
          console.log('✅ Clock: Initial load - timer message:', timerMessage);
        } catch (error) {
          console.error('❌ Clock: Initial load failed to load sub-cue timers and messages:', error);
        }
        
        // Check if active timer has changed (cue jump detection)
        if (activeTimer && activeTimer.timer_state !== 'stopped' && activeTimer.is_active && supabaseOnly) {
          const currentActiveTimerId = `${activeTimer.item_id}_${activeTimer.started_at}`;
          const currentItemId = activeTimer.item_id;
          
          if (lastActiveTimerId && lastActiveTimerId !== currentActiveTimerId) {
            console.log('🔄 Active timer changed - stopping secondary timer');
            console.log('🔄 Previous timer:', lastActiveTimerId);
            console.log('🔄 New timer:', currentActiveTimerId);
            // Clear secondary timer when main timer changes
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null
            }));
          }
          
          // Also check if the item_id changed (new cue loaded) - this should stop sub-cue timer
          if (lastActiveItemId && lastActiveItemId !== currentItemId) {
            console.log('🔄 New cue loaded - stopping secondary timer');
            console.log('🔄 Previous item_id:', lastActiveItemId);
            console.log('🔄 New item_id:', currentItemId);
            // Clear secondary timer when new cue is loaded
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null
            }));
          }
          
          // Check if the start time changed (timer paused/resumed/restarted)
          const currentStartTime = activeTimer.started_at;
          if (lastActiveStartTime && lastActiveStartTime !== currentStartTime) {
            console.log('🔄 Timer start time changed - restarting local timer');
            console.log('🔄 Previous start time:', lastActiveStartTime);
            console.log('🔄 New start time:', currentStartTime);
            // The local timer will automatically restart due to the dependency change
          }
          
          // WebSocket provides real-time updates, no drift detection needed
          
          setLastActiveTimerId(currentActiveTimerId);
          setLastActiveItemId(currentItemId);
          setLastActiveStartTime(currentStartTime);
        } else if (!activeTimer && lastActiveTimerId && supabaseOnly) {
          // Active timer stopped completely - stop secondary timer and drift detection
          console.log('🔄 Active timer stopped - stopping secondary timer and drift detection');
          setHybridTimerData(prev => ({
            ...prev,
            secondaryTimer: null
          }));
          
          // WebSocket provides real-time updates, no drift detection cleanup needed
          
          setLastActiveTimerId(null);
          setLastActiveItemId(null);
          setLastActiveStartTime(null);
        }
      } catch (error) {
        console.error('❌ Error loading active timer:', error);
      } finally {
        loadInFlight = false;
      }
    };

    // Load initial data once
    loadActiveTimer();

    // Set up WebSocket connection for real-time timer updates
    const callbacks = {
      onServerTime: (data: any) => {
        // Sync client clock with server clock
        const serverTime = new Date(data.serverTime).getTime();
        const clientTime = new Date().getTime();
        const offset = serverTime - clientTime;
        setClockOffset(offset);
        console.log('🕐 Clock: Clock sync:', {
          serverTime: data.serverTime,
          clientTime: new Date().toISOString(),
          offsetMs: offset,
          offsetSeconds: Math.floor(offset / 1000)
        });
      },
      onTimerUpdated: (data: any) => {
        console.log('🔍 [CLOCK DEBUG] ===== WebSocket onTimerUpdated =====');
        console.log('🔍 [CLOCK DEBUG] Received data:', data);
        console.log('🔍 [CLOCK DEBUG] Event ID check:', { received: data?.event_id, expected: eventId, match: data?.event_id === eventId });
        console.log('🔍 [CLOCK DEBUG] Timer state:', data?.timer_state);
        console.log('🔍 [CLOCK DEBUG] Is running:', data?.is_running);
        console.log('🔍 [CLOCK DEBUG] Started at:', data?.started_at);
        console.log('🔍 [CLOCK DEBUG] Duration:', data?.duration_seconds);
        
        if (data && data.event_id === eventId) {
          // Update timer data directly from WebSocket
          console.log('🔍 [CLOCK DEBUG] Updating hybridTimerData with WebSocket data');
          setHybridTimerData(prev => {
            console.log('🔍 [CLOCK DEBUG] Previous hybridTimerData:', prev);
            let activeTimer = data;
            if (shouldRejectResolumeAlignReset(prev?.activeTimer, data, clockOffset)) {
              activeTimer = { ...data, started_at: prev!.activeTimer!.started_at };
            }
            const newData = {
              ...prev,
              activeTimer
            };
            console.log('🔍 [CLOCK DEBUG] New hybridTimerData:', newData);
            return newData;
          });
          console.log('✅ Clock: Timer updated via WebSocket');
        } else {
          console.log('⚠️ Clock: Timer update ignored - event ID mismatch or no data');
        }
      },
      onActiveTimersUpdated: (data: any) => {
        console.log('🔍 [CLOCK DEBUG] ===== WebSocket onActiveTimersUpdated =====');
        console.log('🔍 [CLOCK DEBUG] Raw data received:', data);
        
        // Handle array format (from server broadcast)
        let timerData = data;
        if (Array.isArray(data) && data.length > 0) {
          timerData = data[0]; // Take first timer from array
          console.log('🔍 [CLOCK DEBUG] Extracted first timer from array:', timerData);
        }
        
        console.log('🔍 [CLOCK DEBUG] Event ID check:', { received: timerData?.event_id, expected: eventId, match: timerData?.event_id === eventId });
        console.log('🔍 [CLOCK DEBUG] Timer state:', timerData?.timer_state);
        console.log('🔍 [CLOCK DEBUG] Is active:', timerData?.is_active);
        console.log('🔍 [CLOCK DEBUG] Is running:', timerData?.is_running);
        
        if (timerData && timerData.event_id === eventId) {
          // Check if timer is stopped
          if (timerData.timer_state === 'stopped' || timerData.is_active === false) {
            console.log('🔍 [CLOCK DEBUG] Timer is stopped - clearing timer data');
            // Clear timer data when stopped
            setHybridTimerData(prev => ({
              ...prev,
              activeTimer: null
            }));
            console.log('✅ Clock: Timer stopped via WebSocket - cleared timer data');
          } else {
            console.log('🔍 [CLOCK DEBUG] Timer is active - updating hybridTimerData');
            // Update timer data directly from WebSocket
            setHybridTimerData(prev => {
              let activeTimer = timerData;
              if (shouldRejectResolumeAlignReset(prev?.activeTimer, timerData, clockOffset)) {
                activeTimer = { ...timerData, started_at: prev!.activeTimer!.started_at };
              }
              return { ...prev, activeTimer };
            });
            console.log('✅ Clock: Active timer updated via WebSocket');
          }
        } else {
          console.log('⚠️ Clock: Active timers update ignored - event ID mismatch or no data');
        }
      },
      onTimerStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket timer stopped:', data);
        if (data && data.event_id === eventId) {
          // Clear timer data when stopped
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('✅ Clock: Timer cleared via WebSocket');
        }
      },
      onTimersStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket all timers stopped:', data);
        if (data && data.event_id === eventId) {
          // Clear timer data when all stopped
          setHybridTimerData(prev => ({
            ...prev,
            activeTimer: null
          }));
          console.log('✅ Clock: All timers cleared via WebSocket');
        }
      },
      onSubCueTimerStarted: (data: any) => {
        console.log('🔄 Clock: WebSocket sub-cue timer started:', data);
        if (data && data.event_id === eventId) {
          setHybridTimerData(prev => {
            const enriched = enrichSubCueTimer(data);
            let secondaryTimer = enriched;
            if (shouldRejectResolumeAlignReset(prev?.secondaryTimer, enriched, clockOffset)) {
              secondaryTimer = { ...enriched, started_at: prev!.secondaryTimer!.started_at };
              console.log('🎬 Clock: Ignoring Resolume sub-cue align that reset countdown to full clip');
            }
            return { ...prev, secondaryTimer };
          });
          console.log('✅ Clock: Sub-cue timer started via WebSocket:', data);
        }
      },
      onSubCueTimerStopped: (data: any) => {
        console.log('🔄 Clock: WebSocket sub-cue timer stopped:', data);
        if (data && data.event_id === eventId) {
          // Clear secondary timer data
          setHybridTimerData(prev => ({
            ...prev,
            secondaryTimer: null
          }));
          console.log('✅ Clock: Sub-cue timer stopped via WebSocket');
        }
      },
      onTimerMessageUpdated: (data: any) => {
        console.log('📨 Clock: WebSocket timer message updated:', data);
        if (data && data.event_id === eventId) {
          const next = data.enabled ? data : null;
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: next
          }));
          console.log('✅ Clock: Timer message updated via WebSocket:', next);
        }
      },
      onInitialSync: async () => {
        console.log('🔄 Clock: Performing initial sync for sub-cue timers and messages');
        try {
          // Load current sub-cue timers
          const subCueTimersResult = await DatabaseService.getActiveSubCueTimers(eventId);
          if (subCueTimersResult && subCueTimersResult.data && subCueTimersResult.data.length > 0) {
            // Find the first running sub-cue timer
            const runningSubCueTimer = subCueTimersResult.data.find(timer => 
              timer.timer_state === 'running' || timer.is_running === true
            );
            if (runningSubCueTimer) {
              setHybridTimerData(prev => ({
                ...prev,
                secondaryTimer: enrichSubCueTimer(runningSubCueTimer),
              }));
              console.log('✅ Clock: Initial sync - sub-cue timer loaded:', runningSubCueTimer);
            }
          }
          
          // Load current timer message (enabled only; null clears stale display)
          const timerMessage = await DatabaseService.getTimerMessage(eventId);
          setHybridTimerData(prev => ({
            ...prev,
            timerMessage: timerMessage || null
          }));
          console.log('✅ Clock: Initial sync - timer message:', timerMessage);
        } catch (error) {
          console.error('❌ Clock: Initial sync failed to load sub-cue timers and messages:', error);
        }
      },
      onConnectionChange: (connected: boolean) => {
        console.log('🔄 Clock: WebSocket connection status:', connected);
        if (connected) {
          // Reload timer when reconnected
          loadActiveTimer();
        }
      },
      onResetAllStates: (data: any) => {
        if (data?.event_id === eventId || !data?.event_id) {
          setHybridTimerData((prev) => ({
            ...prev,
            activeTimer: null,
            secondaryTimer: null
          }));
          setLastActiveTimerId(null);
          setLastActiveItemId(null);
          setLastActiveStartTime(null);
        }
      }
    };

    socketClient.connect(eventId, callbacks);

    const onCueCardsClockSync = (data: any) => {
      if (!data || String(data.eventId) !== String(eventId)) return;
      if (!data.enabled || !data.slide) {
        setCueClockFeed(null);
        return;
      }
      setTeleprompterClockFeed(null);
      setCueClockFeed({
        enabled: true,
        slide: data.slide,
        comments: Array.isArray(data.comments) ? data.comments : [],
      });
    };

    const onTeleprompterClockSync = (data: any) => {
      if (!data || String(data.eventId) !== String(eventId)) return;
      if (!data.enabled) {
        setTeleprompterClockFeed(null);
        return;
      }
      setCueClockFeed(null);
      setTeleprompterClockFeed((prev) => {
        const nextSettings = data.settings || prev?.settings || {
          fontSize: 48,
          lineHeight: 1.4,
          textAlign: 'center' as const,
          textColor: '#FFFFFF',
          backgroundColor: '#000000',
        };
        return {
          enabled: true,
          scriptText:
            typeof data.scriptText === 'string' ? data.scriptText : prev?.scriptText || '',
          scrollPosition:
            typeof data.scrollPosition === 'number'
              ? data.scrollPosition
              : prev?.scrollPosition || 0,
          settings: nextSettings,
          guideLinePosition:
            typeof data.guideLinePosition === 'number'
              ? data.guideLinePosition
              : prev?.guideLinePosition ?? 50,
          comments: Array.isArray(data.comments)
            ? data.comments
            : prev?.comments || [],
          scriptName:
            typeof data.scriptName === 'string'
              ? data.scriptName
              : prev?.scriptName,
        };
      });
    };

    const sock = socketClient.getSocket();
    sock?.on('cueCardsClockSync', onCueCardsClockSync);
    sock?.on('teleprompterClockSync', onTeleprompterClockSync);

    // Re-register callbacks + refresh when the page becomes visible again.
    // Never disconnect here — display clocks must keep receiving messages while open
    // (including when another window has focus, or this window was briefly occluded).
    const refreshClockOnReturn = () => {
      if (document.hidden) return;
      console.log('🔄 Clock: Visible - re-registering callbacks and refreshing timer state');
      socketClient.connect(eventId, callbacks);
      setCurrentTime(new Date());
      void loadActiveTimer();
      socketClient.getSocket()?.on('cueCardsClockSync', onCueCardsClockSync);
      socketClient.getSocket()?.on('teleprompterClockSync', onTeleprompterClockSync);
    };
    document.addEventListener('visibilitychange', refreshClockOnReturn);

    return () => {
      console.log('🔄 Clock: Cleaning up WebSocket connection');
      document.removeEventListener('visibilitychange', refreshClockOnReturn);
      socketClient.getSocket()?.off('cueCardsClockSync', onCueCardsClockSync);
      socketClient.getSocket()?.off('teleprompterClockSync', onTeleprompterClockSync);
      socketClient.disconnect(eventId);
    };
  }, [eventId]); // Removed supabaseOnly since it's always true in this component

  // Update secondary timer every second when in hybrid mode
  useEffect(() => {
    if (!supabaseOnly || !hybridTimerData?.secondaryTimer) return;

    return startSecondTicker(() => {
      setSecondaryTimerUpdate(prev => prev + 1);
    });
  }, [supabaseOnly, hybridTimerData?.secondaryTimer]);

  // REMOVED: Duplicate timer effect that was causing flickering
  // The timer progress effect above (lines 74-134) handles all timer updates

  // WebSocket provides real-time updates, no drift detection cleanup needed

  // Helper function to format time (same as RunOfShowPage) - handles negative values
  const formatTime = (seconds: number) => {
    const isNegative = seconds < 0;
    const absSeconds = Math.abs(seconds);
    const hours = Math.floor(absSeconds / 3600);
    const minutes = Math.floor((absSeconds % 3600) / 60);
    const secs = Math.floor(absSeconds % 60);
    const sign = isNegative ? '-' : '';
    // Hide hours if they are 0
    if (hours === 0) {
      return `${sign}${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    
    return `${sign}${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Format time of day
  const formatTimeOfDay = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Get remaining time (same logic as RunOfShowPage) - allow negative values except Resolume sync
  const getRemainingTime = () => {
    const progress = timerProgress;
    const remaining = progress.total - progress.elapsed;
    
    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show full duration
        return progress.total;
      }
    }
    
    return remaining;
  };

  // Get elapsed time for count-up display
  const getElapsedTime = () => {
    const progress = timerProgress;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return 0;
      }
    }
    return progress.elapsed;
  };

  // Count-up: bar fills as elapsed increases (cap at 100%); overtime = red
  const getCountUpBarPercentage = () => {
    const progress = timerProgress;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return 0;
      }
    }
    if (progress.total <= 0) return 0;
    return Math.min(100, (progress.elapsed / progress.total) * 100);
  };

  const getCountUpProgressBarColor = () => {
    const progress = timerProgress;
    const elapsed = progress.elapsed;
    const remaining = progress.total - progress.elapsed;
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return '#6b7280';
      }
    }
    if (elapsed > progress.total) return '#ef4444'; // Red when overtime
    if (remaining > 120) return '#10b981';
    if (remaining > 30) return '#f59e0b';
    return '#ef4444';
  };

  // Get remaining percentage for progress bar (same logic as RunOfShowPage)
  const getRemainingPercentage = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show 100% (full bar)
        return 100;
      }
    }
    
    return progress.total > 0 ? (remainingSeconds / progress.total) * 100 : 0;
  };

  // Get progress bar color based on remaining time (same logic as RunOfShowPage)
  const getProgressBarColor = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In WebSocket mode, check if timer is actually running
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show neutral color
        return '#6b7280'; // Gray
      }
    }
    
    // Color based on remaining time
    if (remainingSeconds > 120) { // More than 2 minutes
      return '#10b981'; // Green
    } else if (remainingSeconds > 30) { // Less than 2 minutes but more than 30 seconds
      return '#f59e0b'; // Yellow
    } else { // Less than 30 seconds
      return '#ef4444'; // Red
    }
  };

  // Active cue timer mode: timeOfDay = swap + progress bar; todOnly = time of day only, no progress bar or time remaining
  const activeItemId = hybridTimerData?.activeTimer?.item_id;
  const activeItem = scheduleItems?.length && activeItemId != null
    ? scheduleItems.find((i: any) => i.id === activeItemId || String(i.id) === String(activeItemId) || i.id == activeItemId)
    : null;
  const timerDisplayValue = activeItem && (activeItem.timerDisplay ?? activeItem.timer_display ?? '');
  const normalizedTimer = typeof timerDisplayValue === 'string' ? timerDisplayValue.replace(/_/g, '').toLowerCase() : '';
  const isTodOnly = normalizedTimer === 'todonly';
  const useTodOnly = !!isTodOnly;
  const useCountUp = normalizedTimer === 'countup';
  const useTimeOfDay = !!(activeItem && (
    normalizedTimer === 'timeofday' ||
    normalizedTimer === 'todonly' ||
    activeItem.useTimeOfDay === true
  ));
  const showTimeRemainingAndBar = useTimeOfDay && !useTodOnly; // Time Of Day: countdown top-left + progress bar; TOD Only: hide both (minimal = large time of day only)
  const elapsedForDisplay = getElapsedTime();
  const isOvertimeCountUp = useCountUp && timerProgress.total > 0 && elapsedForDisplay > timerProgress.total;
  const overtimeAmount = isOvertimeCountUp ? elapsedForDisplay - timerProgress.total : 0;
  const secondarySubTimer = enrichSubCueTimer(hybridTimerData?.secondaryTimer);
  const secondaryDisplayColor =
    secondarySubTimer && isResolumeSynced(secondarySubTimer) ? 'text-yellow-300' : 'text-orange-400';
  const secondaryResolumeLabel = secondarySubTimer
    ? isResolumeSynced(secondarySubTimer)
      ? ' · RESOLUME'
      : isResolumeArmed(secondarySubTimer)
        ? ' · RESOLUME (armed)'
        : ''
    : '';
  const secondaryStatusPrefix =
    secondarySubTimer && isResolumeSynced(secondarySubTimer) && secondarySubTimer.is_running
      ? 'RUNNING · RESOLUME - '
      : secondarySubTimer && isResolumeArmed(secondarySubTimer)
        ? 'LOADED · RESOLUME (armed) - '
        : '';

  // Prefer any currently enabled message; Pre Show uses OVER TIME-style label instead of overlay
  const activeStageMessage =
    [hybridTimerData?.timerMessage, supabaseMessage].find(
      (m) => m?.enabled && !isPreshowTimerMessage(m)
    ) ?? null;
  const cueClockActive = !!(cueClockFeed?.enabled && cueClockFeed.slide);
  const teleprompterClockActive = !!(
    teleprompterClockFeed?.enabled && teleprompterClockFeed.scriptText
  );
  const stageFeedActive = cueClockActive || teleprompterClockActive;
  /** Push main timers to the bottom when a stage message OR cue/teleprompter feed is up */
  const layoutCrowded = !!activeStageMessage || stageFeedActive;
  const crowdedTimerBottom = stageFeedActive ? 'bottom-12' : 'bottom-20';
  const crowdedBarBottom = stageFeedActive ? 'bottom-5' : 'bottom-8';

  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden flex flex-col items-center justify-center" style={{ padding: 0, margin: 0 }}>

      {/* Top Left: hide when cue/teleprompter feed is filling the stage */}
      {!useTodOnly && !stageFeedActive && (
        <div className="absolute top-10 left-10 text-3xl font-mono text-white">
          {showTimeRemainingAndBar ? (
            <>
              <div className="text-slate-400 text-lg mb-1">TIME REMAINING</div>
              <div className="text-white" style={{ color: getProgressBarColor() }}>
                {formatTime(getRemainingTime())}
              </div>
            </>
          ) : useCountUp ? (
            <>
              <div className="text-slate-400 text-lg mb-1">CURRENT TIME ELAPSED</div>
              <div className="text-white">
                {formatTimeOfDay(currentTime)}
              </div>
            </>
          ) : (
            <>
              <div className="text-slate-400 text-lg mb-1">CURRENT TIME</div>
              <div className="text-white">
                {formatTimeOfDay(currentTime)}
              </div>
            </>
          )}
        </div>
      )}

      {/* Current Running CUE - Top Right (hidden while stage feed is on clock) */}
      {!stageFeedActive && (
      <div className="fixed top-10 right-10 text-3xl font-mono text-white z-50 w-80 text-right">
        <div className="text-slate-400 text-lg mb-1">CURRENT CUE</div>
        <div className="text-white flex items-center justify-end gap-3 whitespace-nowrap">
          <span>
            {(() => {
              if (supabaseOnly) {
                if (hybridTimerData?.activeTimer) {
                const activeTimer = hybridTimerData.activeTimer;
                const lastLoadedCue = hybridTimerData?.lastLoadedCue;
                const cueData = hybridTimerData?.cueData;
                
                // Try CUE data from active timer cue_is column first
                if (activeTimer.cue_is) {
                  return activeTimer.cue_is;
                }
                
                // Try CUE data from schedule/items table second
                if (cueData) {
                  console.log('🔍 CUE data structure:', cueData);
                  console.log('🔍 CUE data fields:', Object.keys(cueData));
                  
                  const cueDisplay = cueData.customFields?.cue || cueData.cue || cueData.cue_display || cueData.name || cueData.title;
                  const segmentName = cueData.segmentName || cueData.segment_name || cueData.segment;
                  
                  if (cueDisplay) {
                    console.log('✅ Found CUE display:', cueDisplay);
                    return cueDisplay;
                  }
                }
                
                // Try active timer other fields
                const cueDisplay = activeTimer.cue_display || activeTimer.cue;
                const segmentName = activeTimer.segment_name || activeTimer.segmentName;
                
                if (cueDisplay) {
                  return cueDisplay;
                }
                
                // Fallback to last loaded cue
                if (lastLoadedCue) {
                  const lastCueDisplay = lastLoadedCue.cue_display || lastLoadedCue.cue;
                  const lastSegmentName = lastLoadedCue.segment_name || lastLoadedCue.segmentName;
                  if (lastCueDisplay) {
                    return lastCueDisplay;
                  }
                }
                
                // Final fallback: Generate CUE display from item_id
                if (activeTimer.item_id) {
                  // Extract a meaningful CUE number from the item_id
                  const itemIdStr = activeTimer.item_id.toString();
                  const lastDigits = itemIdStr.slice(-4); // Get last 4 digits
                  return `CUE ${lastDigits}`;
                }
                
                return 'No CUE';
              } else {
                  // No active timer - show "No Cue"
                  return 'No Cue';
                }
              } else {
                // Clock always runs in WebSocket-only mode
                return 'No CUE';
              }
            })()}
          </span>
          {/* Drift Status Indicator */}
          {itemId && (
            <DriftStatusIndicator 
              itemId={itemId} 
              className="flex-shrink-0"
            />
          )}
        </div>
      </div>
      )}

      {/* Offline badges stacked above TIMER LOADED — bottom left */}
      {!isFullScreen &&
        (offlineShowBadge || (supabaseOnly && hybridTimerData?.activeTimer)) && (
          <div className="absolute bottom-10 left-10 z-50 flex flex-col items-start gap-1.5">
            {offlineShowBadge && (
              <div className="flex flex-col items-start gap-1">
                <span className="px-2 py-0.5 rounded bg-amber-600 text-black text-[10px] font-bold uppercase tracking-wide leading-tight">
                  Offline Show
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-semibold leading-tight ${
                    cloudConnected
                      ? 'bg-sky-800 text-sky-100 border border-sky-600'
                      : 'bg-orange-900/90 text-orange-100 border border-orange-700'
                  }`}
                >
                  {cloudConnected ? 'Cloud on' : 'LAN only'}
                </span>
              </div>
            )}
            {supabaseOnly && hybridTimerData?.activeTimer && (
              <div
                className={`text-lg font-bold px-4 py-2 rounded-lg shrink-0 ${
                  hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-600 text-white'
                }`}
              >
                {hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
                  ? '⏱️ TIMER RUNNING'
                  : '⏸️ TIMER LOADED'}
              </div>
            )}
          </div>
        )}

      {/* Full Screen Button - Hidden when in full screen */}
      {!isFullScreen && (
        <div className="absolute top-10 left-1/2 transform -translate-x-1/2 flex gap-3 z-50">
        <button
          onClick={() => {
            if (document.documentElement.requestFullscreen) {
              document.documentElement.requestFullscreen();
            }
          }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-lg transition-colors"
        >
          FULL SCREEN
        </button>
        {!isFullScreen && (
          <button
            type="button"
            className={`px-4 py-2 rounded-lg font-bold text-lg cursor-default border ${
              offlineShowBadge
                ? cloudConnected
                  ? 'bg-purple-600 text-white border-transparent'
                  : 'bg-orange-900 text-orange-100 border-orange-600'
                : 'bg-purple-600 text-white border-transparent'
            }`}
            disabled
            title={
              offlineShowBadge
                ? cloudConnected
                  ? 'WebSocket sync — show server bridges Railway (same as hosted Clock)'
                  : 'WebSocket sync — show server on LAN only, no Railway bridge'
                : 'Timer sync via WebSocket only'
            }
          >
            {offlineShowBadge
              ? cloudConnected
                ? 'WEBSOCKET ONLY'
                : 'LAN WEBSOCKET'
              : 'WEBSOCKET ONLY'}
          </button>
        )}
        </div>
      )}


      {/* Cue Cards / Teleprompter clock feed — max 16:9; timers stay along bottom */}
      {stageFeedActive ? (
        <div
          className="absolute inset-x-0 z-20 grid place-items-start justify-items-center px-2"
          style={{
            top: '0.75rem',
            bottom: activeStageMessage ? '26%' : '16%',
            containerType: 'size',
          }}
        >
          <div
            className="relative overflow-hidden border-2 border-white/80 bg-black shadow-2xl"
            style={{
              aspectRatio: '16 / 9',
              width: 'min(100cqw, calc(100cqh * 16 / 9))',
              height: 'min(100cqh, calc(100cqw * 9 / 16))',
            }}
          >
            {cueClockActive && cueClockFeed?.slide ? (
              <CueCardClockOverlay
                slide={cueClockFeed.slide}
                comments={cueClockFeed.comments}
                className="h-full w-full"
              />
            ) : null}
            {teleprompterClockActive && teleprompterClockFeed ? (
              <TeleprompterClockOverlay
                feed={teleprompterClockFeed}
                className="h-full w-full"
              />
            ) : null}
          </div>
        </div>
      ) : null}

      {stageFeedActive && activeStageMessage ? (
        <div className="absolute bottom-[16%] left-1/2 z-30 w-[min(90vw,56rem)] -translate-x-1/2 rounded-lg border-2 border-white/80 bg-black/70 px-6 py-3 text-center text-2xl font-bold text-white md:text-3xl">
          {activeStageMessage.message}
        </div>
      ) : null}

      {/* Message Display */}
      {activeStageMessage && !stageFeedActive && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ transform: 'translateY(-40px)' }}>
          <div 
            className={`font-bold text-white bg-black bg-opacity-50 rounded-lg border-4 border-white text-center flex items-center justify-center ${
              activeStageMessage.flashing ? 'ros-timer-message-flash' : ''
            }`}
            style={{
              width: '80vw',
              minHeight: '50vh',
              maxHeight: '70vh',
              lineHeight: '1.2',
              whiteSpace: 'pre-line',
              overflow: 'visible',
              padding: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              wordWrap: 'break-word'
            }}
          >
            {(() => {
              const displayMessage = activeStageMessage.message || '';
              // Break long messages into multiple lines
              const words = displayMessage.split(' ');
              let formattedMessage;
              let lineCount;
              
              if (words.length <= 3) {
                formattedMessage = displayMessage; // Keep short messages on one line
                lineCount = 1;
              } else if (words.length <= 6) {
                // Break into 2 lines
                const mid = Math.ceil(words.length / 2);
                formattedMessage = words.slice(0, mid).join(' ') + '\n' + words.slice(mid).join(' ');
                lineCount = 2;
              } else if (words.length <= 10) {
                // Break into 3 lines
                const third = Math.ceil(words.length / 3);
                formattedMessage = words.slice(0, third).join(' ') + '\n' + 
                       words.slice(third, third * 2).join(' ') + '\n' + 
                       words.slice(third * 2).join(' ');
                lineCount = 3;
              } else {
                // Break into 4 lines for very long messages
                const quarter = Math.ceil(words.length / 4);
                formattedMessage = words.slice(0, quarter).join(' ') + '\n' + 
                       words.slice(quarter, quarter * 2).join(' ') + '\n' + 
                       words.slice(quarter * 2, quarter * 3).join(' ') + '\n' + 
                       words.slice(quarter * 3).join(' ');
                lineCount = 4;
              }
              
              // Calculate font size based on message length and line count
              // Account for descenders (g, j, p, q, y) that hang below baseline
              let fontSize;
              const hasDescenders = /[gjpqy]/.test(displayMessage.toLowerCase());
              
              if (words.length <= 3) {
                fontSize = hasDescenders ? 'clamp(3rem, 12vw, 16rem)' : 'clamp(3.5rem, 13.5vw, 18rem)';
              } else if (words.length <= 6) {
                fontSize = hasDescenders ? 'clamp(1.9rem, 8vw, 12rem)' : 'clamp(2.25rem, 9vw, 13.5rem)';
              } else if (words.length <= 10) {
                fontSize = hasDescenders ? 'clamp(1.4rem, 6vw, 9rem)' : 'clamp(1.6rem, 7vw, 10.5rem)';
              } else {
                fontSize = hasDescenders ? 'clamp(0.9rem, 4vw, 6rem)' : 'clamp(1.1rem, 5vw, 7rem)';
              }
              
              return (
                <div style={{ fontSize }}>
                  {formattedMessage}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Secondary Timer Display - Only when NO message is active */}
      {(() => {
        // Check if we have a secondary timer in either mode
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (!currentSecondaryTimer) return false;
          
          // Check if there's a message active - if so, don't show this timer (use the new layout instead)
          const hasMessage = layoutCrowded;
          if (hasMessage) return false;
          
          console.log('🔍 Clock: Secondary timer data:', {
            is_running: currentSecondaryTimer.is_running,
            is_active: currentSecondaryTimer.is_active,
            remaining_seconds: currentSecondaryTimer.remaining_seconds,
            duration_seconds: currentSecondaryTimer.duration_seconds
          });
          
          // Hide timer if it's not running
          if (!currentSecondaryTimer.is_running) {
            console.log('🔍 Sub-cue timer not running - hiding');
            return false;
          }
          
          // Check if timer has expired (reached zero or negative)
          if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
            const now = new Date();
            const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
            const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
            const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
            const remaining = Math.max(0, totalDuration - elapsed);
            
            // Hide timer if it has expired (remaining <= 0)
            if (remaining <= 0) return false;
          }
          
          return true;
        } else {
          // Clock always runs in Supabase-only mode
          return false;
        }
      })() && (
        (() => {
          const hasMessage = supabaseOnly
            ? !!(supabaseMessage && supabaseMessage.enabled)
            : !!(messageEnabled && message) || !!(supabaseMessage && supabaseMessage.enabled);

          const labelNode = (() => {
            const currentSecondaryTimer = supabaseOnly ? hybridTimerData?.secondaryTimer : secondaryTimer;
            if (!currentSecondaryTimer) return null;
            if (!supabaseOnly) return <span>ALT</span>;
            return (
              <AltTimerBadge
                timer={currentSecondaryTimer}
                scheduleItems={scheduleItems}
                statusPrefix={secondaryStatusPrefix}
                resolumeSuffix={secondaryResolumeLabel}
              />
            );
          })();

          const remainingSeconds = (() => {
            const currentSecondaryTimer = supabaseOnly ? hybridTimerData?.secondaryTimer : secondaryTimer;
            if (!currentSecondaryTimer) return 0;
            const _ = secondaryTimerUpdate;
            if (supabaseOnly) {
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const syncedNow = Date.now() + clockOffset;
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((syncedNow - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                return Math.max(0, totalDuration - elapsed);
              }
              return currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
            }
            return currentSecondaryTimer.remaining || 0;
          })();

          const formatSecondary = (remaining: number) => {
            const absRemaining = Math.abs(remaining);
            const hours = Math.floor(absRemaining / 3600);
            const minutes = Math.floor((absRemaining % 3600) / 60);
            const seconds = absRemaining % 60;
            const prefix = remaining < 0 ? '-' : '';
            if (hours === 0) {
              return `${prefix}${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            return `${prefix}${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
          };

          const hours = Math.floor(Math.abs(remainingSeconds) / 3600);
          const largeTimeClass = hours === 0
            ? 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]'
            : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';

          // Large (no message): same flex shell + progress-bar spacer as main timer → same Y axis
          if (!hasMessage) {
            return (
              <div className="flex-1 flex flex-col items-center justify-center animate-in fade-in duration-500">
                <div
                  className={`mb-[-50px] text-center ${secondaryDisplayColor} text-xl md:text-2xl lg:text-3xl font-bold whitespace-nowrap`}
                  style={{ lineHeight: '1.2' }}
                >
                  {labelNode}
                </div>
                <div className="text-center">
                  <div
                    className={`${secondaryDisplayColor} font-mono font-bold ${largeTimeClass}`}
                    style={{ lineHeight: '1' }}
                  >
                    {formatSecondary(remainingSeconds)}
                  </div>
                </div>
                {/* Same height as main timer progress bar so digits share the same Y */}
                <div className="w-full max-w-5xl mt-0 h-8" aria-hidden />
              </div>
            );
          }

          // With message: compact secondary in lower area
          return (
            <div className="absolute bottom-20 right-1/3 transform translate-x-1/2 flex flex-col items-center animate-in fade-in duration-500">
              <div
                className={`absolute left-1/2 -translate-x-1/2 ${secondaryDisplayColor} text-lg md:text-xl lg:text-2xl font-bold whitespace-nowrap`}
                style={{ lineHeight: '1.2', bottom: 'calc(5rem - 25px)' }}
              >
                {labelNode}
              </div>
              <div className={`${secondaryDisplayColor} font-mono font-bold text-3xl md:text-4xl lg:text-5xl`} style={{ lineHeight: '1' }}>
                {formatSecondary(remainingSeconds)}
              </div>
            </div>
          );
        })()
      )}

      {/* Main Timer Layout - When there's both a secondary timer AND a message (small layout) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Check if timer has expired (reached zero or negative)
            if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
              const elapsed = calculateElapsed(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
              const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
              const remaining = Math.max(0, totalDuration - elapsed);
              
              // Only show as active if timer hasn't expired
              hasSecondaryTimer = remaining > 0;
            } else {
              hasSecondaryTimer = true; // Show if timer is stopped but not expired
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && hasMessage;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-[18%] -translate-x-1/2 min-w-[11rem]`}>
          {/* Overtime Indicator - Above main timer when both message and secondary timer are active */}
          {getRemainingTime() < 0 && (
            <div className="mb-1">
              <div className="font-bold text-red-500 text-lg leading-none">
                OVER TIME
              </div>
            </div>
          )}
          
          <div 
            className="font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl leading-none"
            style={{ color: getProgressBarColor() }}
          >
            {formatTime(getRemainingTime())}
          </div>
          {/* Main progress bar under small main timer */}
          <div className="w-40 mx-auto mt-2 bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative h-2">
            <div
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{
                width: `${Math.min(100, Math.max(0, getRemainingPercentage()))}%`,
                background: getProgressBarColor(),
              }}
            />
          </div>
        </div>
      )}

      {/* Sub-cue Timer Display - When there's both a secondary timer AND a message (small layout) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Check if timer has expired (reached zero or negative)
            if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
              const elapsed = calculateElapsed(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
              const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
              const remaining = Math.max(0, totalDuration - elapsed);
              
              // Only show as active if timer hasn't expired
              hasSecondaryTimer = remaining > 0;
            } else {
              hasSecondaryTimer = true; // Show if timer is stopped but not expired
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && hasMessage;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} right-[18%] translate-x-1/2 min-w-[11rem] ${secondaryDisplayColor}`}>
          {/* Small secondary: ALT + CUE only — same scale as small main */}
          <div className="mb-1 text-lg font-bold leading-none">
            <AltTimerBadge
              timer={hybridTimerData?.secondaryTimer}
              scheduleItems={scheduleItems}
              cueOnly
            />
          </div>
          
          {/* Sub-cue Countdown Timer */}
          <div className="font-mono text-3xl md:text-4xl font-bold leading-none">
            {(() => {
              const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
              const elapsed = calculateElapsed(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
              const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
              const remaining = Math.max(0, totalDuration - elapsed);
              
              const hours = Math.floor(remaining / 3600);
              const minutes = Math.floor((remaining % 3600) / 60);
              const seconds = remaining % 60;
              
              if (hours > 0) {
                return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
              } else {
                return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
              }
            })()}
          </div>
          {/* Secondary progress bar under small alt timer */}
          <div className="w-40 mx-auto mt-2 bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative h-2">
            <div
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{
                width: `${(() => {
                  const t = hybridTimerData?.secondaryTimer;
                  if (!t) return 0;
                  const _ = secondaryTimerUpdate;
                  const total = t.duration_seconds || t.duration || 0;
                  if (total <= 0) return 0;
                  const elapsed = calculateElapsed(t.started_at || t.created_at);
                  return Math.min(100, Math.max(0, ((total - elapsed) / total) * 100));
                })()}%`,
                backgroundColor: isResolumeSynced(secondarySubTimer) ? '#fde047' : '#fb923c',
              }}
            />
          </div>
        </div>
      )}

      {/* Main Timer Layout - Only when no secondary timer and no message */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Hide timer if it's not running
            if (!currentSecondaryTimer.is_running) {
              hasSecondaryTimer = false;
            } else {
              // Check if timer has expired (reached zero or negative)
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const now = new Date();
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                const remaining = Math.max(0, totalDuration - elapsed);
                
                // Only show as active if timer hasn't expired
                hasSecondaryTimer = remaining > 0;
              } else {
                hasSecondaryTimer = true; // Show if timer is stopped but not expired
              }
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return !hasSecondaryTimer && !hasMessage;
      })() && (
        <div className="flex-1 flex flex-col items-center justify-center">
          {useTimeOfDay ? (
            /* Large Time of Day in center; progress bar only when not TOD Only */
            <>
              <div className="text-center">
                <div 
                  className="font-mono font-bold text-[8rem] md:text-[9.5rem] lg:text-[11rem] text-white"
                >
                  {formatTimeOfDay(currentTime)}
                </div>
              </div>
              {showTimeRemainingAndBar && (
                <div className="w-full max-w-5xl mt-0">
                  <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                    <div 
                      className="h-full transition-all duration-1000 absolute top-0 right-0"
                      style={{ 
                        width: `${getRemainingPercentage()}%`,
                        background: getProgressBarColor()
                      }}
                    />
                  </div>
                </div>
              )}
            </>
          ) : useCountUp ? (
            /* Count Up: elapsed time; OVER TIME + red when overtime; bar fills up */
            <>
              {isOvertimeCountUp ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className="font-bold text-red-500 text-5xl leading-none">
                    OVER TIME
                  </div>
                  <div className="font-mono text-red-400 text-2xl mt-1 leading-none">
                    +{formatTime(overtimeAmount)}
                  </div>
                </div>
              ) : null}
              <div className="text-center">
                <div 
                  className={`font-mono font-bold ${(() => {
                    const hours = Math.floor(Math.abs(elapsedForDisplay) / 3600);
                    return hours === 0 
                      ? 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]'
                      : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';
                  })()}`}
                  style={{ color: getCountUpProgressBarColor() }}
                >
                  {formatTime(elapsedForDisplay)}
                </div>
              </div>
              <div className="w-full max-w-5xl mt-0">
                <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                  <div 
                    className="h-full transition-all duration-1000 absolute top-0 left-0"
                    style={{ 
                      width: `${getCountUpBarPercentage()}%`,
                      background: getCountUpProgressBarColor()
                    }}
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              {getRemainingTime() < 0 ? (
                <div className="mb-[-50px] text-center relative z-10 translate-y-10">
                  <div className="font-bold text-red-500 text-5xl leading-none">
                    OVER TIME
                  </div>
                </div>
              ) : null}
              {/* Countdown Timer - Centered */}
              <div className="text-center">
                <div 
                  className={`font-mono font-bold ${(() => {
                    const remaining = getRemainingTime();
                    const hours = Math.floor(Math.abs(remaining) / 3600);
                    return hours === 0 
                      ? 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]'
                      : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';
                  })()}`}
                  style={{ color: getProgressBarColor() }}
                >
                  {formatTime(getRemainingTime())}
                </div>
              </div>
              {/* Progress Bar - 0px below timer */}
              <div className="w-full max-w-5xl mt-0">
                <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
                  <div 
                    className="h-full transition-all duration-1000 absolute top-0 right-0"
                    style={{ 
                      width: `${getRemainingPercentage()}%`,
                      background: getProgressBarColor()
                    }}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when message is active */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Hide timer if it's not running
            if (!currentSecondaryTimer.is_running) {
              hasSecondaryTimer = false;
            } else {
              // Check if timer has expired (reached zero or negative)
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const now = new Date();
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                const remaining = Math.max(0, totalDuration - elapsed);
                
                // Only show as active if timer hasn't expired
                hasSecondaryTimer = remaining > 0;
              } else {
                hasSecondaryTimer = true; // Show if timer is stopped but not expired
              }
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasMessage && !hasSecondaryTimer;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-1/2 transform -translate-x-1/2`}>
          {useTimeOfDay ? (
            <div className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-white">
              {formatTimeOfDay(currentTime)}
            </div>
          ) : useCountUp ? (
            <>
              {isOvertimeCountUp && (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              )}
              <div 
                className="font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl"
                style={{ color: getCountUpProgressBarColor() }}
              >
                {formatTime(elapsedForDisplay)}
              </div>
            </>
          ) : (
            <>
              {getRemainingTime() < 0 && (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              )}
              <div 
                className="font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl"
                style={{ color: getProgressBarColor() }}
              >
                {formatTime(getRemainingTime())}
              </div>
            </>
          )}
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Hide timer if it's not running
            if (!currentSecondaryTimer.is_running) {
              hasSecondaryTimer = false;
            } else {
              // Check if timer has expired (reached zero or negative)
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const now = new Date();
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                const remaining = Math.max(0, totalDuration - elapsed);
                
                // Only show as active if timer hasn't expired
                hasSecondaryTimer = remaining > 0;
              } else {
                hasSecondaryTimer = true; // Show if timer is stopped but not expired
              }
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && !hasMessage;
      })() && (
        <div className="text-center transition-all duration-500 ease-in-out absolute bottom-20 left-1/2 transform -translate-x-1/2">
          {useTimeOfDay ? (
            <div className="font-mono font-bold text-3xl md:text-4xl lg:text-5xl text-white">
              {formatTimeOfDay(currentTime)}
            </div>
          ) : useCountUp ? (
            <>
              {isOvertimeCountUp && (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              )}
              <div 
                className="font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl"
                style={{ color: getCountUpProgressBarColor() }}
              >
                {formatTime(elapsedForDisplay)}
              </div>
            </>
          ) : (
            <>
              {getRemainingTime() < 0 && (
                <div className="mb-2">
                  <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">OVER TIME</div>
                </div>
              )}
              <div 
                className="font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl"
                style={{ color: getProgressBarColor() }}
              >
                {formatTime(getRemainingTime())}
              </div>
            </>
          )}
        </div>
      )}

      {/* Progress Bar - Positioned at bottom when message is active */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Hide timer if it's not running
            if (!currentSecondaryTimer.is_running) {
              hasSecondaryTimer = false;
            } else {
              // Check if timer has expired (reached zero or negative)
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const now = new Date();
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                const remaining = Math.max(0, totalDuration - elapsed);
                
                // Only show as active if timer hasn't expired
                hasSecondaryTimer = remaining > 0;
              } else {
                hasSecondaryTimer = true; // Show if timer is stopped but not expired
              }
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasMessage && !hasSecondaryTimer;
      })() && (
        <div className={`w-full transition-all duration-500 ease-in-out absolute ${crowdedBarBottom} left-1/2 transform -translate-x-1/2 max-w-2xl`}>
          <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-2">
            <div 
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{ 
                width: `${getRemainingPercentage()}%`,
                background: getProgressBarColor()
              }}
            />
          </div>
        </div>
      )}

      {/* Progress Bar - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          const currentSecondaryTimer = hybridTimerData?.secondaryTimer;
          if (currentSecondaryTimer) {
            // Hide timer if it's not running
            if (!currentSecondaryTimer.is_running) {
              hasSecondaryTimer = false;
            } else {
              // Check if timer has expired (reached zero or negative)
              if (currentSecondaryTimer.is_running && currentSecondaryTimer.is_active) {
                const now = new Date();
                const startedAt = new Date(currentSecondaryTimer.started_at || currentSecondaryTimer.created_at);
                const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
                const totalDuration = currentSecondaryTimer.duration_seconds || currentSecondaryTimer.duration || 0;
                const remaining = Math.max(0, totalDuration - elapsed);
                
                // Only show as active if timer hasn't expired
                hasSecondaryTimer = remaining > 0;
              } else {
                hasSecondaryTimer = true; // Show if timer is stopped but not expired
              }
            }
          }
        } else {
          hasSecondaryTimer = !!secondaryTimer;
        }
        
        const hasMessage = layoutCrowded;
        
        return hasSecondaryTimer && !hasMessage;
      })() && (
        <div className="w-full transition-all duration-500 ease-in-out absolute bottom-8 left-1/2 transform -translate-x-1/2 max-w-2xl">
          <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-2">
            <div 
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{ 
                width: `${getRemainingPercentage()}%`,
                background: getProgressBarColor()
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Clock;
