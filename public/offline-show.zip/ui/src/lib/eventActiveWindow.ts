/** Local calendar-day helpers for upcoming vs past event lists. */

export function startOfTodayLocal(now: Date = new Date()): Date {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

/** Parse YYYY-MM-DD (or ISO …T00:00:00.000Z) as a local calendar date (no UTC→local day shift). */
export function parseEventDateLocal(dateStr: string): Date | null {
  const raw = String(dateStr || '').trim();
  if (!raw) return null;
  const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) {
    const y = Number(m[1]);
    const mo = Number(m[2]);
    const d = Number(m[3]);
    if (![y, mo, d].every((n) => Number.isFinite(n))) return null;
    return new Date(y, mo - 1, d);
  }
  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return null;
  return new Date(parsed.getUTCFullYear(), parsed.getUTCMonth(), parsed.getUTCDate());
}

/**
 * Last calendar day of an event.
 * 1-day event starting 8/5 → ends 8/5.
 * 2-day event starting 8/5 → ends 8/6.
 */
export function getEventLastDay(start: Date, numberOfDays?: number | null): Date {
  const days = Math.max(1, Math.floor(Number(numberOfDays) || 1));
  const end = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  end.setDate(end.getDate() + (days - 1));
  return end;
}

/** Still active/upcoming through the last day (inclusive). */
export function isEventUpcoming(
  dateStr: string,
  numberOfDays?: number | null,
  today: Date = startOfTodayLocal()
): boolean {
  const start = parseEventDateLocal(dateStr);
  if (!start) return true;
  return getEventLastDay(start, numberOfDays) >= today;
}

/** Past only after the last day has ended. */
export function isEventPast(
  dateStr: string,
  numberOfDays?: number | null,
  today: Date = startOfTodayLocal()
): boolean {
  const start = parseEventDateLocal(dateStr);
  if (!start) return false;
  return getEventLastDay(start, numberOfDays) < today;
}

/** Sort key for YYYY-MM-DD (local). Missing/invalid dates sort last. */
export function eventDateSortKey(dateStr: string | null | undefined): number {
  const d = parseEventDateLocal(String(dateStr || ''));
  return d ? d.getTime() : Number.POSITIVE_INFINITY;
}

/**
 * Upcoming: soonest first. Past: most recent first. All: chronological ascending.
 */
export function compareEventsByDateForFilter(
  a: { date?: string | null },
  b: { date?: string | null },
  filter: 'all' | 'upcoming' | 'past'
): number {
  const ka = eventDateSortKey(a.date);
  const kb = eventDateSortKey(b.date);
  if (ka !== kb) {
    return filter === 'past' ? kb - ka : ka - kb;
  }
  return 0;
}
