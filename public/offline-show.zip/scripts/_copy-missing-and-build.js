/**
 * Build offline UI; on unresolved ../lib|components|services|contexts|types|assets imports,
 * copy from main src/ (or stub) and retry.
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const offlineRoot = path.join(__dirname, '..');
const repoRoot = path.join(offlineRoot, '..');
const mainSrc = path.join(repoRoot, 'src');
const offSrc = path.join(offlineRoot, 'ui', 'src');

function copyFromMain(relPosix) {
  const candidates = [
    relPosix,
    relPosix + '.ts',
    relPosix + '.tsx',
    relPosix + '/index.ts',
    relPosix + '/index.tsx',
  ];
  for (const c of candidates) {
    const from = path.join(mainSrc, c);
    if (fs.existsSync(from) && fs.statSync(from).isFile()) {
      const to = path.join(offSrc, c);
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(from, to);
      console.log('copied', c);
      return true;
    }
  }
  console.warn('could not find main file for', relPosix);
  return false;
}

const MAX = 50;
for (let i = 0; i < MAX; i++) {
  let out = '';
  try {
    out = execSync('node scripts/build-ui.js', {
      cwd: offlineRoot,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    console.log(out);
    console.log('BUILD OK');
    process.exit(0);
  } catch (e) {
    out = String(e.stdout || '') + '\n' + String(e.stderr || '') + '\n' + String(e.message || '');
    const tail = out.slice(-2000);
    console.log(tail);

    let m =
      out.match(/Could not resolve "\.\.\/(lib|components|services|contexts|types|assets)\/([^"?]+)/) ||
      out.match(/Failed to resolve import "\.\.\/(lib|components|services|contexts|types|assets)\/([^"?]+)/) ||
      out.match(/from "src\/(lib|components|services|contexts|types|assets)\/([^"?]+)/);

    if (!m) {
      // npm package missing?
      const pkg = out.match(/Could not resolve "([a-z0-9@][^"]*)" from/);
      if (pkg && !pkg[1].startsWith('.') && !pkg[1].startsWith('/')) {
        console.error('Missing npm package:', pkg[1], '— install into offline-show/ui or stub the importer');
        process.exit(1);
      }
      console.error('Unrecognized build error — stopping');
      process.exit(1);
    }

    const kind = m[1];
    let rest = m[2].replace(/\.tsx?$/, '').replace(/\?url$/, '');
    if (kind === 'assets') {
      // copy whole file path under assets
      const assetRel = 'assets/' + rest;
      const from = path.join(mainSrc, assetRel);
      if (fs.existsSync(from)) {
        const to = path.join(offSrc, assetRel);
        fs.mkdirSync(path.dirname(to), { recursive: true });
        fs.copyFileSync(from, to);
        console.log('copied', assetRel);
        continue;
      }
    }

    if (!copyFromMain(`${kind}/${rest}`)) process.exit(1);
  }
}
console.error('Exceeded max copy iterations');
process.exit(1);
