const fs = require('fs');
const path = require('path');
const p = path.join(__dirname, '../ui/src/pages/RunOfShowPage.tsx');
let t = fs.readFileSync(p, 'utf8');
if (!/clockOffset:\s*0/.test(t.slice(t.indexOf('reconnectTimerStateRef'), t.indexOf('reconnectTimerStateRef') + 800))) {
  t = t.replace(
    /(userRole: 'OPERATOR' as string,\r?\n    completedCues: \{\} as Record<number, boolean>,)(\r?\n  \}\);)/,
    '$1$2'.replace(
      'completedCues: {} as Record<number, boolean>,',
      'completedCues: {} as Record<number, boolean>,\n    clockOffset: 0,'
    )
  );
  // clearer replace
  t = fs.readFileSync(p, 'utf8');
  t = t.replace(
    /userRole: 'OPERATOR' as string,\r?\n    completedCues: \{\} as Record<number, boolean>,\r?\n  \}\);/,
    "userRole: 'OPERATOR' as string,\n    completedCues: {} as Record<number, boolean>,\n    clockOffset: 0,\n  });"
  );
  fs.writeFileSync(p, t);
  console.log('patched clockOffset onto reconnectTimerStateRef');
} else {
  console.log('clockOffset already present');
}
