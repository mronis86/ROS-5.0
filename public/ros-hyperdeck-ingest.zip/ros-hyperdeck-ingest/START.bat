@echo off
setlocal
cd /d "%~dp0"
echo Starting ROS HyperDeck Ingest...
if not exist "%~dp0ROS-HyperDeck-Ingest.exe" (
  echo ERROR: Missing ROS-HyperDeck-Ingest.exe next to this START.bat
  echo Unzip the full ros-hyperdeck-ingest folder and run START.bat from inside it.
  pause
  exit /b 1
)
start "" "%~dp0ROS-HyperDeck-Ingest.exe"
endlocal
