ROS HyperDeck Ingest (portable — no Python install)

1. Unzip this folder and double-click START.bat
   (or run ROS-HyperDeck-Ingest.exe from the same folder).
2. Paste your Railway API URL and Integration token (ros_itok_…, read scope).
3. Select the event, connect to the HyperDeck, set target folder, Start follow.

Settings: %LOCALAPPDATA%\ros-hyperdeck-ingest\config.json

Records cues marked Record when the timer is running; copies clips on stop.
