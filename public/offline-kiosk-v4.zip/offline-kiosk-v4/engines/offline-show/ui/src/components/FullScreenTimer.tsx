import React, { useState, useEffect } from 'react';
import DriftStatusIndicator from './DriftStatusIndicator';
import { DatabaseService, TimerMessage } from '../services/database';
import { driftDetector } from '../services/driftDetector';
import {
  countdownColorForRemaining,
  useCountdownColorMode,
} from '../lib/countdownColor';
import { useOvertimeSign } from '../lib/overtimeSign';
import { OvertimeClockText } from '../lib/OvertimeClockText';
import { isPreshowTimerMessage, findTopPreshowCue } from '../lib/preshowCountdown';
import { shouldUsePreshowRainbow } from '../lib/usePreshowRainbow';
import { AltTimerBadge } from './AltTimerBadge';
import CueCardClockOverlay from './CueCardClockOverlay';
import {
  getLiveIndentedSubTimer,
  hasDualAltLayout,
  isOperatorAltTimer,
  resolveDisplaySecondaryTimer,
} from '../lib/operatorCountdown';
import TeleprompterClockOverlay, {
  type TeleprompterClockFeed,
} from './TeleprompterClockOverlay';
import PptClockOverlay from './PptClockOverlay';
import type { PptClockFeed } from '../lib/pptClockFeed';
import type { CueCardComment, CueCardSlide } from '../lib/cueCards';
import { resolveLiveCueLabel } from '../lib/cueDisplay';
import {
  flashPlanFromParent,
  isQaFlashPlan,
  shouldShowQaFlashReminder,
} from '../lib/qaPlan';
import { useQaFlashTimerLine } from '../hooks/useQaFlashTimerLine';

interface FullScreenTimerProps {
  isRunning?: boolean;
  elapsedTime?: number;
  totalDuration?: number;
  onClose?: () => void;
  message?: string;
  messageEnabled?: boolean;
  itemId?: number; // Add itemId for drift detection
  eventId?: string; // Add eventId for Supabase message loading
  supabaseMessage?: TimerMessage | null; // Add supabaseMessage prop
  mainTimer?: {
    cue: string;
    segmentName: string;
  } | null;
  secondaryTimer?: {
    itemId: number;
    remaining: number;
    duration: number;
    cue: string;
    segmentName: string;
  } | null;
  hybridTimerData?: any; // Add hybridTimerData prop for direct RunOfShowPage communication
  clockOffset?: number; // Add clockOffset for synced timer
  cueClockFeed?: {
    enabled: boolean;
    slide: CueCardSlide | null;
    comments: CueCardComment[];
  } | null;
  teleprompterClockFeed?: TeleprompterClockFeed | null;
  pptClockFeed?: PptClockFeed | null;
  /** When false (session disconnect / Displays paused), stop hybrid HTTP polls. */
  networkEnabled?: boolean;
}

const FullScreenTimer: React.FC<FullScreenTimerProps> = ({
  isRunning = false,
  elapsedTime = 0,
  totalDuration = 0, // Default to 0 when no timer is running
  onClose,
  message = '',
  messageEnabled = false,
  itemId,
  eventId,
  supabaseMessage = null,
  mainTimer = null,
  secondaryTimer = null,
  hybridTimerData = null,
  clockOffset = 0,
  cueClockFeed = null,
  teleprompterClockFeed = null,
  pptClockFeed = null,
  networkEnabled = true,
}) => {
  const [timerProgress, setTimerProgress] = useState<{ elapsed: number; total: number }>({
    elapsed: elapsedTime,
    total: totalDuration
  });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullScreen, setIsFullScreen] = useState(false);
  // Use supabaseMessage prop instead of internal state
  const [messageLoading, setMessageLoading] = useState(false);
  const [supabaseOnly, setSupabaseOnly] = useState(false);
  const [hybridPolling, setHybridPolling] = useState<NodeJS.Timeout | null>(null);
  const [secondaryTimerUpdate, setSecondaryTimerUpdate] = useState(0);
  const [lastActiveTimerId, setLastActiveTimerId] = useState<string | null>(null);
  const [lastActiveItemId, setLastActiveItemId] = useState<number | null>(null);
  const [lastActiveStartTime, setLastActiveStartTime] = useState<string | null>(null);
  const [localTimerInterval, setLocalTimerInterval] = useState<NodeJS.Timeout | null>(null);
  const [serverSyncedTimers, setServerSyncedTimers] = useState<Set<number>>(new Set());
  const countdownColorMode = useCountdownColorMode();
  const overtimeSign = useOvertimeSign();
  const stageMessageForColor =
    [hybridTimerData?.timerMessage, supabaseMessage].find((m: any) => m?.enabled) ?? null;
  const timerRunningForRainbow = !!(
    hybridTimerData?.activeTimer?.is_running && hybridTimerData?.activeTimer?.is_active
  );
  const hybridCueProgramType =
    hybridTimerData?.cueData?.programType ||
    hybridTimerData?.activeTimer?.program_type ||
    hybridTimerData?.activeTimer?.programType ||
    null;
  const activeTimerItemId =
    hybridTimerData?.activeTimer?.item_id ??
    hybridTimerData?.activeTimer?.itemId ??
    itemId ??
    null;
  const [topPreshowItemId, setTopPreshowItemId] = useState<number | null>(null);
  const [scheduleCueProgramType, setScheduleCueProgramType] = useState<string | null>(null);
  const [scheduleItems, setScheduleItems] = useState<any[]>([]);
  useEffect(() => {
    if (!eventId) {
      setTopPreshowItemId(null);
      setScheduleCueProgramType(null);
      setScheduleItems([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const data = await DatabaseService.getRunOfShowData(eventId);
        const items = Array.isArray(data?.schedule_items) ? data.schedule_items : [];
        let day: number | null = null;
        let cueProgramType: string | null = null;
        if (activeTimerItemId != null) {
          const idNum = Number(activeTimerItemId);
          const cue = items.find(
            (s: any) =>
              s?.id === activeTimerItemId ||
              String(s?.id) === String(activeTimerItemId) ||
              (Number.isFinite(idNum) && Number(s?.id) === idNum)
          );
          if (cue?.day != null) day = Number(cue.day) || 1;
          cueProgramType = cue?.programType || null;
        }
        const top = findTopPreshowCue(items, null, day);
        if (!cancelled) {
          setTopPreshowItemId(top?.id ?? null);
          setScheduleCueProgramType(cueProgramType);
          setScheduleItems(items);
        }
      } catch {
        if (!cancelled) {
          setTopPreshowItemId(null);
          setScheduleCueProgramType(null);
          setScheduleItems([]);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [eventId, activeTimerItemId]);
  const usePreshowRainbow = shouldUsePreshowRainbow(stageMessageForColor, {
    isRunning: timerRunningForRainbow,
    programType: hybridCueProgramType || scheduleCueProgramType,
    itemId: activeTimerItemId,
    topPreshowItemId,
  });

  const hasBlockingStageMessage = () => {
    const cueActive = !!(cueClockFeed?.enabled && cueClockFeed.slide);
    const teleActive = !!(
      teleprompterClockFeed?.enabled && teleprompterClockFeed.scriptText
    );
    const pptActive = !!pptClockFeed?.enabled;
    if (cueActive || teleActive || pptActive) return true;
    if (supabaseOnly) {
      return [hybridTimerData?.timerMessage, supabaseMessage].some(
        (m) => !!m?.enabled && !isPreshowTimerMessage(m)
      );
    }
    if (messageEnabled && message) return true;
    return !!(supabaseMessage?.enabled && !isPreshowTimerMessage(supabaseMessage));
  };

  const cueClockActive = !!(cueClockFeed?.enabled && cueClockFeed.slide);
  const teleprompterClockActive = !!(
    teleprompterClockFeed?.enabled && teleprompterClockFeed.scriptText
  );
  const pptClockActive = !!pptClockFeed?.enabled;
  const stageFeedActive = cueClockActive || teleprompterClockActive || pptClockActive;
  const activeFsMessage = [hybridTimerData?.timerMessage, supabaseMessage].find(
    (m: any) => m?.enabled && !isPreshowTimerMessage(m)
  ) || null;
  const crowdedTimerBottom = stageFeedActive ? 'bottom-12' : 'bottom-20';
  const crowdedBarBottom = stageFeedActive ? 'bottom-5' : 'bottom-8';
  // Large ALT: Op wins; indented alone uses this slot too
  const displaySecondaryTimer =
    resolveDisplaySecondaryTimer(hybridTimerData) ||
    (!isOperatorAltTimer(secondaryTimer) && secondaryTimer?.is_running
      ? secondaryTimer
      : null);
  const dualAltLayout = hasDualAltLayout(hybridTimerData);
  const isOpAlt = isOperatorAltTimer(displaySecondaryTimer);
  const secondaryDisplayColor = isOpAlt ? 'text-violet-400' : 'text-orange-400';

  const secondaryRemainingSeconds = (timer: any): number => {
    if (!timer) return 0;
    if (timer.started_at || timer.created_at) {
      const startedAt = new Date(timer.started_at || timer.created_at);
      const elapsed = Math.floor((Date.now() - startedAt.getTime()) / 1000);
      const totalDuration = timer.duration_seconds || timer.duration || 0;
      const rem = totalDuration - elapsed;
      return isOperatorAltTimer(timer) ? rem : Math.max(0, rem);
    }
    if (typeof timer.remaining === 'number') return Math.max(0, timer.remaining);
    return Number(timer.duration_seconds || timer.duration || 0) || 0;
  };

  const secondaryStillVisible = (timer: any): boolean => {
    if (!timer?.is_running) return false;
    if (isOperatorAltTimer(timer)) return true;
    return secondaryRemainingSeconds(timer) > 0;
  };

  const formatTimeBody = (seconds: number) => {
    const absSeconds = Math.abs(seconds);
    const hours = Math.floor(absSeconds / 3600);
    const minutes = Math.floor((absSeconds % 3600) / 60);
    const secs = Math.floor(absSeconds % 60);
    if (hours === 0) {
      return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatSecondaryTime = (remaining: number) => (
    <OvertimeClockText
      seconds={remaining}
      body={formatTimeBody(remaining)}
      sign={overtimeSign}
    />
  );

  const hasLargeAlt = secondaryStillVisible(displaySecondaryTimer);
  const indentedSubTimer = getLiveIndentedSubTimer(hybridTimerData);
  const hasIndentedSmall = dualAltLayout && secondaryStillVisible(indentedSubTimer);
  // Message crowding only — Op+indented dual keeps Op large center
  const layoutCrowdedFs = !!(
    (hybridTimerData?.timerMessage && hybridTimerData.timerMessage.enabled) ||
    (messageEnabled && message) ||
    (supabaseMessage && supabaseMessage.enabled) ||
    stageFeedActive
  );

  // Debug secondary timer prop (only when it changes)
  useEffect(() => {
    if (secondaryTimer) {
      console.log('🔍 Secondary timer prop updated:', {
        secondaryTimer,
        supabaseOnly,
        hasSecondaryTimer: !!secondaryTimer
      });
    }
  }, [secondaryTimer, supabaseOnly]);

  // Update timer progress when props change or hybrid data changes
  useEffect(() => {
    if (supabaseOnly && hybridTimerData?.activeTimer) {
      // Use hybrid data when in Supabase-only mode (Neon Only ON)
      const activeTimer = hybridTimerData.activeTimer;
      
      if (activeTimer.is_running && activeTimer.is_active) {
        // Timer is running - calculate remaining time
        const now = new Date();
        const startedAt = new Date(activeTimer.started_at);
        const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
        const total = activeTimer.duration_seconds || 0;
        const remaining = Math.max(0, total - elapsed);
        
        setTimerProgress({
          elapsed: elapsed,
          total: total
        });
      } else {
        // Timer is not running - show 0 elapsed
        setTimerProgress({
          elapsed: 0,
          total: activeTimer.duration_seconds || 0
        });
      }
    } else if (!supabaseOnly && hybridTimerData?.activeTimer) {
      // Use hybrid data when Neon Only is OFF (direct RunOfShowPage communication)
      const activeTimer = hybridTimerData.activeTimer;
      
      if (activeTimer.is_running && activeTimer.is_active) {
        // Timer is running - calculate remaining time
        const now = new Date();
        const startedAt = new Date(activeTimer.started_at);
        const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
        const total = activeTimer.duration_seconds || 0;
        const remaining = Math.max(0, total - elapsed);
        
        setTimerProgress({
          elapsed: elapsed,
          total: total
        });
      } else {
        // Timer is not running - show 0 elapsed
        setTimerProgress({
          elapsed: 0,
          total: activeTimer.duration_seconds || 0
        });
      }
    } else {
      // Use props data when no hybrid data is available
      setTimerProgress({
        elapsed: elapsedTime,
        total: totalDuration
      });
    }
  }, [elapsedTime, totalDuration, supabaseOnly, hybridTimerData]);

  // Update current time every second
  useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timeInterval);
  }, []);

  // Listen for full screen changes
  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);

  // Message loading is now handled by FullScreenTimerPage via WebSocket
  // No need for internal message loading

  // Hybrid mode: Fetch timer data from Supabase when supabaseOnly is true
  useEffect(() => {
    if (!supabaseOnly || !eventId || !networkEnabled) {
      // Clear any existing polling
      if (hybridPolling) {
        clearInterval(hybridPolling);
        setHybridPolling(null);
      }
      // Reset timer tracking when exiting hybrid mode
      setLastActiveTimerId(null);
      setLastActiveItemId(null);
      setLastActiveStartTime(null);
      
      // Clean up drift detection
      if (lastActiveTimerId) {
        const itemId = parseInt(lastActiveTimerId.split('_')[0]);
        driftDetector.stopMonitoring(itemId);
      }
      
      // Clear drift sync interval
      if (localTimerInterval) {
        clearInterval(localTimerInterval);
        setLocalTimerInterval(null);
      }
      
      // Clear server-synced timers
      setServerSyncedTimers(new Set());
      
      return;
    }

    const fetchHybridData = async () => {
      try {
        console.log('🔄 Fetching hybrid timer data from Supabase...');
        const data = await DatabaseService.getHybridTimerData(eventId);
        setHybridTimerData(data);
        console.log('✅ Hybrid timer data updated:', data);
        
        // Debug secondary timer data
        if (data?.secondaryTimer) {
          console.log('🔍 Secondary timer data:', data.secondaryTimer);
        } else {
          console.log('❌ No secondary timer data found');
        }
        
        // Debug sub-cue timers data
        if (data?.subCueTimers && data.subCueTimers.length > 0) {
          console.log('🔍 Sub-cue timers data:', data.subCueTimers);
          console.log('🔍 First sub-cue timer structure:', data.subCueTimers[0]);
        } else {
          console.log('❌ No sub-cue timers data found');
        }
        
        // Debug secondary timer data (might be using sub-cue timers as fallback)
        if (data?.secondaryTimer) {
          console.log('🔍 Secondary timer data (from sub-cue fallback):', data.secondaryTimer);
        }
        
        // Debug active timer data for CUE display
        if (data?.activeTimer) {
          console.log('🔍 Active timer data for CUE display:', {
            cue_display: data.activeTimer.cue_display,
            cue: data.activeTimer.cue,
            item_id: data.activeTimer.item_id,
            allFields: Object.keys(data.activeTimer),
            fullData: data.activeTimer
          });
        }
        
        // Debug last loaded cue data
        if (data?.lastLoadedCue) {
          console.log('🔍 Last loaded cue data:', {
            cue: data.lastLoadedCue.cue,
            cue_display: data.lastLoadedCue.cue_display,
            segment_name: data.lastLoadedCue.segment_name,
            allFields: Object.keys(data.lastLoadedCue),
            fullData: data.lastLoadedCue
          });
        }
        
        // Debug CUE data
        if (data?.cueData) {
          console.log('🔍 CUE data from schedule/items table:', {
            allFields: Object.keys(data.cueData),
            fullData: data.cueData
          });
        } else {
          console.log('🔍 No CUE data found from schedule/items tables');
        }
        
        // Debug the full active timer data to see what fields are available
        if (data?.activeTimer) {
          console.log('🔍 Full active timer data structure:', data.activeTimer);
        }
        
        // Check if active timer has changed (cue jump detection)
        if (data?.activeTimer && supabaseOnly) {
          const currentActiveTimerId = `${data.activeTimer.item_id}_${data.activeTimer.started_at}`;
          const currentItemId = data.activeTimer.item_id;
          
          if (lastActiveTimerId && lastActiveTimerId !== currentActiveTimerId) {
            console.log('🔄 Active timer changed - stopping secondary timer');
            console.log('🔄 Previous timer:', lastActiveTimerId);
            console.log('🔄 New timer:', currentActiveTimerId);
            // Clear secondary timer when main timer changes
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null
            }));
          }
          
          // Also check if the item_id changed (new cue loaded) - this should stop sub-cue timer
          if (lastActiveItemId && lastActiveItemId !== currentItemId) {
            console.log('🔄 New cue loaded - stopping secondary timer');
            console.log('🔄 Previous item_id:', lastActiveItemId);
            console.log('🔄 New item_id:', currentItemId);
            // Clear secondary timer when new cue is loaded
            setHybridTimerData(prev => ({
              ...prev,
              secondaryTimer: null
            }));
          }
          
          // Check if the start time changed (timer paused/resumed/restarted)
          const currentStartTime = data.activeTimer.started_at;
          if (lastActiveStartTime && lastActiveStartTime !== currentStartTime) {
            console.log('🔄 Timer start time changed - restarting local timer');
            console.log('🔄 Previous start time:', lastActiveStartTime);
            console.log('🔄 New start time:', currentStartTime);
            // The local timer will automatically restart due to the dependency change
          }
          
          // Start drift detection for the new active timer
          if (data.activeTimer.is_running && data.activeTimer.is_active && data.activeTimer.started_at) {
            const startedAt = new Date(data.activeTimer.started_at);
            const duration = data.activeTimer.duration_seconds;
            
            console.log(`🔄 Starting drift detection for timer ${currentItemId} with duration ${duration}s`);
            
            // Stop any existing drift detection
            driftDetector.stopMonitoring(currentItemId);
            
            // Start drift detection for the new timer
            driftDetector.startMonitoring(
              currentItemId,
              startedAt,
              duration,
              (serverElapsed) => {
                console.log(`🔄 DriftDetector: Syncing timer ${currentItemId} with server elapsed: ${serverElapsed}s`);
                // Note: We don't update timer progress here anymore - let the local timer handle it
                // The drift detector is just for monitoring, not for UI updates
                
                // Mark this timer as server-synced for monitoring purposes
                setServerSyncedTimers(prev => new Set(prev).add(currentItemId));
              }
            );
            
            // Set up periodic drift sync
            const driftSyncInterval = setInterval(async () => {
              try {
                console.log(`🔄 DriftDetector: Starting periodic sync for timer ${currentItemId}`);
                await driftDetector.forceSync(currentItemId, async () => {
                  const activeTimer = await DatabaseService.getActiveTimer(eventId);
                  const serverElapsed = activeTimer?.elapsed_seconds || 0;
                  console.log(`🔄 DriftDetector: Server returned elapsed: ${serverElapsed}s for timer ${currentItemId}`);
                  return serverElapsed;
                });
              } catch (error) {
                console.warn(`⚠️ DriftDetector: Failed to sync timer ${currentItemId}:`, error);
              }
            }, 30000); // Force sync every 30 seconds
            
            // Store the drift sync interval for cleanup
            setLocalTimerInterval(driftSyncInterval);
          }
          
          setLastActiveTimerId(currentActiveTimerId);
          setLastActiveItemId(currentItemId);
          setLastActiveStartTime(currentStartTime);
        } else if (!data?.activeTimer && lastActiveTimerId && supabaseOnly) {
          // Active timer stopped completely - stop secondary timer and drift detection
          console.log('🔄 Active timer stopped - stopping secondary timer and drift detection');
          setHybridTimerData(prev => ({
            ...prev,
            secondaryTimer: null
          }));
          
          // Stop drift detection
          if (lastActiveTimerId) {
            const itemId = parseInt(lastActiveTimerId.split('_')[0]);
            driftDetector.stopMonitoring(itemId);
            setServerSyncedTimers(prev => {
              const newSet = new Set(prev);
              newSet.delete(itemId);
              return newSet;
            });
          }
          
          // Clear drift sync interval
          if (localTimerInterval) {
            clearInterval(localTimerInterval);
            setLocalTimerInterval(null);
          }
          
          setLastActiveTimerId(null);
          setLastActiveItemId(null);
          setLastActiveStartTime(null);
        }
      } catch (error) {
        console.error('❌ Error fetching hybrid timer data:', error);
      }
    };

    // Fetch immediately
    fetchHybridData();

    // Poll every 3 seconds when in hybrid mode
    const interval = setInterval(fetchHybridData, 3000);
    setHybridPolling(interval);

    return () => {
      clearInterval(interval);
      setHybridPolling(null);
    };
  }, [supabaseOnly, eventId, networkEnabled]);

  // Update secondary / operator ALT timer every second
  useEffect(() => {
    const active =
      !!displaySecondaryTimer?.is_running ||
      !!displaySecondaryTimer?.isActive;
    if (!active) return;

    const interval = setInterval(() => {
      setSecondaryTimerUpdate(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [displaySecondaryTimer]);

  // Always run local timer for smooth updates in both Neon Only ON and OFF modes
  useEffect(() => {
    if (!hybridTimerData?.activeTimer) return;

    const activeTimer = hybridTimerData.activeTimer;
    const itemId = activeTimer.item_id;
    
    if (activeTimer.is_running && activeTimer.is_active && activeTimer.started_at) {
      const startedAt = new Date(activeTimer.started_at);
      const duration = activeTimer.duration_seconds;
      
      console.log(`🔄 Starting continuous local timer for ${itemId} with duration ${duration}s, start time: ${startedAt.toISOString()}`);
      
      const continuousTimer = setInterval(() => {
        const now = new Date();
        const elapsed = Math.floor((now.getTime() - startedAt.getTime()) / 1000);
        
        // Always update timer progress for smooth counting
        setTimerProgress(prev => ({
          ...prev,
          elapsed: elapsed,
          total: duration
        }));
        
        // Update drift detector with local elapsed time
        driftDetector.updateLocalElapsed(itemId, elapsed);
        
        // Debug logging for first few seconds
        if (elapsed <= 10) {
          console.log(`🕐 Timer ${itemId}: Continuous elapsed=${elapsed}s, Start=${startedAt.toISOString()}, Now=${now.toISOString()}`);
        }
      }, 1000);

      return () => {
        console.log(`🔄 Stopping continuous local timer for ${itemId}`);
        clearInterval(continuousTimer);
      };
    }
  }, [hybridTimerData?.activeTimer, lastActiveStartTime]);

  // Cleanup drift detector on component unmount
  useEffect(() => {
    return () => {
      console.log('🔄 Cleaning up drift detector on component unmount');
      driftDetector.destroy();
      
      // Clear any remaining intervals
      if (localTimerInterval) {
        clearInterval(localTimerInterval);
      }
    };
  }, []);

  // Helper function to format time (same as RunOfShowPage) - handles negative values
  const formatTime = (seconds: number) => (
    <OvertimeClockText
      seconds={seconds}
      body={formatTimeBody(seconds)}
      sign={overtimeSign}
    />
  );

  // Format time of day
  const formatTimeOfDay = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Get remaining time (same logic as RunOfShowPage) - allow negative values
  const getRemainingTime = () => {
    const progress = timerProgress;
    const remaining = progress.total - progress.elapsed;
    
    // In hybrid mode, check if timer is actually running (both Neon Only ON and OFF)
    if (hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show full duration
        return progress.total;
      }
    }
    
    return remaining;
  };

  // Get remaining percentage for progress bar (same logic as RunOfShowPage)
  const getRemainingPercentage = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In hybrid mode, check if timer is actually running (both Neon Only ON and OFF)
    if (hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        // Timer is not running, show 100% (full bar)
        return 100;
      }
    }
    
    return progress.total > 0 ? (remainingSeconds / progress.total) * 100 : 0;
  };

  // Get progress bar color based on remaining time (same logic as RunOfShowPage)
  const getProgressBarColor = () => {
    const progress = timerProgress;
    const remainingSeconds = progress.total - progress.elapsed;
    
    // In hybrid mode, check if timer is actually running (both Neon Only ON and OFF)
    if (hybridTimerData?.activeTimer) {
      const activeTimer = hybridTimerData.activeTimer;
      if (!activeTimer.is_running || !activeTimer.is_active) {
        return countdownColorForRemaining(0, { isRunning: false, mode: countdownColorMode });
      }
    }

    if (usePreshowRainbow) {
      return countdownColorForRemaining(remainingSeconds, {
        mode: countdownColorMode,
        rainbow: true,
      });
    }
    
    return countdownColorForRemaining(remainingSeconds, { mode: countdownColorMode });
  };

  const activeFsCue = (() => {
    if (!scheduleItems.length || activeTimerItemId == null) return null;
    const idNum = Number(activeTimerItemId);
    return (
      scheduleItems.find(
        (s: any) =>
          s?.id === activeTimerItemId ||
          String(s?.id) === String(activeTimerItemId) ||
          (Number.isFinite(idNum) && Number(s?.id) === idNum)
      ) || null
    );
  })();
  const qaFlashPlan = isQaFlashPlan(activeFsCue) ? flashPlanFromParent(activeFsCue) : null;
  const parentRunningForQaFlash = !!(
    hybridTimerData?.activeTimer?.is_running &&
    hybridTimerData?.activeTimer?.is_active !== false &&
    (hybridTimerData?.activeTimer?.timer_state == null ||
      hybridTimerData?.activeTimer?.timer_state === 'running' ||
      hybridTimerData?.activeTimer?.timer_state === 'unknown')
  );
  const qaFlashRemaining = getRemainingTime();
  const qaFlashTotal = Number(timerProgress.total) || 0;
  const showQaFlashReminder =
    !!qaFlashPlan &&
    qaFlashPlan.auto !== false &&
    shouldShowQaFlashReminder({
      parentRunning: parentRunningForQaFlash,
      parentRemainingSeconds: qaFlashRemaining,
      parentTotalSeconds: qaFlashTotal,
      thresholdSeconds: qaFlashPlan.thresholdSeconds,
      parentElapsedSeconds: qaFlashTotal - qaFlashRemaining,
    });
  const qaFlashLine = useQaFlashTimerLine({
    active: showQaFlashReminder,
    label: qaFlashPlan?.label || 'Q&A',
  });
  const qaFlashTimerClass = qaFlashLine.timerClass;
  const renderMainTimerDigits = (seconds: number) => {
    if (qaFlashLine.show) {
      return <>{qaFlashLine.formatLine(formatTimeBody(Math.max(0, seconds)))}</>;
    }
    return formatTime(seconds);
  };

  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden flex flex-col items-center justify-center" style={{ padding: 0, margin: 0 }}>

      {/* Current Time / Cue — hidden while stage feed fills the stage */}
      {!stageFeedActive && (
      <div className="absolute top-10 left-10 text-3xl font-mono text-white">
        <div className="text-slate-400 text-lg mb-1">CURRENT TIME</div>
        <div className="text-white">
          {formatTimeOfDay(currentTime)}
        </div>
      </div>
      )}

      {!stageFeedActive && (
      <div className="fixed top-10 right-10 text-3xl font-mono text-white z-50 w-80 text-right">
        <div className="text-slate-400 text-lg mb-1">CURRENT CUE</div>
        <div className="text-white flex items-center justify-end gap-3 whitespace-nowrap">
          <span>
            {(() => {
              if (hybridTimerData?.activeTimer) {
                const activeTimer = hybridTimerData.activeTimer;
                const lastLoadedCue = hybridTimerData?.lastLoadedCue;
                const cueData = hybridTimerData?.cueData;
                const liveCue = resolveLiveCueLabel({
                  item: cueData,
                  timer: activeTimer,
                });
                if (liveCue === 'DELAY') return 'DELAY';
                if (liveCue && liveCue !== 'CUE') return liveCue;
                
                // Try CUE data from active timer cue_is column first
                if (activeTimer.cue_is && !/^CUE\s*\d{5,}$/i.test(String(activeTimer.cue_is))) {
                  console.log('✅ Using CUE data from active timer cue_is:', activeTimer.cue_is);
                  return activeTimer.cue_is;
                }
                
                // Try CUE data from schedule/items table second
                if (cueData) {
                  console.log('🔍 CUE data structure:', cueData);
                  console.log('🔍 CUE data fields:', Object.keys(cueData));
                  
                  const cueDisplay = cueData.customFields?.cue || cueData.cue || cueData.cue_display || cueData.name || cueData.title;
                  const segmentName = cueData.segmentName || cueData.segment_name || cueData.segment;
                  
                  if (cueDisplay) {
                    console.log('✅ Found CUE display:', cueDisplay);
                    return cueDisplay;
                  }
                }
                
                // Try active timer other fields
                const cueDisplay = activeTimer.cue_display || activeTimer.cue;
                const segmentName = activeTimer.segment_name || activeTimer.segmentName;
                
                if (cueDisplay) {
                  return cueDisplay;
                }
                
                // Fallback to last loaded cue
                if (lastLoadedCue) {
                  const lastCueDisplay = lastLoadedCue.cue_display || lastLoadedCue.cue;
                  const lastSegmentName = lastLoadedCue.segment_name || lastLoadedCue.segmentName;
                  if (lastCueDisplay) {
                    return lastCueDisplay;
                  }
                }
                
                if (liveCue) return liveCue;
                
                return 'No CUE';
              }
              return mainTimer ? (mainTimer.cue.includes('CUE') ? mainTimer.cue.replace(/CUE(\d+)/, 'CUE $1') : `CUE ${mainTimer.cue}`) : 'No CUE';
            })()}
          </span>
          {/* Drift Status Indicator */}
          {itemId && (
            <DriftStatusIndicator 
              itemId={itemId} 
              className="flex-shrink-0"
            />
          )}
        </div>
      </div>
      )}

      {/* Timer Status Indicator - Bottom Left */}
      {!isFullScreen && hybridTimerData?.activeTimer && (
        <div className="absolute bottom-10 left-10 text-center">
          <div className={`text-lg font-bold px-4 py-2 rounded-lg ${
            hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
              ? 'bg-green-600 text-white'
              : 'bg-gray-600 text-white'
          }`}>
            {hybridTimerData.activeTimer.is_running && hybridTimerData.activeTimer.is_active
              ? '⏱️ TIMER RUNNING'
              : '⏸️ TIMER STOPPED'
            }
          </div>
        </div>
      )}

      {/* Full Screen Button - Hidden when in full screen */}
      {!isFullScreen && (
        <div className="absolute top-10 left-1/2 transform -translate-x-1/2 flex gap-3 z-50">
        <button
          onClick={() => {
            if (document.documentElement.requestFullscreen) {
              document.documentElement.requestFullscreen();
            }
          }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-lg transition-colors"
        >
          FULL SCREEN
        </button>
        {!isFullScreen && (
          <button
            onClick={() => setSupabaseOnly(!supabaseOnly)}
            className={`px-4 py-2 rounded-lg font-bold text-lg transition-colors ${
              supabaseOnly 
                ? 'bg-green-600 hover:bg-green-700 text-white' 
                : 'bg-gray-600 hover:bg-gray-700 text-white'
            }`}
          >
            NEON ONLY
          </button>
        )}
        </div>
      )}

      {/* Cue Cards / Teleprompter clock feed */}
      {stageFeedActive ? (
        <div
          className="absolute inset-x-0 z-20 grid place-items-start justify-items-center px-2"
          style={{
            top: '0.75rem',
            bottom: activeFsMessage ? '26%' : '16%',
            containerType: 'size',
          }}
        >
          <div
            className="relative overflow-hidden border-2 border-white/80 bg-black shadow-2xl"
            style={{
              aspectRatio: '16 / 9',
              width: 'min(100cqw, calc(100cqh * 16 / 9))',
              height: 'min(100cqh, calc(100cqw * 9 / 16))',
            }}
          >
            {cueClockActive && cueClockFeed?.slide ? (
              <CueCardClockOverlay
                slide={cueClockFeed.slide}
                comments={cueClockFeed.comments || []}
                className="h-full w-full"
              />
            ) : null}
            {teleprompterClockActive && teleprompterClockFeed ? (
              <TeleprompterClockOverlay
                feed={teleprompterClockFeed}
                className="h-full w-full"
              />
            ) : null}
            {!cueClockActive && !teleprompterClockActive && pptClockActive && pptClockFeed ? (
              <PptClockOverlay feed={pptClockFeed} className="h-full w-full" />
            ) : null}
          </div>
        </div>
      ) : null}

      {stageFeedActive && activeFsMessage ? (
        <div className="absolute bottom-[16%] left-1/2 z-30 w-[min(90vw,56rem)] -translate-x-1/2 rounded-lg border-2 border-white/80 bg-black/70 px-6 py-3 text-center text-2xl font-bold text-white md:text-3xl">
          {activeFsMessage.message}
        </div>
      ) : null}

      {/* Message Display — skip Pre Show (uses OVER TIME-style label instead) */}
      {(() => {
        const activeMsg = activeFsMessage;
        return !!activeMsg && !stageFeedActive;
      })() && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ transform: 'translateY(-40px)' }}>
          <div 
            className={`font-bold text-white bg-black bg-opacity-50 rounded-lg border-4 border-white text-center flex items-center justify-center ${
              !!([hybridTimerData?.timerMessage, supabaseMessage].find((m: any) => m?.enabled)?.flashing) ? 'ros-timer-message-flash' : ''
            }`}
            style={{
              width: '80vw',
              minHeight: '50vh',
              maxHeight: '70vh',
              lineHeight: '1.2',
              whiteSpace: 'pre-line',
              overflow: 'visible',
              padding: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              wordWrap: 'break-word'
            }}
          >
            {(() => {
              // Use enabled message only
              const displayMessage = ([hybridTimerData?.timerMessage, supabaseMessage].find((m: any) => m?.enabled)?.message)
                || message
                || '';
              // Break long messages into multiple lines
              const words = displayMessage.split(' ');
              let formattedMessage;
              let lineCount;
              
              if (words.length <= 3) {
                formattedMessage = displayMessage; // Keep short messages on one line
                lineCount = 1;
              } else if (words.length <= 6) {
                // Break into 2 lines
                const mid = Math.ceil(words.length / 2);
                formattedMessage = words.slice(0, mid).join(' ') + '\n' + words.slice(mid).join(' ');
                lineCount = 2;
              } else if (words.length <= 10) {
                // Break into 3 lines
                const third = Math.ceil(words.length / 3);
                formattedMessage = words.slice(0, third).join(' ') + '\n' + 
                       words.slice(third, third * 2).join(' ') + '\n' + 
                       words.slice(third * 2).join(' ');
                lineCount = 3;
              } else {
                // Break into 4 lines for very long messages
                const quarter = Math.ceil(words.length / 4);
                formattedMessage = words.slice(0, quarter).join(' ') + '\n' + 
                       words.slice(quarter, quarter * 2).join(' ') + '\n' + 
                       words.slice(quarter * 2, quarter * 3).join(' ') + '\n' + 
                       words.slice(quarter * 3).join(' ');
                lineCount = 4;
              }
              
              // Calculate font size based on message length and line count
              // Account for descenders (g, j, p, q, y) that hang below baseline
              let fontSize;
              const hasDescenders = /[gjpqy]/.test(displayMessage.toLowerCase());
              
              if (words.length <= 3) {
                fontSize = hasDescenders ? 'clamp(3rem, 12vw, 16rem)' : 'clamp(3.5rem, 13.5vw, 18rem)';
              } else if (words.length <= 6) {
                fontSize = hasDescenders ? 'clamp(1.9rem, 8vw, 12rem)' : 'clamp(2.25rem, 9vw, 13.5rem)';
              } else if (words.length <= 10) {
                fontSize = hasDescenders ? 'clamp(1.4rem, 6vw, 9rem)' : 'clamp(1.6rem, 7vw, 10.5rem)';
              } else {
                fontSize = hasDescenders ? 'clamp(0.9rem, 4vw, 6rem)' : 'clamp(1.1rem, 5vw, 7rem)';
              }
              
              return (
                <div style={{ fontSize }}>
                  {formattedMessage}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Secondary Timer Display - Large ALT (Op preferred). Hidden only for stage messages. */}
      {(() => {
        if (!hasLargeAlt) return false;
        if (layoutCrowdedFs) return false;
        return true;
      })() && (
        <div className={`animate-in fade-in duration-500 ${(() => {
          // Check for messages (both Neon Only ON and OFF)
          if (hybridTimerData?.timerMessage) {
            return hybridTimerData.timerMessage.enabled;
          }
          return (messageEnabled && message) || (supabaseMessage && supabaseMessage.enabled);
          // Large: same flex-1 shell as main timer (same Y). With message: compact absolute.
        })() ? 'absolute bottom-20 right-[18%] translate-x-1/2 flex flex-col items-center min-w-[11rem]' : 'flex-1 flex flex-col items-center justify-center'}`}
        >
          {/* ALT label — large uses OVER TIME slot; with message stays above small countdown */}
          {(() => {
            const hasMessage = hybridTimerData?.timerMessage
              ? !!hybridTimerData.timerMessage.enabled
              : !!(messageEnabled && message) || !!(supabaseMessage && supabaseMessage.enabled);
            const label = (() => {
              const currentSecondaryTimer = displaySecondaryTimer;
              if (!currentSecondaryTimer) return null;
              return <AltTimerBadge timer={currentSecondaryTimer} />;
            })();
            if (hasMessage) {
              return (
                <div className="mb-1 text-lg font-bold leading-none whitespace-nowrap">
                  <AltTimerBadge timer={displaySecondaryTimer} cueOnly />
                </div>
              );
            }
            return (
                <div
                  className={`mb-[-50px] text-center ${secondaryDisplayColor} text-xl md:text-2xl lg:text-3xl font-bold whitespace-nowrap`}
                  style={{ lineHeight: '1.2' }}
                >
                  {label}
                </div>
            );
          })()}
          {/* Large Time — same digit wrapper + progress-bar spacer as main timer */}
          <div className="text-center w-full flex flex-col items-center">
          <div
            className={`${secondaryDisplayColor} font-mono font-bold animate-in zoom-in duration-500 ${(() => {
              const currentSecondaryTimer = displaySecondaryTimer;
              if (!currentSecondaryTimer) return 'text-3xl md:text-4xl lg:text-5xl';
              
              // Use secondaryTimerUpdate to trigger re-calculation every second
              const _ = secondaryTimerUpdate;
              
              let remaining = 0;
              if (currentSecondaryTimer.started_at || currentSecondaryTimer.created_at || supabaseOnly) {
                remaining = secondaryRemainingSeconds(currentSecondaryTimer);
              } else {
                remaining = currentSecondaryTimer.remaining || 0;
              }
              
              // Check for messages (both Neon Only ON and OFF)
              if (hybridTimerData?.timerMessage) {
                if (hybridTimerData.timerMessage.enabled) {
                  return 'text-3xl md:text-4xl';
                }
              } else if ((messageEnabled && message) || (supabaseMessage && supabaseMessage.enabled)) {
                return 'text-3xl md:text-4xl';
              }
              const hours = Math.floor(Math.abs(remaining) / 3600);
              return hours === 0
                ? 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]'
                : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';
            })()}`}
            style={{ lineHeight: '1' }}
          >
            {(() => {
              const currentSecondaryTimer = displaySecondaryTimer;
              if (!currentSecondaryTimer) return '00:00';
              
              // Use secondaryTimerUpdate to trigger re-calculation every second
              const _ = secondaryTimerUpdate;
              
              let remaining = 0;
              if (currentSecondaryTimer.started_at || currentSecondaryTimer.created_at || supabaseOnly) {
                remaining = secondaryRemainingSeconds(currentSecondaryTimer);
              } else {
                // Props data structure - use remaining property
                remaining = currentSecondaryTimer.remaining || 0;
              }
              
              return formatSecondaryTime(remaining);
            })()}
          </div>
          {(() => {
            const hasMessage = hybridTimerData?.timerMessage
              ? !!hybridTimerData.timerMessage.enabled
              : !!(messageEnabled && message) || !!(supabaseMessage && supabaseMessage.enabled);
            if (!hasMessage) {
              return <div className="w-full max-w-5xl mt-0 h-8" aria-hidden />;
            }
            const t = displaySecondaryTimer;
            let pct = 0;
            if (t) {
              const total = t.duration_seconds || t.duration || 0;
              if (total > 0) {
                const startedAt = new Date(t.started_at || t.created_at);
                const elapsed = Math.floor((Date.now() - startedAt.getTime()) / 1000);
                pct = Math.min(100, Math.max(0, ((total - elapsed) / total) * 100));
              }
            }
            return (
              <div className="w-40 mx-auto mt-2 bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative h-2">
                <div
                  className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                    isOpAlt ? 'bg-violet-400' : 'bg-orange-400'
                  }`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            );
          })()}
          </div>
        </div>
      )}

      {/* When Op + indented both live: main small left, indented small right (Op stays large above) */}
      {hasIndentedSmall && !layoutCrowdedFs && (
        <>
          <div className={`text-center absolute ${crowdedTimerBottom} left-[18%] -translate-x-1/2 min-w-[11rem]`}>
            <div
              className={`font-mono font-bold text-3xl md:text-4xl leading-none ${
                usePreshowRainbow ? 'ros-rainbow-text' : ''
              }`}
              style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
            >
              {formatTime(getRemainingTime())}
            </div>
          </div>
          <div className={`text-center absolute ${crowdedTimerBottom} right-[18%] translate-x-1/2 min-w-[11rem] text-orange-400`}>
            <div className="mb-1 text-lg font-bold leading-none">
              <AltTimerBadge timer={indentedSubTimer} cueOnly />
            </div>
            <div className="font-mono text-3xl md:text-4xl font-bold leading-none">
              {formatSecondaryTime(secondaryRemainingSeconds(indentedSubTimer))}
            </div>
          </div>
        </>
      )}

      {/* Main Timer Layout - When there's both a secondary timer AND a message (small layout) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return hasSecondaryTimer && hasMessage;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-[18%] -translate-x-1/2 min-w-[11rem]`}>
          {/* Overtime Indicator - Above main timer when both message and secondary timer are active */}
          {!qaFlashLine.show && getRemainingTime() < 0 && (
            <div className="mb-1">
              <div className="font-bold text-red-500 text-lg leading-none">
                OVER TIME
              </div>
            </div>
          )}
          
          <div 
            className={`font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl leading-none ${qaFlashTimerClass} ${
              usePreshowRainbow ? 'ros-rainbow-text' : ''
            }`}
            style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
          >
            {renderMainTimerDigits(getRemainingTime())}
          </div>
          <div className="w-40 mx-auto mt-2 bg-slate-700 rounded-full overflow-hidden border border-slate-600 relative h-2">
            <div
              className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                usePreshowRainbow ? 'ros-rainbow-fill' : ''
              }`}
              style={{
                width: `${Math.min(100, Math.max(0, getRemainingPercentage()))}%`,
                ...(usePreshowRainbow ? {} : { background: getProgressBarColor() }),
              }}
            />
          </div>
        </div>
      )}

      {/* Main Timer Layout - Only when no secondary timer and no message */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return !hasSecondaryTimer && !hasMessage;
      })() && (
        <div className="flex-1 flex flex-col items-center justify-center">
          {!qaFlashLine.show && getRemainingTime() < 0 ? (
            <div className="mb-[-50px] text-center relative z-10 translate-y-10">
              <div className="font-bold text-red-500 text-5xl leading-none">
                OVER TIME
              </div>
            </div>
          ) : !qaFlashLine.show && usePreshowRainbow ? (
            <div className="mb-[-50px] text-center relative z-10 translate-y-10">
              <div className="ros-preshow-super text-5xl leading-none">PRE SHOW COUNTDOWN</div>
              <span className="ros-preshow-super-rule" aria-hidden />
            </div>
          ) : null}
          {/* Countdown Timer - Centered; Q&A flash replaces digits in-place */}
          <div className="text-center">
            <div 
              className={`font-mono font-bold ${qaFlashTimerClass} ${usePreshowRainbow ? 'ros-rainbow-text' : ''} ${
                qaFlashLine.show
                  ? 'text-[8rem] md:text-[9.5rem] lg:text-[11rem]'
                  : (() => {
                      const remaining = getRemainingTime();
                      const hours = Math.floor(Math.abs(remaining) / 3600);
                      return hours === 0
                        ? 'text-[15rem] md:text-[16.875rem] lg:text-[22.5rem]'
                        : 'text-[12rem] md:text-[13.5rem] lg:text-[18rem]';
                    })()
              }`}
              style={usePreshowRainbow ? undefined : { color: getProgressBarColor() }}
            >
              {renderMainTimerDigits(getRemainingTime())}
            </div>
          </div>
          
          {/* Progress Bar - 0px below timer */}
          <div className="w-full max-w-5xl mt-0">
            <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-8">
              <div 
                className={`h-full transition-all duration-1000 absolute top-0 right-0 ${
                  usePreshowRainbow ? 'ros-rainbow-fill' : ''
                }`}
                style={{ 
                  width: `${getRemainingPercentage()}%`,
                  ...(usePreshowRainbow ? {} : { background: getProgressBarColor() }),
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when message is active */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return hasMessage && !hasSecondaryTimer;
      })() && (
        <div className={`text-center transition-all duration-500 ease-in-out absolute ${crowdedTimerBottom} left-1/2 transform -translate-x-1/2`}>
          {/* Overtime Indicator - Above main timer when message is active */}
          {!qaFlashLine.show && getRemainingTime() < 0 && (
            <div className="mb-2">
              <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">
                OVER TIME
              </div>
            </div>
          )}
          
          <div 
            className={`font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl ${qaFlashTimerClass}`}
            style={{ color: getProgressBarColor() }}
          >
            {renderMainTimerDigits(getRemainingTime())}
          </div>
        </div>
      )}

      {/* Countdown Timer - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return hasSecondaryTimer && !hasMessage && !dualAltLayout;
      })() && (
        <div className="text-center transition-all duration-500 ease-in-out absolute bottom-20 left-1/2 transform -translate-x-1/2">
          {/* Overtime Indicator - Above main timer when secondary timer is active */}
          {!qaFlashLine.show && getRemainingTime() < 0 && (
            <div className="mb-2">
              <div className="font-bold text-red-500 text-lg md:text-xl lg:text-2xl">
                OVER TIME
              </div>
            </div>
          )}
          
          <div 
            className={`font-mono font-bold transition-all duration-500 ease-in-out text-3xl md:text-4xl lg:text-5xl ${qaFlashTimerClass}`}
            style={{ color: getProgressBarColor() }}
          >
            {renderMainTimerDigits(getRemainingTime())}
          </div>
        </div>
      )}

      {/* Progress Bar - Positioned at bottom when message is active */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return hasMessage && !hasSecondaryTimer;
      })() && (
        <div className={`w-full transition-all duration-500 ease-in-out absolute ${crowdedBarBottom} left-1/2 transform -translate-x-1/2 max-w-2xl`}>
          <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-2">
            <div 
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{ 
                width: `${getRemainingPercentage()}%`,
                background: getProgressBarColor()
              }}
            />
          </div>
        </div>
      )}

      {/* Progress Bar - Positioned at bottom when secondary timer is shown (but not when message is active) */}
      {(() => {
        let hasSecondaryTimer = false;
        
        if (supabaseOnly) {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        } else {
          hasSecondaryTimer = secondaryStillVisible(displaySecondaryTimer);
        }
        
        const hasMessage = hasBlockingStageMessage();
        
        return hasSecondaryTimer && !hasMessage && !dualAltLayout;
      })() && (
        <div className="w-full transition-all duration-500 ease-in-out absolute bottom-8 left-1/2 transform -translate-x-1/2 max-w-2xl">
          <div className="w-full bg-slate-700 rounded-full overflow-hidden border-3 border-slate-600 relative h-2">
            <div 
              className="h-full transition-all duration-1000 absolute top-0 right-0"
              style={{ 
                width: `${getRemainingPercentage()}%`,
                background: getProgressBarColor()
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default FullScreenTimer;
