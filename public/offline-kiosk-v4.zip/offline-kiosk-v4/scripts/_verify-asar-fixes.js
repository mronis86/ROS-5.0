'use strict';
const fs = require('fs');
const path = require('path');
const asarPath = process.argv[2] || path.join(__dirname, '..', 'dist-ship-20261118-181926', 'win-unpacked', 'resources', 'app.asar');
const buf = fs.readFileSync(asarPath);
const t = buf.toString('latin1');
const checks = {
  svcVmix: t.includes("vmix: 'svcVmix'"),
  showingLocal: t.includes('Showing local events'),
  kioskCalendarPath: t.includes('kiosk/calendar-events'),
  calendarOnly: t.includes('calendarOnly'),
  grClientEmpty: t.includes('Green Room Client app'),
};
console.log(JSON.stringify({ asarPath, checks }, null, 2));
process.exit(Object.values(checks).every(Boolean) ? 0 : 2);
