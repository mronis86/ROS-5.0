# Run of Show (ROS)

Control your Run of Show schedule directly from Bitfocus Companion. No Electron or Python app required – this module talks to your Railway API natively.

## Configuration

- **API Base URL**: Your Run of Show API (default: https://ros-50-production.up.railway.app)
- **Event ID**: Paste the event ID from the Run of Show web app (Events list). Copy it from the URL or event details.
- **Day**: Day number for multi-day events (1–10).

## Actions

### Main Timer
- **Load Cue** – Select a cue/row from the schedule and load it as the active cue.
- **Start Timer** – Start the timer for the currently loaded cue.
- **Stop Timer** – Stop the running timer.
- **Reset Timer** – Reset all timers for the event (clears loaded cue, timers, etc.).

### Sub-Timers (like OSC `/subtimer/cue/5/start` and `/subtimer/cue/5/stop`)
- **Start Sub-Timer** – Start a sub-timer for an indented cue (select cue from dropdown).
- **Stop Sub-Timer** – Stop a sub-timer. Choose a specific cue or "All sub-timers" to stop all.

### Timer Duration Adjust
- **Timer +1 min** – Add 1 minute to the active timer duration.
- **Timer -1 min** – Subtract 1 minute from the active timer duration.
- **Timer +5 min** – Add 5 minutes to the active timer duration.
- **Timer -5 min** – Subtract 5 minutes from the active timer duration.

### LED Text Graphics
- **LED Clear Output** – Clears the transparent LED output page for this event (same as **Clear Output** on the LED Layouts page). All connected `/led-output` browser sources hide their content.

### DSM (presets → Companion buttons)
- In module settings, set **page / row / column** for Full, LED, VID, and PPT. Put Ultrix / ATEM / vMix / OBS / Ross Talk on those Companion buttons.
- **Do not** also put **DSM · Full/LED/VID/PPT** actions on those same buttons — the module already presses them; nesting causes double-fire.
- **Do not** also add Companion Triggers on `dsm_fire` / `dsm_mode` that press the same buttons if **Press DSM button on cue load** is ON — pick one path (HTTP press *or* Triggers).
- Double-check page / row / column (Companion rows/columns are usually **0-based**). Wrong coords press neighboring buttons.
- Enable Companion **HTTP Server** (default `http://127.0.0.1:8000`).
- With **Press DSM button on cue load** ON, loading a DSM-enabled cue presses the matching button once (cue change only; Stop does not re-press).
- **DSM · Full / LED / VID / PPT** presets: set Clock layout, publish variables, and press the same configured button (for dry-run).

## Variables

- **Current Cue** – The cue label of the loaded item.
- **Current Segment Name** – The segment name of the loaded item.
- **Timer Running** – "Yes" or "No".
- **Event Name** – The name of the selected event.
- **dsm_mode** – full / led / vid / ppt.
- **dsm_fire** – increments on each publish (best Trigger hook).
- **dsm_source** – manual or cue_load.

## Feedbacks

- **Timer Running** – True when the timer is running.
- **Cue Loaded** – True when a cue is loaded.

## Getting the Event ID

1. Open the Run of Show web app.
2. Go to the Events list.
3. The event ID is in the URL when you open an event, or you can inspect the event object. It's typically a UUID or numeric ID.
