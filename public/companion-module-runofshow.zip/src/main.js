const { InstanceBase, runEntrypoint, InstanceStatus, combineRgb } = require('@companion-module/base')
const UpgradeScripts = require('./upgrades')
const UpdateActions = require('./actions')
const UpdateFeedbacks = require('./feedbacks')
const UpdateVariableDefinitions = require('./variables')

class RunOfShowInstance extends InstanceBase {
	constructor(internal) {
		super(internal)
		this.events = []
		this.scheduleItems = []
		this.activeTimer = null
		this.pollInterval = null
		this.refreshStartedAt = null
	}

	async init(config) {
		this.config = config
		this.refreshStartedAt = Date.now()
		this.updateStatus(InstanceStatus.Connecting)
		await this.fetchData()
		this.updateActions()
		this.updateFeedbacks()
		this.updatePresets()
		this.updateVariableDefinitions()
		this.updateVariableValues()
		this.startPolling()
		this.updateStatus(InstanceStatus.Ok)
	}

	async destroy() {
		if (this.pollInterval) {
			clearInterval(this.pollInterval)
		}
	}

	async configUpdated(config) {
		this.config = config
		this.refreshStartedAt = Date.now()
		this.updateStatus(InstanceStatus.Connecting)
		await this.fetchData()
		this.startPolling() // restart with new sync interval and event ID
		this.updateActions()
		this.updateFeedbacks()
		this.updatePresets()
		this.updateVariableDefinitions()
		this.updateVariableValues()
		this.updateStatus(InstanceStatus.Ok)
	}

	getApiUrl() {
		const url = (this.config?.apiUrl || '').trim().replace(/\/+$/, '')
		return url || 'https://ros-50-production.up.railway.app'
	}

	async fetch(url, options = {}) {
		const baseUrl = this.getApiUrl()
		const fullUrl = url.startsWith('http') ? url : `${baseUrl}${url}`
		try {
			const res = await fetch(fullUrl, {
				...options,
				headers: { 'Content-Type': 'application/json', ...options.headers },
			})
			if (!res.ok) throw new Error(`HTTP ${res.status}`)
			const text = await res.text()
			return text ? JSON.parse(text) : null
		} catch (err) {
			this.log('error', `API request failed: ${err.message}`)
			throw err
		}
	}

	async fetchEvents() {
		const data = await this.fetch('/api/calendar-events')
		this.events = Array.isArray(data) ? data : []
		return this.events
	}

	async fetchRunOfShow(eventId, day = 1) {
		const data = await this.fetch(`/api/run-of-show-data/${eventId}`)
		if (!data || !data.schedule_items) {
			this.scheduleItems = []
			return []
		}
		let items = typeof data.schedule_items === 'string' ? JSON.parse(data.schedule_items) : data.schedule_items
		if (!Array.isArray(items)) items = []
		const dayNum = parseInt(day, 10) || 1
		this.scheduleItems = items.filter((item) => (item.day || 1) === dayNum)
		return this.scheduleItems
	}

	async fetchActiveTimer(eventId) {
		try {
			const data = await this.fetch(`/api/active-timers/${eventId}`)
			const row = Array.isArray(data) && data[0] ? data[0] : data
			this.activeTimer = row && row.item_id != null ? row : null
		} catch {
			this.activeTimer = null
		}
		return this.activeTimer
	}

	async fetchData() {
		const eventId = this.config?.eventId
		if (!eventId) {
			this.events = []
			this.scheduleItems = []
			this.activeTimer = null
			return
		}
		try {
			await this.fetchEvents()
			await this.fetchRunOfShow(eventId, this.config?.day || 1)
			await this.fetchActiveTimer(eventId)
		} catch (err) {
			this.log('error', `Failed to fetch data: ${err.message}`)
		}
	}

	startPolling() {
		if (this.pollInterval) clearInterval(this.pollInterval)
		this.pollInterval = null
		this.refreshStartedAt = Date.now()
		const seconds = Math.max(5, Math.min(600, parseInt(this.config?.syncIntervalSeconds, 10) || 60))
		const ms = seconds * 1000
		this.pollInterval = setInterval(() => {
			if (!this.config?.eventId) return
			const stopAfterEnabled = this.config.stopRefreshAfterEnabled === true || this.config.stopRefreshAfterEnabled === 'true'
			if (stopAfterEnabled && this.refreshStartedAt != null) {
				const hours = Math.max(1, Math.min(72, parseInt(this.config.stopRefreshAfterHours, 10) || 4))
				const limitMs = hours * 3600 * 1000
				if ((Date.now() - this.refreshStartedAt) >= limitMs) {
					clearInterval(this.pollInterval)
					this.pollInterval = null
					this.updateStatus(InstanceStatus.Warning, `Refresh stopped after ${hours}h (time limit)`)
					return
				}
			}
			this.fetchData().then(() => {
				this.updateActions()
				this.updateFeedbacks()
				this.updatePresets()
				this.updateVariableDefinitions()
				this.updateVariableValues()
			}).catch(() => {})
		}, ms)
	}

	async apiPost(path, body) {
		const baseUrl = this.getApiUrl()
		const res = await fetch(`${baseUrl}${path}`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body),
		})
		if (!res.ok) {
			const err = await res.text()
			throw new Error(err || `HTTP ${res.status}`)
		}
		return res.json().catch(() => ({}))
	}

	async apiPut(path, body) {
		const baseUrl = this.getApiUrl()
		const res = await fetch(`${baseUrl}${path}`, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body),
		})
		if (!res.ok) {
			const err = await res.text()
			throw new Error(err || `HTTP ${res.status}`)
		}
		return res.json().catch(() => ({}))
	}

	async apiDelete(path) {
		const baseUrl = this.getApiUrl()
		const res = await fetch(`${baseUrl}${path}`, { method: 'DELETE' })
		if (!res.ok) throw new Error(`HTTP ${res.status}`)
		return res.json().catch(() => ({}))
	}

	getConfigFields() {
		return [
			{
				type: 'textinput',
				id: 'apiUrl',
				label: 'API Base URL',
				width: 12,
				default: 'https://ros-50-production.up.railway.app',
				tooltip: 'Run of Show Railway API URL',
			},
			{
				type: 'textinput',
				id: 'eventId',
				label: 'Event ID',
				width: 12,
				tooltip: 'Paste the event ID from the Run of Show web app (Events list)',
			},
			{
				type: 'number',
				id: 'day',
				label: 'Day',
				width: 4,
				default: 1,
				min: 1,
				max: 10,
			},
			{
				type: 'number',
				id: 'syncIntervalSeconds',
				label: 'Sync interval (seconds)',
				width: 6,
				default: 60,
				min: 5,
				max: 600,
				tooltip: 'How often to fetch schedule/timer from the API (5–600 seconds). Lower = more responsive, higher = less traffic.',
			},
			{
				type: 'checkbox',
				id: 'stopRefreshAfterEnabled',
				label: 'Stop refresh after set hours',
				width: 12,
				default: false,
				tooltip: 'When enabled, the module will stop polling the API after the number of hours set below. Restart the instance or change config to resume.',
			},
			{
				type: 'number',
				id: 'stopRefreshAfterHours',
				label: 'Stop after (hours)',
				width: 6,
				default: 4,
				min: 1,
				max: 72,
				tooltip: 'Stop fetching schedule/timer after this many hours (only if "Stop refresh after set hours" is enabled).',
			},
		]
	}

	updateActions() {
		UpdateActions(this)
	}

	updateFeedbacks() {
		UpdateFeedbacks(this)
	}

	// Ensure cue displays as "CUE 1" / "CUE 1.1" not just "1" / "1.1"
	formatCueDisplay(raw, itemId) {
		const s = String(raw ?? itemId ?? '').trim()
		if (!s) return `CUE ${itemId}`
		if (/^\d+(\.\d+)?$/.test(s)) return `CUE ${s}`
		if (/^CUE\s+/i.test(s)) return s
		return `CUE ${s}`
	}

	updatePresets() {
		const presets = {}
		const items = this.scheduleItems || []
		// Regular cues = not indented (main CUE rows). Sub-cues = indented (sub-rows under a CUE).
		const regularCues = items.filter((item) => !item.isIndented)
		const subCues = items.filter((item) => item.isIndented === true)

		// One preset per regular cue only (Load Cue + feedback)
		for (const item of regularCues) {
			const cueDisplay = this.formatCueDisplay(item.customFields?.cue, item.id)
			const fullLabel = `${cueDisplay}: ${item.segmentName || 'Untitled'}`
			presets[`cue_${item.id}`] = {
				type: 'button',
				category: 'Cues',
				name: fullLabel,
				style: {
					text: cueDisplay,
					size: 'auto',
					color: combineRgb(255, 255, 255),
					bgcolor: combineRgb(40, 40, 40),
				},
				feedbacks: [
					{
						feedbackId: 'loaded_cue_is',
						options: { itemId: String(item.id) },
						style: { bgcolor: combineRgb(50, 100, 200), color: combineRgb(255, 255, 255) },
					},
				],
				steps: [
					{
						down: [{ actionId: 'load_cue', options: { itemId: String(item.id) } }],
						up: [],
					},
				],
			}
		}

		// Timer control presets (Start, Stop, Reset, +/- 1 min, +/- 5 min)
		const timerPresets = {
			start_timer: { name: 'Start Timer', actionId: 'start_timer', text: 'Start', bgcolor: combineRgb(0, 120, 0) },
			stop_timer: { name: 'Stop Timer', actionId: 'stop_timer', text: 'Stop', bgcolor: combineRgb(120, 0, 0) },
			reset_timer: { name: 'Reset Timer', actionId: 'reset_timer', text: 'Reset', bgcolor: combineRgb(80, 80, 0) },
			timer_plus_1: { name: 'Timer +1 min', actionId: 'adjust_timer_plus_1', text: '+1', bgcolor: combineRgb(40, 60, 80) },
			timer_minus_1: { name: 'Timer -1 min', actionId: 'adjust_timer_minus_1', text: '-1', bgcolor: combineRgb(40, 60, 80) },
			timer_plus_5: { name: 'Timer +5 min', actionId: 'adjust_timer_plus_5', text: '+5', bgcolor: combineRgb(40, 60, 80) },
			timer_minus_5: { name: 'Timer -5 min', actionId: 'adjust_timer_minus_5', text: '-5', bgcolor: combineRgb(40, 60, 80) },
		}
		for (const [id, def] of Object.entries(timerPresets)) {
			presets[id] = {
				type: 'button',
				category: 'Timer',
				name: def.name,
				style: {
					text: def.text,
					size: 'auto',
					color: combineRgb(255, 255, 255),
					bgcolor: def.bgcolor,
				},
				feedbacks: [],
				steps: [
					{
						down: [{ actionId: def.actionId, options: {} }],
						up: [],
					},
				],
			}
		}

		// Stop all sub-timers (single preset)
		presets.stop_subtimer_all = {
			type: 'button',
			category: 'Timer',
			name: 'Stop all sub-timers',
			style: {
				text: 'Stop subs',
				size: 'auto',
				color: combineRgb(255, 255, 255),
				bgcolor: combineRgb(100, 50, 0),
			},
			feedbacks: [],
			steps: [
				{
					down: [{ actionId: 'stop_subtimer', options: { itemId: '' } }],
					up: [],
				},
			],
		}

		// One preset per sub-cue only for Start Sub-Timer
		for (const item of subCues) {
			const cueDisplay = this.formatCueDisplay(item.customFields?.cue, item.id)
			const fullLabel = `Sub: ${cueDisplay} – ${item.segmentName || 'Untitled'}`
			presets[`sub_${item.id}`] = {
				type: 'button',
				category: 'Sub-Timers',
				name: fullLabel,
				style: {
					text: `Sub ${cueDisplay}`,
					size: 'auto',
					color: combineRgb(255, 255, 255),
					bgcolor: combineRgb(60, 40, 80),
				},
				feedbacks: [],
				steps: [
					{
						down: [{ actionId: 'start_subtimer', options: { itemId: String(item.id) } }],
						up: [],
					},
				],
			}
		}

		this.setPresetDefinitions(presets)
	}

	updateVariableDefinitions() {
		UpdateVariableDefinitions(this)
	}

	updateVariableValues() {
		const eventId = this.config?.eventId
		if (!eventId) return

		const event = this.events.find((e) => String(e.id) === String(eventId))
		const currentItem = this.scheduleItems.find((s) => String(s.id) === String(this.activeTimer?.item_id))
		const cueLabel = currentItem ? this.formatCueDisplay(currentItem.customFields?.cue ?? this.activeTimer?.cue_is, currentItem.id) : (this.activeTimer?.cue_is ?? '—')
		const segmentName = currentItem?.segmentName ?? '—'
		const loadedCueValue = currentItem?.customFields?.value ?? segmentName ?? '—'
		const timerRunning = this.activeTimer?.is_running === true

		const values = {
			current_cue: cueLabel,
			current_segment: segmentName,
			loaded_cue_value: loadedCueValue,
			timer_running: timerRunning ? 'Yes' : 'No',
			event_name: event?.name ?? '—',
		}

		// Per-cue variables: label shows CUE 1 / CUE 1.1 not just 1
		for (const item of this.scheduleItems) {
			values[`cue_${item.id}_label`] = this.formatCueDisplay(item.customFields?.cue, item.id)
			values[`cue_${item.id}_value`] = item.customFields?.value ?? item.segmentName ?? '—'
		}

		this.setVariableValues(values)
	}
}

runEntrypoint(RunOfShowInstance, UpgradeScripts)
