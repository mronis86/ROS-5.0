module.exports = function (self) {
	self.setVariableDefinitions([
		{ variableId: 'current_cue', name: 'Current Cue' },
		{ variableId: 'current_segment', name: 'Current Segment Name' },
		{ variableId: 'timer_running', name: 'Timer Running (Yes/No)' },
		{ variableId: 'event_name', name: 'Event Name' },
	])
}
