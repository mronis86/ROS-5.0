ROS PowerPoint Bridge V2 (0.2.2)

Open/Loaded thrash fix build. Use this V2 zip only — quit any older bridge first.
Only one Mode 2 helper should run per event.

No Node.js / npm install required.

1. Unzip this folder completely. Do not run START.bat from inside the zip window.
2. Open PowerPoint with your deck.
3. Double-click START.bat (or the V2 .exe in the same folder).
4. Paste the Railway API URL and an integration token (ros_itok_...) with read,control,write.
5. Load events, pick the show.
6. PowerPoint Show with Timers: Capture stills, then Start follow.
7. ROS PPT Launcher: Sync decks (downloads decks + slide images), then Follow loaded cue or Manual open.

Keep the .exe next to resources\app.asar.
