@echo off
setlocal
cd /d "%~dp0"
title ROS PowerPoint Bridge V2
echo Starting ROS PowerPoint Bridge V2...
if not exist "%~dp0ROS PowerPoint Bridge V2.exe" (
  echo ERROR: Missing "ROS PowerPoint Bridge V2.exe" next to this START.bat
  echo Unzip the full powerpoint-bridge-v2 folder first. Do not run from inside the zip window.
  pause
  exit /b 1
)
if not exist "%~dp0resources\app.asar" (
  echo ERROR: Missing resources\app.asar - zip is incomplete.
  echo Re-download powerpoint-bridge-v2.zip and unzip the whole folder.
  pause
  exit /b 1
)
start "" "%~dp0ROS PowerPoint Bridge V2.exe"
endlocal
