@echo off
setlocal
cd /d "%~dp0"
title ROS PowerPoint Bridge
echo Starting ROS PowerPoint Bridge...
if not exist "%~dp0ROS PowerPoint Bridge.exe" (
  echo ERROR: Missing "ROS PowerPoint Bridge.exe" next to this START.bat
  echo Unzip the full powerpoint-bridge folder first. Do not run from inside the zip window.
  pause
  exit /b 1
)
if not exist "%~dp0resources\app.asar" (
  echo ERROR: Missing resources\app.asar - zip is incomplete.
  echo Re-download powerpoint-bridge.zip and unzip the whole folder.
  pause
  exit /b 1
)
start "" "%~dp0ROS PowerPoint Bridge.exe"
endlocal
