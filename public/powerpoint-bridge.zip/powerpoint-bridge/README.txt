ROS PowerPoint Bridge (prebuilt)

No Node.js / npm install required.

1. Unzip this folder completely. Do not run START.bat from inside the zip window.
2. Open PowerPoint with your deck.
3. Double-click START.bat (or ROS PowerPoint Bridge.exe in the same folder).
4. Paste the Railway API URL and an integration token (ros_itok_...) with read,control,write.
5. Load events, pick the show.
6. PowerPoint Show with Timers: Capture stills, then Start follow.
7. ROS PPT Launcher: Sync decks (downloads decks + slide images), then Follow loaded cue or Manual open. Do not expect live PowerPoint export.

Keep the .exe next to resources\app.asar.
