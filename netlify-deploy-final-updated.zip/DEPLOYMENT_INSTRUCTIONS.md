# Netlify Deployment Instructions

## Required Environment Variables

After deploying to Netlify, you MUST set these environment variables in your Netlify dashboard:

1. Go to **Site Settings** → **Environment Variables**
2. Add the following variables:

```
NEON_DATABASE_URL=postgresql://neondb_owner:npg_lxfHkb60SjMi@ep-noisy-salad-adtczvk3-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
```

## Testing the Deployment

### 1. Test the Main App
- Visit your Netlify URL (e.g., `https://your-site.netlify.app`)
- The React app should load normally

### 2. Test Netlify Functions
After setting the environment variables, test these URLs:

**XML Endpoints:**
- `https://your-site.netlify.app/.netlify/functions/lower-thirds-xml?eventId=YOUR_EVENT_ID`
- `https://your-site.netlify.app/.netlify/functions/schedule-xml?eventId=YOUR_EVENT_ID`
- `https://your-site.netlify.app/.netlify/functions/custom-columns-xml?eventId=YOUR_EVENT_ID`

**CSV Endpoints:**
- `https://your-site.netlify.app/.netlify/functions/lower-thirds-csv?eventId=YOUR_EVENT_ID`
- `https://your-site.netlify.app/.netlify/functions/schedule-csv?eventId=YOUR_EVENT_ID`
- `https://your-site.netlify.app/.netlify/functions/custom-columns-csv?eventId=YOUR_EVENT_ID`

### 3. Get Event ID
To get a valid event ID, run this locally first:
```bash
node check-event-ids.js
```

## VMIX Integration

Once deployed and environment variables are set:

1. **For Local Development:**
   - Use: `http://localhost:3002/api/lower-thirds-csv?eventId=YOUR_EVENT_ID`

2. **For Netlify Deployment:**
   - Use: `https://your-site.netlify.app/.netlify/functions/lower-thirds-csv?eventId=YOUR_EVENT_ID`

## Troubleshooting

### Functions Not Working
1. Check that environment variables are set in Netlify dashboard
2. Check Netlify function logs in the dashboard
3. Verify the event ID exists in the database

### XML Pages Not Loading
1. Make sure the React app is deployed correctly
2. Check browser console for errors
3. Verify the event ID is being passed correctly

### VMIX Not Importing Data
1. Test the CSV/XML URLs directly in a browser first
2. Make sure you're using a valid event ID
3. Check that the data contains items marked as "Public"

## Architecture

- **React App**: Frontend with WebSocket for real-time updates
- **Netlify Functions**: Serverless API endpoints for CSV/XML data
- **Neon Database**: PostgreSQL database for data storage
- **Railway**: WebSocket server for real-time updates

## Low Egress Design

This deployment is optimized for minimal data usage:
- WebSocket connections for real-time updates
- HTTP endpoints only called when needed
- Efficient caching and data structures
